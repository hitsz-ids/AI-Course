# -*-Encoding: utf-8 -*-
################################################################################
#
# Copyright (c) 2022 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
Description: Evaluate the performance
Authors: Lu,Xinjiang (luxinjiang@baidu.com)
Date:    2022/03/10
"""
import os
import sys
import time
import traceback
import numpy as np
import pandas as pd
import metrics as metrics
import argparse

def performance(settings, prediction, ground_truth, ground_truth_df):
    """
    单个滑窗的指标计算
    prediction: shape [风机数, 288, 1]
    ground_truth: shape [风机数, 288, 1]
    ground_truth_df: list，每个风机一个 DataFrame
    """
    wind_farm_prediction = np.sum(prediction, axis=0)
    wind_farm_ground = np.sum(ground_truth, axis=0)
    day_len = settings["day_len"]
    acc = 1 - metrics.rmse(wind_farm_prediction[-day_len:, -1],
                           wind_farm_ground[-day_len:, -1]) / (settings["capacity"] * 1000)
    overall_mae, overall_rmse = \
        metrics.regressor_detailed_scores(prediction, ground_truth, ground_truth_df, settings)
    return overall_mae, overall_rmse, acc


def load_predictions_and_ground_truth(pred_dir_path, gt_dir_path):
    """
    Desc:
        加载所有滑动窗口的预测和真实值，组织成 [风机数, 滑窗数, 288, 1] 的四维数组
    Args:
        pred_dir_path: 预测结果目录
        gt_dir_path: 标准答案目录
    Returns:
        predictions, grounds, raw_data_lst
    """
    print(f"Loading predictions from directory: {pred_dir_path}")
    print(f"Loading ground truth from directory: {gt_dir_path}")

    pred_files = sorted([f for f in os.listdir(pred_dir_path) if f.endswith('.csv')])
    gt_files = sorted([f for f in os.listdir(gt_dir_path) if f.endswith('.csv')])

    print(f"Found {len(pred_files)} prediction files and {len(gt_files)} ground truth files")

    if len(pred_files) != len(gt_files):
        raise ValueError(f"预测结果文件数（{len(pred_files)}）与标准答案文件数（{len(gt_files)}）不一致，请检查提交结果！")
    if len(pred_files) == 0:
        raise ValueError("未检测到任何预测结果文件，请检查提交目录！")

    num_turbines = 134
    output_len = 288
    num_features = 1
    num_windows = len(pred_files)

    # 初始化
    predictions = np.zeros((num_turbines, num_windows, output_len, num_features), dtype=np.float32)
    grounds = np.zeros((num_turbines, num_windows, output_len, num_features), dtype=np.float32)
    # raw_data_lst: 每个风机一个DataFrame，包含所有滑窗的原始数据
    raw_data_dict = {tid: [] for tid in range(1, num_turbines+1)}

    for win_idx, (pred_file, gt_file) in enumerate(zip(pred_files, gt_files)):
        print(f"Processing file {win_idx+1}/{len(pred_files)}: {pred_file}")
        pred_path = os.path.join(pred_dir_path, pred_file)
        gt_path = os.path.join(gt_dir_path, gt_file)
        pred_df = pd.read_csv(pred_path)
        gt_df = pd.read_csv(gt_path)

        # 检查列
        required_cols = ['TurbID', 'Day', 'Tmstamp', 'Patv']
        for col in required_cols:
            if col not in pred_df.columns:
                raise ValueError(f"预测文件 {pred_file} 缺少 {col} 列，请检查文件格式！")
            if col not in gt_df.columns:
                raise ValueError(f"标准答案文件 {gt_file} 缺少 {col} 列，请联系主办方！")

        # 按TurbID排序，确保顺序一致
        pred_df = pred_df.sort_values(['TurbID', 'Day', 'Tmstamp']).reset_index(drop=True)
        gt_df = gt_df.sort_values(['TurbID', 'Day', 'Tmstamp']).reset_index(drop=True)

        if not pred_df[['TurbID', 'Day', 'Tmstamp']].equals(gt_df[['TurbID', 'Day', 'Tmstamp']]):
            print("pred_df head:")
            print(pred_df[['TurbID', 'Day', 'Tmstamp']].head(10))
            print("gt_df head:")
            print(gt_df[['TurbID', 'Day', 'Tmstamp']].head(10))
            raise ValueError(f"预测文件和标准答案的 'TurbID', 'Day', 'Tmstamp' 不一致，请检查数据对齐！")

        for tid in range(1, num_turbines+1):
            pred_turb = pred_df[pred_df['TurbID'] == tid]
            gt_turb = gt_df[gt_df['TurbID'] == tid]
            if len(pred_turb) != output_len:
                raise ValueError(f"文件 {pred_file} 中风机 {tid} 的数据长度不是 {output_len}，请检查数据！")
            if len(gt_turb) != output_len:
                raise ValueError(f"文件 {gt_file} 中风机 {tid} 的数据长度不是 {output_len}，请检查数据！")
            
            # 取Patv，缺失填0
            pred_patv = pred_turb['Patv'].fillna(0).values.astype(np.float32)
            gt_patv = gt_turb['Patv'].fillna(0).values.astype(np.float32)
            predictions[tid-1, win_idx, :, 0] = pred_patv
            grounds[tid-1, win_idx, :, 0] = gt_patv
            # 收集原始数据
            raw_data_dict[tid].append(gt_turb.reset_index(drop=True))

    # raw_data_lst: 每个风机一个DataFrame，行数=滑窗数*288
    raw_data_lst = [pd.concat(raw_data_dict[tid], ignore_index=True) for tid in range(1, num_turbines+1)]

    # 新增：按滑窗切分
    predictions_list = [predictions[:, win_idx, :, :] for win_idx in range(num_windows)]
    grounds_list = [grounds[:, win_idx, :, :] for win_idx in range(num_windows)]

    return predictions_list, grounds_list, raw_data_lst


def evaluate(settings, pred_dir_path, gt_dir_path):
    predictions_list, grounds_list, raw_data_lst = load_predictions_and_ground_truth(pred_dir_path, gt_dir_path)
    maes, rmses, accs = [], [], []
    num_windows = len(predictions_list)
    for i in range(num_windows):
        prediction = predictions_list[i]  # shape: [风机数, 288, 1]
        ground_truth = grounds_list[i]    # shape: [风机数, 288, 1]
        # 取出每个风机当前滑窗的 288 行
        raw_data_window = [raw_data_lst[j].iloc[i*288:(i+1)*288].reset_index(drop=True) for j in range(len(raw_data_lst))]
        tmp_mae, tmp_rmse, tmp_acc = performance(settings, prediction, ground_truth, raw_data_window)
        print(f'滑窗 {i+1}: MAE={tmp_mae:.4f}, RMSE={tmp_rmse:.4f}, Score={(tmp_mae+tmp_rmse)/2:.4f}, Accuracy={tmp_acc*100:.2f}%')
        maes.append(tmp_mae)
        rmses.append(tmp_rmse)
        accs.append(tmp_acc)
    avg_mae = np.mean(maes)
    avg_rmse = np.mean(rmses)
    avg_acc = np.mean(accs)
    total_score = (avg_mae + avg_rmse) / 2
    print('\n --- Final MAE: {:.4f}, RMSE: {:.4f}, Accuracy: {:.2f}% ---'.format(avg_mae, avg_rmse, avg_acc*100))
    print('--- Final Score --- \n\t{:.4f}'.format(total_score))
    return {
        "score": total_score,
        "MAE": avg_mae,
        "RMSE": avg_rmse,
        "Accuracy": avg_acc,
    }
    


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Wind Power Prediction Evaluation")
    parser.add_argument('--pred_dir', type=str, required=True, help='submission directory')
    parser.add_argument('--gold_dir', type=str, required=True, help='gold directory')
    args = parser.parse_args()
    
    #args.pred_dir='/data1/caozk/run_openhands/wind_power/workspace/dataset/sdwpf_kddcup/final_phase_test/outfile_sample_submission'
    #args.gt_dir='/data1/caozk/run_openhands/wind_power/workspace/dataset/sdwpf_kddcup/final_phase_test/outfile_gold'
    
    settings = {
        "capacity": 134,
        "day_len": 144,
        "output_len": 288,
        "stride": 1,
        "is_debug": False
    }
    try:
        result = evaluate(settings, args.pred_dir, args.gold_dir)
    except Exception as e:
        traceback.print_exc()
        print(f"\n评分失败：{e}\n请检查提交的预测结果格式、文件名、文件数、内容等是否符合要求。")
        