目前评分有两张方式：

+ 方式1：官方竞赛方式：官方竞赛是需要提交模型和模型预测脚本以及配置脚本进行评分，比较复杂，人工复现比赛榜单上代码时可用此方式
+ 方式2：对官方的评分方式修改，只需要读入预测输入和结果输出csv文件进行评分，大多数kaggle比赛都是这种形式，方便评分。Agent适配sota适合用此方式评分。

## 方式1：竞赛方式评分

目录：evaluate_competition

官方竞赛评分方式，是需要提交模型、预测脚本以及配置脚本进行评分。人工复现比赛榜单上的代码时可用此方式，这些代码会生成好提交文件。

注：官方baseline评分有问题，评分应该是先对单个切片汇总（134台风机求和），然后对所有切片求平均。官方baseline代码是先对单个风机的所有切片求平均，然后对所有风机求和。   【可能是baseline测试示例只有单个切片（一个文件），这时没有问题，没有考虑到多个切片的问题。】

evaluate_competition目录中的评分代码是更正后的，在榜单第三名的代码结果上测试结果是一致的，官方baseline不一致。

result目录中是评分需要提交的东西，训练和预测输入数据路径在prepare.py中配置。

使用方式：

```
python evalutaion.py
```



## 方式2：Agent评分

简化了官方评分方式，不需要提交模型和预测脚本等，只需要预测结果csv文件。Agent适配代码后评分用此方式。

每个预测结果csv文件的需要的字段：

```
TurbID,Day,Tmstamp,Patv
1,15,00:00,95.21088
2,15,00:00,152.86607
3,15,00:00,130.24957
4,15,00:00,84.50839
5,15,00:00,136.95972
6,15,00:00,119.456345
```

使用方式：

```
python evaluation.py --pred_dir <predict results dir> --gold_dir <gold dir>

例如：
python evaluation.py --pred_dir /workspace/dataset/sdwpf_kddcup/final_phase_test/outfile_submission --gold_dir /workspace/dataset/sdwpf_kddcup/final_phase_test/outfile_gold
```

目录中内容为142个切片的预测结果和答案：

```
(wpf3rd) root@AGX-18:~/KDDCup2022-WPF# ls /workspace/dataset/sdwpf_kddcup/final_phase_test/outfile_submission
0001out.csv  0012out.csv  0023out.csv  0034out.csv  0045out.csv  0056out.csv  0067out.csv  0078out.csv  0089out.csv  0100out.csv  0111out.csv  0122out.csv  0133out.csv
0002out.csv  0013out.csv  0024out.csv  0035out.csv  0046out.csv  0057out.csv  0068out.csv  0079out.csv  0090out.csv  0101out.csv  0112out.csv  0123out.csv  0134out.csv
0003out.csv  0014out.csv  0025out.csv  0036out.csv  0047out.csv  0058out.csv  0069out.csv  0080out.csv  0091out.csv  0102out.csv  0113out.csv  0124out.csv  0135out.csv
0004out.csv  0015out.csv  0026out.csv  0037out.csv  0048out.csv  0059out.csv  0070out.csv  0081out.csv  0092out.csv  0103out.csv  0114out.csv  0125out.csv  0136out.csv
0005out.csv  0016out.csv  0027out.csv  0038out.csv  0049out.csv  0060out.csv  0071out.csv  0082out.csv  0093out.csv  0104out.csv  0115out.csv  0126out.csv  0137out.csv
0006out.csv  0017out.csv  0028out.csv  0039out.csv  0050out.csv  0061out.csv  0072out.csv  0083out.csv  0094out.csv  0105out.csv  0116out.csv  0127out.csv  0138out.csv
0007out.csv  0018out.csv  0029out.csv  0040out.csv  0051out.csv  0062out.csv  0073out.csv  0084out.csv  0095out.csv  0106out.csv  0117out.csv  0128out.csv  0139out.csv
0008out.csv  0019out.csv  0030out.csv  0041out.csv  0052out.csv  0063out.csv  0074out.csv  0085out.csv  0096out.csv  0107out.csv  0118out.csv  0129out.csv  0140out.csv
0009out.csv  0020out.csv  0031out.csv  0042out.csv  0053out.csv  0064out.csv  0075out.csv  0086out.csv  0097out.csv  0108out.csv  0119out.csv  0130out.csv  0141out.csv
0010out.csv  0021out.csv  0032out.csv  0043out.csv  0054out.csv  0065out.csv  0076out.csv  0087out.csv  0098out.csv  0109out.csv  0120out.csv  0131out.csv  0142out.csv
0011out.csv  0022out.csv  0033out.csv  0044out.csv  0055out.csv  0066out.csv  0077out.csv  0088out.csv  0099out.csv  0110out.csv  0121out.csv  0132out.csv
(wpf3rd) root@AGX-18:~/KDDCup2022-WPF#
(wpf3rd) root@AGX-18:~/KDDCup2022-WPF# ls /workspace/dataset/sdwpf_kddcup/final_phase_test/outfile_gold/
0001out.csv  0012out.csv  0023out.csv  0034out.csv  0045out.csv  0056out.csv  0067out.csv  0078out.csv  0089out.csv  0100out.csv  0111out.csv  0122out.csv  0133out.csv
0002out.csv  0013out.csv  0024out.csv  0035out.csv  0046out.csv  0057out.csv  0068out.csv  0079out.csv  0090out.csv  0101out.csv  0112out.csv  0123out.csv  0134out.csv
0003out.csv  0014out.csv  0025out.csv  0036out.csv  0047out.csv  0058out.csv  0069out.csv  0080out.csv  0091out.csv  0102out.csv  0113out.csv  0124out.csv  0135out.csv
0004out.csv  0015out.csv  0026out.csv  0037out.csv  0048out.csv  0059out.csv  0070out.csv  0081out.csv  0092out.csv  0103out.csv  0114out.csv  0125out.csv  0136out.csv
0005out.csv  0016out.csv  0027out.csv  0038out.csv  0049out.csv  0060out.csv  0071out.csv  0082out.csv  0093out.csv  0104out.csv  0115out.csv  0126out.csv  0137out.csv
0006out.csv  0017out.csv  0028out.csv  0039out.csv  0050out.csv  0061out.csv  0072out.csv  0083out.csv  0094out.csv  0105out.csv  0116out.csv  0127out.csv  0138out.csv
0007out.csv  0018out.csv  0029out.csv  0040out.csv  0051out.csv  0062out.csv  0073out.csv  0084out.csv  0095out.csv  0106out.csv  0117out.csv  0128out.csv  0139out.csv
0008out.csv  0019out.csv  0030out.csv  0041out.csv  0052out.csv  0063out.csv  0074out.csv  0085out.csv  0096out.csv  0107out.csv  0118out.csv  0129out.csv  0140out.csv
0009out.csv  0020out.csv  0031out.csv  0042out.csv  0053out.csv  0064out.csv  0075out.csv  0086out.csv  0097out.csv  0108out.csv  0119out.csv  0130out.csv  0141out.csv
0010out.csv  0021out.csv  0032out.csv  0043out.csv  0054out.csv  0065out.csv  0076out.csv  0087out.csv  0098out.csv  0109out.csv  0120out.csv  0131out.csv  0142out.csv
0011out.csv  0022out.csv  0033out.csv  0044out.csv  0055out.csv  0066out.csv  0077out.csv  0088out.csv  0099out.csv  0110out.csv  0121out.csv  0132out.csv
(wpf3rd) root@AGX-18:~/KDDCup2022-WPF#
```

