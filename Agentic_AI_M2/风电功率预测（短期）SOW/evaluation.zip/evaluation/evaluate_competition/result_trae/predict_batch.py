# -*-Encoding: utf-8 -*-

"""
Description: Batch forecasting for multiple test files
"""

import os
import gc
import time
import glob
import joblib
import numpy as np
import pandas as pd
import tensorflow as tf
from predict import CFG, custom_loss, build_nn_feature, get_lag_rolling_feature


def build_test_data_single(test_file_path, settings):
    """Build test data for a single test file"""
    df_raw = pd.read_csv(test_file_path)
    df_raw[['Wspd', 'Wdir', 'Prtv', 'Patv']] = df_raw.groupby(['TurbID'])[['Wspd', 'Wdir', 'Prtv', 'Patv']].apply(lambda x: x.ffill().bfill())

    latest_hist = df_raw.groupby(['TurbID'])['Patv'].tail(3).values.reshape(-1, 3)
    latest_hist = np.mean(latest_hist, axis=1)
    latest_hist = np.tile(latest_hist.reshape(-1, 1, 1), (1, 3, 1))
    
    # scaler or not
    if CFG.scaler is not None:
        scaler = joblib.load(os.path.join(settings['checkpoints'], CFG.scaler))
        df_raw[CFG.feature_column_norm] = scaler.transform(df_raw[CFG.feature_column_norm])

    turbine_id = df_raw.groupby(['TurbID'])['TurbID'].tail(1).values.reshape(-1, 1).astype(np.int32)
    df_raw['Hour'] = pd.to_datetime(df_raw['Tmstamp'], format='%H:%M').dt.hour
    df_raw['Minute'] = pd.to_datetime(df_raw['Tmstamp'], format='%H:%M').dt.minute
    df_raw['MinuteofDay'] = df_raw['Hour'] * 6 + df_raw['Minute'] / 10
    df_raw['DayofWeek'] = df_raw['Day'] // 7

    df_raw, feature_cols = build_nn_feature(df_raw)
    feature_idx = [df_raw.columns.get_loc(c) for c in feature_cols]

    history_features = df_raw.groupby(['TurbID']).tail(CFG.train_sequence_length).values[:, list(range(3, 13))+feature_idx]
    history_features = history_features.reshape(134, CFG.train_sequence_length, -1).astype(np.float32)   
  
    encoder_features_long = df_raw[['Hour', 'MinuteofDay', 'DayofWeek']].iloc[-CFG.train_sequence_length:].values
    decoder_features_long = df_raw[['Hour', 'MinuteofDay', 'DayofWeek']].iloc[-CFG.predict_sequence_length:].values
    features_long = np.concatenate([encoder_features_long, decoder_features_long], axis=0)    
    features_long = np.tile(np.expand_dims(features_long, 0), (134, 1, 1))   
    
    dataset = tf.data.Dataset.from_tensor_slices(((turbine_id, history_features, features_long), np.ones((134, 288, 1))))
    dataset = dataset.batch(CFG.test_batch_size)

    # Get the last timestamp info for generating future timestamps
    last_day = df_raw.iloc[-1]['Day']
    last_timestamp = df_raw.iloc[-1]['Tmstamp']
    
    # Calculate daily pattern adjustment
    last = df_raw.iloc[-1]['MinuteofDay']    
    shift = int((last + 1) % 144)
    all_history = pd.read_csv(os.path.join(settings['data_path'], settings['filename']))
    all_history['Hour'] = pd.to_datetime(all_history['Tmstamp'], format='%H:%M').dt.hour
    all_history['Minute'] = pd.to_datetime(all_history['Tmstamp'], format='%H:%M').dt.minute
    all_history['MinuteofDay'] = all_history['Hour'] * 6 + all_history['Minute'] / 10
    
    turb_day = all_history.groupby(['TurbID', 'MinuteofDay'])['Patv'].agg('mean')
    turb_day_unstack = turb_day.unstack(level=-1).values
    turb_day_shift = np.roll(turb_day_unstack, -1 * shift, axis=1)
    turb_day_shift = (turb_day_shift - 205.) / (527. - 205.)

    turb_day_shift = turb_day_shift * 36  # base

    top70_max = np.percentile(turb_day_shift, 33)
    turb_day_shift[np.where(turb_day_shift > top70_max)] = turb_day_shift[
                                                               np.where(turb_day_shift > top70_max)] * 2.25

    top50_max = np.percentile(turb_day_shift, 50)
    turb_day_shift[np.where(turb_day_shift > top50_max)] = turb_day_shift[
                                                               np.where(turb_day_shift > top50_max)] * 1.55

    top10_max = np.percentile(turb_day_shift, 90)
    turb_day_shift[np.where(turb_day_shift > top10_max)] = turb_day_shift[
                                                               np.where(turb_day_shift > top10_max)] * 1.25

    top4_max = np.percentile(turb_day_shift, 96)
    turb_day_shift[np.where(turb_day_shift > top4_max)] = turb_day_shift[
                                                              np.where(turb_day_shift > top4_max)] * 1.15

    turb_day_shift = np.concatenate([turb_day_shift, turb_day_shift], axis=1)
    turb_day_shift = np.expand_dims(turb_day_shift, 2)
    
    del turb_day, df_raw
    gc.collect()
    
    return dataset, turb_day_shift, latest_hist, last_day, last_timestamp


def load_model(settings):
    """Load trained models"""
    models = []
    for m in CFG.use_models:
        models.append(
            tf.keras.models.load_model(os.path.join(settings['checkpoints'], m), custom_objects={'custom_loss': custom_loss})
            )
    return models


def generate_future_timestamps(last_day, last_timestamp, n_steps=288):
    """Generate future timestamps for 48 hours (288 steps of 10 minutes each)"""
    # Parse last timestamp
    last_hour, last_minute = map(int, last_timestamp.split(':'))
    
    timestamps = []
    current_day = last_day
    current_hour = last_hour
    current_minute = last_minute
    
    for _ in range(n_steps):
        # Add 10 minutes
        current_minute += 10
        if current_minute >= 60:
            current_minute = 0
            current_hour += 1
            if current_hour >= 24:
                current_hour = 0
                current_day += 1
        
        timestamps.append((current_day, f"{current_hour:02d}:{current_minute:02d}"))
    
    return timestamps


def forecast_single_file(test_file_path, settings, models):
    """Forecast for a single test file"""
    test_loader, turb_day_shift, latest_hist, last_day, last_timestamp = build_test_data_single(test_file_path, settings)
    
    res = []
    for model in models:
        time_res = []
        for x in test_loader:
            y = model(x)  # batch * 288 * 1
            time_res.append(y.numpy())
        time_res = np.concatenate(time_res)  # 134 * 288 * 1
        res.append(time_res)

    res = np.array(res)
    res = np.mean(res, axis=0)  # n_turbine * n_time * 1
    res = res + turb_day_shift
    res = np.concatenate([latest_hist, res[:, 3:, :]], axis=1)
    res = np.clip(res, 1, 1520)

    # Generate future timestamps
    future_timestamps = generate_future_timestamps(last_day, last_timestamp)
    
    # Create submission dataframe
    submission_data = []
    for turb_id in range(1, 135):  # TurbID from 1 to 134
        for i, (day, timestamp) in enumerate(future_timestamps):
            submission_data.append({
                'TurbID': turb_id,
                'Day': day,
                'Tmstamp': timestamp,
                'Patv': res[turb_id-1, i, 0]  # turb_id-1 because array is 0-indexed
            })
    
    submission_df = pd.DataFrame(submission_data)
    
    del test_loader
    gc.collect()
    return submission_df


def batch_forecast(settings):
    """Process all test files and generate submissions"""
    # Load models once
    models = load_model(settings)
    
    # Get all input files
    input_dir = settings['input_dir']
    output_dir = settings['output_dir']
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    input_files = sorted(glob.glob(os.path.join(input_dir, "*in.csv")))
    print(f"Found {len(input_files)} test files to process")
    
    for input_file in input_files:
        print(f"Processing {input_file}...")
        
        # Generate output filename
        input_filename = os.path.basename(input_file)
        output_filename = input_filename.replace('in.csv', 'out.csv')
        output_path = os.path.join(output_dir, output_filename)
        
        # Forecast for this file
        submission_df = forecast_single_file(input_file, settings, models)
        
        # Save submission
        submission_df.to_csv(output_path, index=False)
        print(f"Saved predictions to {output_path}")
    
    # Clean up models
    tf.keras.backend.clear_session()
    del models
    gc.collect()
    
    print(f"Batch forecasting completed. Results saved to {output_dir}")


if __name__ == '__main__':
    from prepare import prep_env
    
    settings = prep_env()
    settings['input_dir'] = '/workspace/dataset/sdwpf_kddcup/final_phase_test/infile'
    settings['output_dir'] = '/workspace/dataset/sdwpf_kddcup/final_phase_test/outfile_submission'
    settings['data_path'] = '../../data/raw'
    settings['filename'] = 'wtbdata_245days.csv'
    
    t1 = time.time()
    batch_forecast(settings)
    print("Total cost {}s".format(time.time() - t1))