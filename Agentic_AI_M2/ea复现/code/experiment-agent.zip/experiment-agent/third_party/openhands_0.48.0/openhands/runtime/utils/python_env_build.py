import asyncio
import os
import re

import requests

from openhands.core.logger import openhands_logger as logger
from openhands.events.action import (
    CmdRunAction,
    PythonAutoSetupAction, CmdRunStreamAction,
)
from openhands.events.observation import (
    CmdOutputObservation,
    ErrorObservation,
    PythonAutoSetupObservation,
)
from openhands.runtime.utils.bash import BashSession
from openhands.runtime.utils.reproduction_tool_utils import CONFIG_FILE_NAME
from openhands.utils.async_utils import call_sync_from_async


async def get_supported_python_version(package_name, version=None):
    """
    获取指定包在 PyPI 上的 Python 支持版本。
    如果传入了 version 参数，则查询对应版本；否则查询最新版本的信息。

    优先尝试使用 info.requires_python 字段，
    如果该字段不可用，则根据 classifiers 中的 “Programming Language :: Python :: …”
    信息来返回支持的 Python 版本列表（以逗号分隔的字符串）。
    """
    logger.info(f'开始获取{package_name},version:{version},python版本')
    if version:
        url = f'https://pypi.org/pypi/{package_name}/{version}/json'
    else:
        url = f'https://pypi.org/pypi/{package_name}/json'

    try:
        response = requests.get(url)
        response.raise_for_status()  # 检查请求是否成功
        data = response.json()

        # # 首先尝试从 requires_python 字段中获取支持的 Python 版本
        # requires_python = data['info'].get('requires_python')
        # if requires_python and requires_python != 'Not specified':
        #     return requires_python

        # 如果 requires_python 不明确，则根据 classifiers 中的信息获取
        classifiers = data['info'].get('classifiers', [])
        py_versions = []
        for classifier in classifiers:
            # 判断是否以 "Programming Language :: Python ::" 开头
            if classifier.startswith('Programming Language :: Python ::'):
                # 提取后面的版本号部分
                parts = classifier.split('::')
                if len(parts) >= 3:
                    ver = parts[2].strip()
                    if ver.startswith('3.'):
                        py_versions.append(ver)
        if py_versions:
            # 去重并排序后返回版本信息
            py_versions = sorted(
                set(py_versions), key=lambda v: [int(x) for x in v.split('.')]
            )
            logger.info(f'去重后py版本{py_versions}')
            return py_versions

    except requests.exceptions.RequestException as e:
        logger.info(f'Error fetching data from PyPI for {package_name}: {e}')
        return None


def add_config(key, value):
    print(f'增加配置:{key},值为:{value}')
    import json

    # 1. 读取 JSON 文件
    file_path = CONFIG_FILE_NAME
    with open(file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)  # 解析为 Python 字典
    data[key] = value
    # 3. 写回 JSON 文件
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)  # 格式化输出

    print('修改后的数据：', data)


import re


async def parse_requirements_txt(path):
    """
    返回元组：(python_version, dependencies)
    """
    logger.info('enter the parse_requirements_txt')
    dependencies = []
    python_version = None

    VALID_OPERATORS = {'==', '>=', '<=', '>', '<', '~=', '!='}

    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue

            if line.lower().startswith('python'):
                m = re.search(r'python\s*([=><!~]+)\s*([\d\.]+)', line, re.IGNORECASE)
                if m:
                    operator = m.group(1)
                    version = m.group(2)
                    if operator in VALID_OPERATORS:
                        python_version = version
            else:
                # 匹配包名、操作符和版本
                pattern = r'([\w\-\[\]]+)(?:\s*([=><!~]+)\s*([\d\.\*\w]+))?'
                m = re.match(pattern, line)
                if m:
                    package = m.group(1)
                    raw_operator = m.group(2) if m.group(2) else None
                    raw_version = m.group(3) if m.group(3) else None

                    # 验证操作符
                    operator = raw_operator if raw_operator in VALID_OPERATORS else None

                    # 验证版本号格式（可选）
                    version = raw_version
                    if version and not re.match(r'^[\d\.\*]+$', version):
                        # 如果版本号包含非数字、点号或星号，可能格式有问题
                        logger.warning(f"Potentially invalid version format: {version} in line: {line}")

                    dependencies.append((package, version, operator))

    return python_version, dependencies


def version_to_tuple(v):
    """将版本字符串转换为元组用于比较"""
    return tuple(int(x) for x in v.split('.'))


async def get_python_version_from_txt(file_path):
    logger.info('enter the get_python_version_from_txt')
    version, deps = await parse_requirements_txt(file_path)
    if version:
        logger.info(f'获得 Python 版本: {version}')
        return version, deps
    else:
        logger.info('txt文件中未获得 Python 版本')
        # 如果是 requirements.txt 则累计依赖列表
    if deps:
        common_versions = []
        logger.info('\n开始遍历依赖项，获取各包的 Python 版本要求：')
        for package, pkg_version,operator in deps:
            if package in ['torch', 'numpy', 'pandas'] and pkg_version:
                constraint = await get_supported_python_version(package, pkg_version)
                logger.info(f'constraint:{constraint}')
                if constraint is not None:
                    common_versions.append(constraint)
        if common_versions:
            from packaging.version import parse

            logger.info('计算依赖版本')
            # 计算交集
            common_versions_set = set(common_versions[0])
            # 计算交集
            for constraint in common_versions[1:]:
                if constraint is not None:
                    common_versions_set.intersection_update(constraint)
            if common_versions_set:
                best_version = max(common_versions_set, key=parse)
                logger.info(
                    f'\n根据依赖项计算出的最佳 Python 版本(max)为:{best_version}'
                )
                return best_version, deps
            else:
                logger.info('没有找到共同的 Python 版本约束')
                return '3.9', deps
    return '3.9', deps


def get_close_version(parts, pkg_version):
    versions_part = parts[1].strip()
    available_versions = [
        v.strip() for v in re.split(r',\s*', versions_part) if v.strip()
    ]

    # 获取当前包的大版本号（第一个数字）
    try:
        major_version = pkg_version.split('.')[0]
    except (IndexError, AttributeError):
        major_version = None

    # 筛选出大版本号相同的版本
    same_major_versions = [
        v for v in available_versions if v.split('.')[0] == major_version
    ]

    if same_major_versions:
        # 先尝试找更新的版本
        newer_versions = [v for v in same_major_versions if v > pkg_version]
        if newer_versions:
            newer_versions.sort()
            selected_version = newer_versions[0]  # 取最小的更新版本
        else:
            # 没有更新的版本，找最接近的旧版本
            older_versions = [v for v in same_major_versions if v < pkg_version]
            if older_versions:
                older_versions.sort(reverse=True)
                selected_version = older_versions[0]  # 取最大的旧版本
            else:
                selected_version = None
    else:
        selected_version = None

    return selected_version


async def run_command(cmd):
    """异步运行 shell 命令"""
    process = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,  # 关键参数：禁用终端控制
        stdin=asyncio.subprocess.DEVNULL,  # 不接收输入
        start_new_session=True,  # 避免继承终端进程组
    )
    stdout, stderr = await process.communicate()
    return process.returncode, stdout.decode(), stderr.decode()


class PythonEnvExecutor:
    def __init__(self, bash_session: BashSession, action: PythonAutoSetupAction):
        self.bash_session = bash_session
        self.action = action
        self.installed_packages = set()

    async def run(
            self, action: CmdRunAction, stream_callback=None
    ) -> CmdOutputObservation | ErrorObservation:
        action.stream_callback = stream_callback
        obs = await call_sync_from_async(self.bash_session.execute, action)
        return obs

    async def run_stream(self, action: CmdRunStreamAction):
        """以流式方式执行命令，并实时返回输出结果。"""
        async for obs in self.bash_session.execute_stream(action):
            yield obs

    async def execute_stream_cmd(self, cmd: str):
        cmd_action = CmdRunStreamAction(command=cmd)
        try:
            logger.info(f'待执行命令:{cmd}')
            async for obs in self.run_stream(cmd_action):
                if isinstance(obs, ErrorObservation):
                    return False, obs.content
                else:
                    if obs.exit_code == 0:
                        logger.info(f'cmd execute completed,{cmd}')
                        return True, 'success'
                    elif obs.exit_code != -1:
                        return False, obs.content
        except Exception as e:
            return False, str(e)

    async def _init_conda_config(self):
        logger.info('初始化conda 条款和镜像源配置')

        command = (
            "bash -c '"
            "conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/main && "
            "conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/r && "
            "conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/main && "
            "conda config --add channels https://mirrors.tuna.tsinghua.edu.cn/anaconda/pkgs/free && "
            "conda config --add channels conda-forge && "
            "conda config --set show_channel_urls yes'"
        )

        success, message = await self.execute_stream_cmd(command)

        if success:
            logger.info('conda 条款接受并配置镜像源成功')
        else:
            logger.error(f'conda 条款或镜像源配置失败，原因: {message}')

    async def _create_conda_env(self, action, preferred_version, fallback_version):
        """创建conda环境"""
        if preferred_version:
            logger.info(f'创建推荐python版本{preferred_version}')
            success, message = await self.execute_stream_cmd(
                f"bash -c 'conda create -n {action.env_name} python={preferred_version} -y -c conda-forge'"
            )
            if success:
                logger.info(f'推荐python版本{preferred_version}创建成功')
                return True
            else:
                parts = preferred_version.split('.')
                if len(parts) >= 2:
                    version = '.'.join(parts[:2])
                    success, message = await self.execute_stream_cmd(
                        f"bash -c 'conda create -n {action.env_name} python={version} -y -c conda-forge'"
                    )
                    if success:
                        logger.info(f'python版本{version}创建成功')
                        return True
            logger.info(f'推荐python版本{preferred_version}创建失败,原因:{message}')
        logger.info(f'创建版本{fallback_version}')
        success, result = await self.execute_stream_cmd(
            f"bash -c 'conda create -n {action.env_name} python={fallback_version} -y -c conda-forge'"
        )
        return success

    async def _setup_env_tools(self, action):
        """设置环境基础工具"""
        logger.info('升级pip和setuptools and wheel')
        success, result = await self.execute_stream_cmd(
            f"bash -i -c '/opt/conda/envs/{action.env_name}/bin/pip install --upgrade setuptools pip wheel'"
        )
        if not success:
            logger.error(f'升级setuptools pip wheel失败,错误信息:{result}')
        return success

    async def _install_callgraph_tool(self, action):
        """安装callgraph工具"""
        logger.info('开始安装callgraph_tool')
        success, result = await self.execute_stream_cmd(
            f"bash -i -c '/opt/conda/envs/{action.env_name}/bin/pip install /app/callgraph_tool-0.1.0-py3-none-any.whl --timeout 999'"
        )
        if not success:
            logger.error(f'安装callgraph_tool失败，错误原因: {result}')
        success, result = await self.execute_stream_cmd(
            f"bash -i -c '/opt/conda/envs/{action.env_name}/bin/pip install seaborn --timeout 999'"
        )
        return success

    async def _install_all_dependencies(self, action, file_path, dependencies):
        """安装所有依赖"""
        # 收集所有依赖
        all_deps = await self._collect_all_dependencies(action, file_path)
        if all_deps is None:
            logger.warning('未能收集所有依赖')
            all_deps = []

        # 合并依赖
        merged_deps = self._merge_dependencies(dependencies, all_deps)
        logger.info(f'所有依赖为: {merged_deps}')

        # 安装依赖
        fail_pkgs = []
        for package, pkg_version, pkg_operator in merged_deps:
            if not await self._install_dependency(action, package, pkg_version, pkg_operator):
                fail_pkgs.append(package)
        return fail_pkgs

    async def _collect_all_dependencies(self, action, file_path):
        """使用pipreqs收集所有依赖"""
        logger.info('开始安装pipreqs')
        success, _ = await self.execute_stream_cmd(
            f"bash -i -c '/opt/conda/envs/{action.env_name}/bin/pip install pipreqs'"
        )
        if not success:
            logger.warning('安装pipreqs失败')
            return None

        logger.info('生成所有依赖的txt文件')
        dep_dir = os.path.dirname(file_path)
        all_requirements_file_path = os.path.join(dep_dir, 'requirements_all.txt')

        success, _ = await self.execute_stream_cmd(
            f"bash -i -c '/opt/conda/envs/{action.env_name}/bin/pipreqs {dep_dir} --savepath={all_requirements_file_path}'"
        )
        if not success:
            logger.warning('生成所有依赖的txt文件失败')
            return None
        _, all_deps = await parse_requirements_txt(all_requirements_file_path)
        return [(pkg, None, None) for pkg, version, operator in all_deps]

    def _merge_dependencies(self, primary_deps, secondary_deps):
        """合并依赖项"""
        pkg_all = dict(secondary_deps)
        pkg_all.update(dict(primary_deps))
        return (
                primary_deps  # 主要依赖在前
                + [
                    (pkg, pkg_all[pkg])
                    for pkg, _ in secondary_deps
                    if pkg not in dict(primary_deps)
                ]  # 剩余项
        )

    async def _install_dependency(self, action, package, version, pkg_operator):
        if package in ('pytorch', 'torch'):
            if (
                    'pytorch' in self.installed_packages
                    or 'torch' in self.installed_packages
            ):
                logger.info(f'已安装 PyTorch，跳过 {package} 的安装')
                return True
        """安装单个依赖"""
        install_attempts = [
            # 尝试1: 使用指定版本pip安装
            (
                f'/opt/conda/envs/{action.env_name}/bin/pip install --prefer-binary {package}{pkg_operator}{version}',
                version, pkg_operator is not None,
                'pip',
            ),
            # 尝试2: 不指定版本pip安装
            (
                f'/opt/conda/envs/{action.env_name}/bin/pip install --prefer-binary {package}',
                True,
                'pip',
            ),
            # 尝试3: 使用conda安装指定版本 (注意conda是全局命令)
            (
                f'conda install -n {action.env_name} -c conda-forge {package}{pkg_operator}{version} -y',
                version, pkg_operator is not None and pkg_operator != '~=',
                'conda',
            ),
            # 尝试4: 使用conda安装不指定版本
            (f'conda install -n {action.env_name} -c conda-forge {package} -y', True, 'conda'),
        ]

        for cmd, condition, cmd_type in install_attempts:
            if not condition:
                continue
            success, result = await self.execute_stream_cmd(cmd)

            if success:
                logger.info(f"{package}{f'=={version}' if version else ''} 安装成功")
                if package in ('pytorch', 'torch'):
                    self.installed_packages.update(['pytorch', 'torch'])
                return True
            else:
                logger.warning(f'安装失败: {cmd}, 错误: {result}')

                # 如果有版本信息，尝试寻找相近版本
                if version and 'from versions:' in result:
                    closest_version = self._find_closest_version(result, version)
                    if closest_version:
                        return await self._install_closest_version(
                            action, package, closest_version
                        )
        return False

    def _find_closest_version(self, error_msg, target_version):
        """从错误信息中寻找最接近的版本"""
        parts = error_msg.split('from versions:')
        if len(parts) > 1:
            return get_close_version(parts, target_version)
        return None

    async def _install_closest_version(self, action, package, version):
        """安装最接近的版本"""
        logger.info(f'尝试安装推荐版本: {package}=={version}')
        success, result = await self.execute_stream_cmd(
            f"bash -i -c '/opt/conda/envs/{action.env_name}/bin/pip install {package}=={version}'"
        )
        if success:
            logger.info(f'{package}=={version} 安装成功')
        else:
            logger.error(f'{package}=={version} 安装失败, 错误: {result}')
        return success

    async def _finalize_environment_setup(self, action, file_path):
        """完成环境设置"""
        try:
            cmd = CmdRunAction(
                command=f'echo "export PATH=/opt/conda/envs/{action.env_name}/bin:$PATH" >> ~/.bashrc && '
                        f'conda init && '
                        f'source ~/.bashrc && '
                        f'conda activate {action.env_name} && '
                        f'cd {os.path.dirname(file_path)} && '
                        f'export PYTHONPATH=$PYTHONPATH:$(pwd)'
            )
            obs = await self.run(cmd)
            logger.info(f'环境设置完成: {obs}')
            key = f'{action.namespace}_env'
            add_config(key, action.env_name)

            return PythonAutoSetupObservation(
                dependency_file_path=action.dependency_file_path,
                env_name=action.env_name,
                content=f'success to init env,create a conda env named {action.env_name},next install dependencies',
                success=True,
            )
        except Exception as e:
            return self._failed_response(action, str(e))

    def _failed_response(self, action, msg):
        return PythonAutoSetupObservation(
            dependency_file_path=action.dependency_file_path,
            env_name=action.env_name,
            content=msg,
            success=False,
        )

    async def handle_txt_dependencies(
            self, file_path, action, python_version
    ) -> PythonAutoSetupObservation:
        """处理.txt后缀的依赖文件"""
        logger.info('开始.txt后缀依赖处理')

        # 1. 获取Python版本和依赖
        py_version, dependencies = await get_python_version_from_txt(
            file_path=file_path
        )
        logger.info(f'依赖版本信息: {dependencies}')

        # 2. 创建conda环境
        # await self._init_conda_config()
        env_created = await self._create_conda_env(action, python_version, py_version)
        if not env_created:
            return self._failed_response(
                action, f'创建conda环境失败, python版本: {py_version},请重新调用python_auto_setup工具安装'
            )

        # 3. 设置环境基础工具
        # if not await self._setup_env_tools(action):
        #     logger.error('升级setuptools pip wheel失败')

        # 4. 安装callgraph工具
        # if not await self._install_callgraph_tool(action):
        #     return self._failed_response(action, '安装callgraph_tool失败')

        # # 5. 收集并安装所有依赖
        # fail_pkgs = await self._install_all_dependencies(
        #     action, file_path, dependencies
        # )
        # if fail_pkgs:
        #     logger.info(f'安装失败的依赖项{fail_pkgs}')
        #     return self._failed_response(
        #         action,
        #         f'conda env created success,named {action.env_name},but deps install failed,packages:{fail_pkgs}',
        #     )

        # 6. 设置环境变量
        return await self._finalize_environment_setup(action, file_path)

    async def _create_conda_by_yml(self, file_path):
        logger.info(
            f'conda 执行conda init &&  conda env create -f {file_path} 创建虚拟环境'
        )
        return await run_command(
            f"bash -i -c 'conda init &&  conda env create -f {file_path}'"
        )

    async def generate_env(self) -> PythonAutoSetupObservation:
        action = self.action
        try:
            logger.info('进入python 环境安装')
            file_path = action.dependency_file_path
            _, ext = os.path.splitext(file_path)
            ext = ext.lower()
            logger.info('判断文件后缀')
            if ext in ['.yml', '.yaml']:
                # 执行 conda 命令创建虚拟环境
                return_code, stdout, stderr = await self._create_conda_by_yml(file_path)
                if return_code != 0:
                    logger.error(f'{stderr}')
                    return self._failed_response(action, '创建conda 环境失败')
                #  设置环境基础工具
                # if not await self._setup_env_tools(action):
                #     logger.error('升级setuptools pip wheel失败')

                # #  安装callgraph工具
                # if not await self._install_callgraph_tool(action):
                #     return self._failed_response(action, '安装callgraph_tool失败')
                # 执行conda env create -f path
                return await self._finalize_environment_setup(action, file_path)
            elif ext == '.txt':
                file_path = action.dependency_file_path
                _, ext = os.path.splitext(file_path)
                return await self.handle_txt_dependencies(
                    file_path, action, action.python_version
                )
            else:
                return PythonAutoSetupObservation(
                    dependency_file_path=action.dependency_file_path,
                    env_name=action.env_name,
                    content='The file format is not supported',
                    success=True,
                )
            #
        except Exception as e:
            logger.error(e, exc_info=True)
            return PythonAutoSetupObservation(
                dependency_file_path=action.dependency_file_path,
                env_name=action.env_name,
                content=str(e),
                success=False,
            )
