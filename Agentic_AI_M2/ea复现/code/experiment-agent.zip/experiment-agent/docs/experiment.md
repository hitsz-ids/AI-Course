# 相关工作：

- TimeXer：Empowering Transformers for Time Series Forecasting with Exogenous Variables
  - NeuIPS 2024: https://proceedings.neurips.cc/paper_files/paper/2024/file/0113ef4642264adc2e6924a3cbbdf532-Paper-Conference.pdf
  - github地址：https://github.com/thuml/TimeXer
- Time-MoE: Billion-Scale Time Series Foundation Models with Mixture of Experts
  - ICLR 2025: https://arxiv.org/abs/2409.16040
  - github地址：https://github.com/Time-MoE/Time-MoE
- ST-ReP: Learning Predictive Representations Efficiently for Spatial-Temporal Forecasting
  - AAAI-25: https://arxiv.org/html/2412.14537v1
  - github地址：https://github.com/zhuoshu/ST-ReP
- 2DXformer: Dual Transformers for Wind Power Forecasting with Dual Exogenous Variables
  - ICDM 2024: https://ieeexplore.ieee.org/stamp/stamp.jsp?arnumber=10884123
  - github地址:https://github.com/jseaj/2DXformer
- Hiformer: Hybrid Frequency Feature Enhancement Inverted Transformer for Long-Term Wind Power Prediction
  - arxiv: https://arxiv.org/abs/2207.08518
  - github地址：https://github.com/linyi201314/Hiformer
- DLinear: Are Transformers Effective for Time Series Forecasting?
  - AAAI 2023：https://arxiv.org/pdf/2205.13504
  - github地址：https://github.com/vivva/DLinear

# 实验结果：

| 相关工作  | **MAE** | **RMSE** | **Score** |
| :-------- | :------ | :------- | :-------- |
| TimeXer   | 43.7744 | 53.3985  | 48.5864   |
| Time-MoE  | 53.23   | 70.29    | 61.76     |
| ST-ReP    | 53.48   | 64.65    | 59.06     |
| 2DXformer | 53.05   | 70.03    | 61.54     |
| Hiformer  | 52.7    | 64.62    | 58.66     |
| DLinear   | 45.6541 | 57.3024  | 51.4782   |

# 实验结论

从以上实验结果可以得到两个明显的结论：

- 表现最好的是 **TimeXer**算法，而它并不是时间上最新的工作

- 算法**Time-MoE**的论文中体现的效果实际上是比**DLinear**要好，从实验结果看反而**DLinear**的效果要好于**Time-MoE**

这说明：真正的 SOTA 必须基于适配后的统一评测，而不是简单依赖最新论文中的声明