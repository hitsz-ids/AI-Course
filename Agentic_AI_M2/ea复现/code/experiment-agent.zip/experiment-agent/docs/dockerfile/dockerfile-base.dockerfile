FROM ghcr.io/all-hands-ai/runtime:0.48-nikolaik

# 安装基础工具 + Conda（根据架构自动选择）
RUN apt-get update && apt-get install -y wget bzip2 tree && \
    ARCH=$(uname -m) && \
    if [ "$ARCH" = "x86_64" ]; then \
        CONDA_URL="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh"; \
    elif [ "$ARCH" = "aarch64" ]; then \
        CONDA_URL="https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-aarch64.sh"; \
    else \
        echo "Unsupported architecture: $ARCH" && exit 1; \
    fi && \
    wget $CONDA_URL -O /tmp/miniconda.sh && \
    bash /tmp/miniconda.sh -b -p /opt/conda && \
    rm /tmp/miniconda.sh

# 添加 Conda 到 PATH
ENV PATH="/opt/conda/bin:${PATH}"

# 配置 Conda 使用中科大镜像（防止访问默认源）
RUN echo "channels:" > /opt/conda/.condarc && \
    echo "  - https://mirrors.ustc.edu.cn/anaconda/pkgs/main" >> /opt/conda/.condarc && \
    echo "  - https://mirrors.ustc.edu.cn/anaconda/pkgs/free" >> /opt/conda/.condarc && \
    echo "channel_priority: flexible" >> /opt/conda/.condarc && \
    echo "show_channel_urls: true" >> /opt/conda/.condarc

# 更新 Conda（使用国内源，避免官方 TOS）
RUN conda config --set always_yes yes && \
    conda update -n base conda --override-channels \
        -c https://mirrors.ustc.edu.cn/anaconda/pkgs/main \
        -c https://mirrors.ustc.edu.cn/anaconda/pkgs/free
RUN conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/main
RUN conda tos accept --override-channels --channel https://repo.anaconda.com/pkgs/free

# github config
RUN mkdir -p ~/.ssh
RUN cp -v ~/.ssh/known_hosts ~/.ssh/known_hosts.bak 2>/dev/null || true
RUN cat >> ~/.ssh/known_hosts <<'EOF'
github.com ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl
github.com ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBEmKSENjQEezOmxkZMy7opKgwFB9nkt5YRrYMjNuG5N87uRgg6CLrbo5wAdT/y6v0mKV0U2w0WZ2YB/++Tpockg=
github.com ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCj7ndNxQowgcQnjshcLrqPEiiphnt+VTTvDP6mHBL9j1aNUkY4Ue1gvwnGLVlOhGeYrnZaMgRK6+PKCUXaDbC7qtbW8gIkhL7aGCsOr/C56SJMy/BCZfxd1nWzAOxSDPgVsmerOBYfNqltV9/hWCqBywINIR+5dIg6JTJ72pcEpEjcYgXkE2YEFXV1JHnsKgbLWNlhScqb2UmyRkQyytRLtL+38TGxkxCflmO+5Z8CSSNY7GidjMIZ7Q4zMjA2n1nGrlTDkzwDCsw+wqFPGQA179cnfGWOWRVruj16z6XyvxvjJwbz0wQZ75XK5tKSb7FNyeIEs4TT4jk+S4dhPeAUC5y+bDYirYgM4GC7uEnztnZyaVWQ7B381AK4Qdrwt51ZqExKbQpTUNn+EjqoTwvqNj4kqx5QUCI0ThS/YkOxJCXmPUWZbhjpCg56i+2aB6CmK2JGhn57K5mj0MNdBXA4/WnwH6XoPWJzK5Nyu2zB3nAZp+S5hpQs+p1vN1/wsjk=
EOF
RUN chmod 700 ~/.ssh
RUN chmod 644 ~/.ssh/known_hosts

COPY third_party/openhands_0.48.0 /openhands/code
RUN cd /openhands/code \
    && /openhands/poetry/openhands-ai-5O4_aCHf-py3.12/bin/pip install -e .
COPY third_party/openhands-aci /app/openhands-aci
RUN cd /app/openhands-aci \
    && /openhands/poetry/openhands-ai-5O4_aCHf-py3.12/bin/pip install -e .


# 或者使用 echo 版本（更兼容）
RUN mkdir -p /root/.pip && \
    echo '[global]' > /root/.pip/pip.conf && \
    echo 'index-url = https://pypi.tuna.tsinghua.edu.cn/simple' >> /root/.pip/pip.conf && \
    echo 'trusted-host = pypi.tuna.tsinghua.edu.cn' >> /root/.pip/pip.conf && \
    echo 'timeout = 6000' >> /root/.pip/pip.conf

# 示例构建命令 在项目根目录下执行
# docker build -t experiment-agent-base:0.1 -f docs/dockerfile/dockerfile-base.dockerfile .
