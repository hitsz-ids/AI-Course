import os
import time
import uuid

ENV_EA_CLIENT_PARAMS = 'ENV_EA_CLIENT_PARAMS'
GLOBAL_SID = os.getenv('ENV_EA_CLIENT_SID', str(uuid.uuid4()))
os.environ['DEBUG'] = '1'
os.environ['LOG_ALL_EVENTS'] = '1'
os.environ['LOG_TO_FILE'] = '1'
# os.environ['LOG_DIR'] = f'~/.ea/logs/{GLOBAL_SID}'
os.environ['LOG_DIR'] = f'./output/logs'
# os.environ['SANDBOX_ENV_http_proxy'] = 'http://127.0.0.1:7900'
# os.environ['SANDBOX_ENV_https_proxy'] = 'http://127.0.0.1:7900'
params_from_env = os.getenv(ENV_EA_CLIENT_PARAMS, None)
import argparse
import json
from pathlib import Path
from experiment_agent.framework.models.models import ExperimentParams
from experiment_agent import ExperimentAgent


def main():
    parser = argparse.ArgumentParser(description="Run task with agent")
    parser.add_argument("--params-file", required=False, help="task json file")
    parser.add_argument("--config-file", required=False, help="config toml file")
    args = parser.parse_args()
    config = args.config_file
    if config is None or config == '':
        config = os.getcwd()
    config = os.path.join(config, 'config.toml')
    if params_from_env is None:
        params_from_args = args.params_file
        if params_from_args is None:
            raise RuntimeError('启动参数有误，请检查参数')
        else:
            params_json = Path(params_from_args).read_text(encoding='utf-8')
    else:
        params_json = params_from_env

    data = json.loads(params_json)
    params = ExperimentParams(**data)
    agent = ExperimentAgent(GLOBAL_SID, config)
    agent.run(params)


if __name__ == "__main__":
    main()
