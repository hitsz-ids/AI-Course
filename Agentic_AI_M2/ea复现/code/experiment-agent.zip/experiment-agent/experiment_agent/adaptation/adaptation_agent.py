import os
from pathlib import Path

import docker
from openhands.core.config import OpenHandsConfig
from openhands.runtime import DockerRuntime, GoogleKubernetesRuntime

from experiment_agent.adaptation.config.adaptation_config import AdaptationConfig
from experiment_agent.adaptation.model.adaptaion_result import AdaptationResult
from experiment_agent.framework.agent.base import Agent, StepDecision
from experiment_agent.framework.delegate.impl.openhands_delegate import OpenhandsDelegate
from experiment_agent.framework.delegate.impl.openhands_delegate import create_openhands_config
from experiment_agent.framework.logger.logger import ea_logger
from experiment_agent.framework.memery.conversation import Conversation, Step
from experiment_agent.framework.memery.impl.file_store import FileStore
from experiment_agent.framework.memery.impl.memory_store import MemoryStore
from experiment_agent.framework.memery.iteration_model import IterationModel
from experiment_agent.reproduction.model.reproduction_result import ReproductionResult
from experiment_agent.framework.utils.object import convert


def cleanup_container(container_name):
    try:
        # client = docker.from_env()
        # container = client.containers.get(container_name)
        # container.remove(force=True)
        # ea_logger.info(f"已清理失败的容器: {container_name}")
        pass
    except Exception as e:
        raise ValueError(f"清理容器失败: {e}")


class AdaptationAgent(Agent[ReproductionResult, AdaptationResult]):
    adaptation_config: AdaptationConfig
    project_env: str
    project_name: str
    project_path: str
    evaluation_env: str
    image_name: str
    workspace: str
    pod_name: str
    openhands_config: OpenHandsConfig

    def init_config(self):
        ea_logger.info(f'Create Adaptation Agent id is:{self.id}')
        self.adaptation_config = self.config.adaptation
        self.project_env = self.params.project_env
        self.project_name = self.params.project_name
        self.evaluation_env = self.params.evaluation_env
        self.image_name = self.params.image_name
        if self.config.runtime == 'google_k8s':
            self.workspace = self.params.workspace
            self.pod_name = self.params.pod_name if self.params is not None else None

    def init_delegate(self) -> OpenhandsDelegate | None:
        self.openhands_config = create_openhands_config()
        self.openhands_config.default_agent = 'CodeActAgent'
        self.openhands_config.max_iterations = self.adaptation_config.max_iterations
        self.openhands_config.sandbox.enable_gpu = self.config.enable_gpu
        self.openhands_config.sandbox.base_container_image = self.image_name
        self.openhands_config.sandbox.runtime_container_image = self.image_name
        self.openhands_config.runtime = self.config.runtime
        if self.config.runtime == 'google_k8s':
            if self.pod_name:
                self.openhands_config.google_k8s_config.pod_name = self.pod_name
            self.openhands_config.google_k8s_config.workspace_bucket = self.workspace
            if self.config.enable_gpu:
                self.openhands_config.google_k8s_config.gpu_count = self.config.google_k8s.gpu_count
        elif self.config.runtime == 'docker':
            self.openhands_config.workspace_mount_path = self.config.local_docker.workspace
            self.openhands_config.sandbox.cuda_visible_devices = self.config.local_docker.cuda_visible_devices
        for key, value in self.openhands_config.llms.items():
            for attr in self.config.llm.__annotations__:
                if not attr.startswith('_'):
                    setattr(value, attr, getattr(self.config.llm, attr))
        for key, value in self.openhands_config.agents.items():
            value.llm_config = 'llm'

        return OpenhandsDelegate(openhands_config=self.openhands_config,
                                 conda_env=self.project_env,
                                 pre_next_step=self._delegate_pre_next_step,
                                 is_change_python_env=True,
                                 sid=self.id)

    def init_memory(self):
        if self.adaptation_config.memory_storage_type == 'file':
            return FileStore(
                name='adaptation',
                iteration_model=IterationModel(
                    self.adaptation_config.max_iterations, 1),
                conversation=Conversation(),
                sid=self.id)
        else:
            return MemoryStore(
                name='adaptation',
                iteration_model=IterationModel(
                    self.adaptation_config.max_iterations, 1),
                conversation=Conversation(),
                sid=self.id)

    def run(self) -> AdaptationResult | None:
        is_finish = self.delegate.run(self.load_instruction())
        if is_finish:
            return AdaptationResult(
                id='',
                workspace=''
            )
        else:
            return None

    def _delegate_pre_next_step(self, step: Step, current_iteration: int) -> StepDecision:
        if current_iteration > self.memory.max_iterations:
            return StepDecision(prompt='', proceed=False)
        self.memory.set_iteration(current_iteration)
        self.memory.record(step)
        self.should_proceed_next_step(self.memory)
        return StepDecision(prompt='', proceed=True)

    def load_instruction(self):
        template = Path(os.path.join(os.path.dirname(__file__), 'prompts', 'instruction_template.txt')).read_text(
            encoding='utf-8')
        prompt = template.format(
            conda_env=self.project_env,
            evaluation_conda_env=self.evaluation_env,
            project=self.project_name
        )
        return prompt

    def close_resources(self):
        delegate = convert(self.delegate, OpenhandsDelegate)
        if self.config.runtime == 'docker':
            container_name = delegate.runtime(DockerRuntime).container_name
            cleanup_container(container_name)
        elif self.config.runtime == 'google_k8s':
            delegate.runtime(GoogleKubernetesRuntime).cleanup_k8s_resources()
