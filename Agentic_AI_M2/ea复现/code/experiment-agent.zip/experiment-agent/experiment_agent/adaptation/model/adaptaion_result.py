from experiment_agent import StageResult


class AdaptationResult(StageResult):
    id: str
    workspace: str
