#!/bin/bash

# 删除旧的 workspace 目录
if [ -d "./workspace" ]; then
    echo "Removing old workspace directory..."
    rm -rf ./workspace
else
    echo "No old workspace directory found."
fi

# 克隆新的仓库
cp -R /Users/jcl/project/DLinear_adaptation ./workspace

echo "Workspace setup completed successfully."
