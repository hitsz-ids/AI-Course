import asyncio
from dataclasses import asdict

import requests
import re

from google.cloud.aiplatform.telemetry import tool_context_manager
from pydantic import ValidationError

from experiment_agent import ExperimentConfig


async def parse_requirements_txt(path):
    """
    返回元组：(python_version, dependencies)
      - python_version：如果有在文件中直接声明 Python 版本则返回版本，否则为 None
      - dependencies：列表形式 [(package, version), ...]，如果没有版本号，version 为 None
    """
    dependencies = []
    python_version = None

    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            # 如果行中包含 Python 版本约束，则尝试提取
            if line.lower().startswith("python"):
                m = re.search(r'python\s*[=><!~]+\s*([\d\.]+)', line, re.IGNORECASE)
                if m:
                    python_version = m.group(1)
            else:
                # 提取 package 和 version（可能没有版本号）
                m = re.match(r'([\w\-]+)(?:[>=]=([\d\.]+))?', line)
                if m:
                    package = m.group(1)
                    version = m.group(2) if m.group(2) else None
                    dependencies.append((package, version))

    return python_version, dependencies


async def get_supported_python_version(package_name, version=None):
    """
    获取指定包在 PyPI 上的 Python 支持版本。
    如果传入了 version 参数，则查询对应版本；否则查询最新版本的信息。

    优先尝试使用 info.requires_python 字段，
    如果该字段不可用，则根据 classifiers 中的 “Programming Language :: Python :: …”
    信息来返回支持的 Python 版本列表（以逗号分隔的字符串）。
    """
    if version:
        url = f"https://pypi.org/pypi/{package_name}/{version}/json"
    else:
        url = f"https://pypi.org/pypi/{package_name}/json"

    try:
        response = requests.get(url)
        response.raise_for_status()  # 检查请求是否成功
        data = response.json()

        # # 首先尝试从 requires_python 字段中获取支持的 Python 版本
        # requires_python = data['info'].get('requires_python')
        # if requires_python and requires_python != 'Not specified':
        #     return requires_python

        # 如果 requires_python 不明确，则根据 classifiers 中的信息获取
        classifiers = data['info'].get('classifiers', [])
        py_versions = []
        for classifier in classifiers:
            # 判断是否以 "Programming Language :: Python ::" 开头
            if classifier.startswith("Programming Language :: Python ::"):
                # 提取后面的版本号部分
                parts = classifier.split("::")
                if len(parts) >= 3:
                    ver = parts[2].strip()
                    if ver.startswith("3."):
                        py_versions.append(ver)
        if py_versions:
            # 去重并排序后返回版本信息
            py_versions = sorted(
                set(py_versions), key=lambda v: [int(x) for x in v.split(".")]
            )
            return py_versions

    except requests.exceptions.RequestException as e:
        return None


async def get_python_version_from_txt(file_path):
    version, deps = await parse_requirements_txt(file_path)
    if version:
        return version, deps
    else:
        # 如果是 requirements.txt 则累计依赖列表
        print(f"txt文件中未获得 Python 版本")
    if deps:
        common_versions = []
        for package, pkg_version in deps:
            if package in ['torch', 'numpy', 'pandas'] and pkg_version:
                constraint = await get_supported_python_version(package, pkg_version)
                if constraint is not None:
                    common_versions.append(constraint)
        if common_versions:
            from packaging.version import parse

            # 计算交集
            common_versions_set = set(common_versions[0])
            # 计算交集
            for constraint in common_versions[1:]:
                if constraint is not None:
                    common_versions_set.intersection_update(constraint)
            if common_versions_set:
                best_version = max(common_versions_set, key=parse)
                return best_version, deps
            else:
                return '3.9', deps
    return '3.9', deps

def monitor_prompt(command_info, content):
    prompt = f"""You are a machine learning training monitoring assistant, responsible for analyzing and judging the status of command line execution.
Your task is to monitor the commands and their outputs I run in the terminal in real time, help me judge whether the program is running normally, and decide whether to stop or continue waiting.
You need to judge whether it is a machine learning or deep learning task based on the output of the program. If not, return "CONTINUE" directly. If it is, execute according to the following standards:
### Monitoring content:
1. **Executed command**: `{command_info}`
2. **Program output**: Current time: `{content}`

### Your goal:
- **Normal execution**: If the output shows that the loss is decreasing, the accuracy is improving, and there are no abnormal warnings or errors, return "CONTINUE".
- **Potential problems**: If the loss becomes NaN or inf, or the model fails to converge for a long time and the accuracy stagnates, return "STOP".
- **Error termination**: If the output contains obvious errors, such as insufficient memory, data loading failure, or tensor shape mismatch, return "STOP" immediately.
- **Notice**: Early stop information in the output is not a stop signal, it is a normal log, trainning script will process it, you should return "CONTINUE".

- **This task is not related to machine learning or deep learning**: If the program output itself is not related to machine learning or deep learning, "CONTINUE" is returned.

### Output format:
- **Normal operation: return `{{"status": "CONTINUE"}}`
- **Anomaly detected: return `{{"status": "STOP", "reason": "REASON"}}`

### Important:
- **Only JSON objects are returned without any other formatting or backticks. **
- **Please note that if there is no output content that can be used for judgment, continue to wait.
                """
    print(prompt)


import json
import toml
ENV_VAR = 'EXPERIMENT_CONFIG'

def _load_from_toml(config_file: str) -> ExperimentConfig:
    try:
        with open(config_file, 'r', encoding='utf-8') as toml_contents:
            toml_config = toml.load(toml_contents)
    except Exception as e:
        raise e
    return ExperimentConfig.model_validate(toml_config)

def _load_from_env(env_var: str) -> ExperimentConfig:
    config_json = os.getenv(env_var)
    try:
        config_data = json.loads(config_json)
        return ExperimentConfig.model_validate(config_data)
    except Exception as e:
        print(e)
        return ExperimentConfig()

if __name__ == '__main__':
    # params = {
    #     'task': ''
    # }
    # a_list = [
    #     {'github': 'xxxxx', 'project_name': 'xxxx'}
    # ]
    # from litellm import completion as litellm_completion
    # import json
    #
    # with open("tools_json.json", "r", encoding="utf-8") as f:
    #     data = json.load(f)
    # with open("prompt.log", "r", encoding="utf-8") as f:
    #     prompt = f.read()
    # message = {
    #     "role": 'user',
    #     "content": prompt
    # }
    # response = litellm_completion(
    #     model='claude-3-5-sonnet-20241022',
    #     api_key='sk-IBzdqGKVXTbQAZyveE24Q8s3GayhovdaQn1PpJRexdpyjyNR',
    #     base_url='https://poloai.top',
    #     tools=data,
    #     messages=[message]
    # )
    # print(response.choices[0].message)
    # print(response.choices[0].message.tool_calls[0])
    import os
    env_config = _load_from_env(ENV_VAR)
    toml_config = _load_from_toml('config.toml')
    config = ExperimentConfig()
    local_path = os.path.join(os.path.dirname(__file__), "config", 'config.toml')
    for attr in config.__annotations__:
        value = getattr(env_config, attr)
        if value is None:
            value = getattr(toml_config, attr)
        setattr(config, attr, value)
    config_json = config.model_dump_json(indent=2)
    print(config_json)
