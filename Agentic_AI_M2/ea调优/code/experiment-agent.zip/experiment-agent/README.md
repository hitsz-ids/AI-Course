# 启动服务进行开发

## 1. 要求

- Linux, Mac OS
- Python >= 3.12

## 2. 三方开源主要依赖

- openhands == 0.48.0

## 3. 依赖安装

``` bash
make dev
```

## 4. 配置文件创建

``` bash
# 会生成config.toml文件和openhands_config.toml
make config
``` 
## 5. 项目启动
```bash
python start.py
```

## 5. 启动

# 相关信息介绍

## 需要适配的sota、benchmark的目录要求

``` code
   workspace                  (rename it acording to your setting)        
   | --- dataset                    (required) (对应的benchmark数据目录)
      | --- data_description.md           (required) (对应数据的描述)
      | --- submisstion_description.md    (optional) (对应最终提交文件的描述)
   | --- evaluation.py           (required) (评测程序，如果评测程序涉及多个代码文件或者三方库，要保证该文件可以执行运行)
   | --- project-folder-name     (required rename it acording to your setting) (对应要适配的sota工作程序目录)
      | --- READEME.md               (required) (对应工程启动和配置的详细介绍)
```