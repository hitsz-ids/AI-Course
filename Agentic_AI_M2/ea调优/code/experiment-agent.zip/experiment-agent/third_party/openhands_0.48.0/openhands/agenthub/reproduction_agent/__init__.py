from openhands.agenthub.reproduction_agent.reproduction_agent import ReproductionAgent
from openhands.controller.agent import Agent

Agent.register('ReproductionAgent', ReproductionAgent)
