from litellm.types.llms.openai import ChatCompletionToolParam, ChatCompletionToolParamFunctionChunk

_EXTRACT_COMPRESSED_FILE_DESCRIPTION = """Extract a compressed file from a specified path.  
* The assistant should provide the file path of the compressed file and the destination folder to extract the contents.  
* Supported formats: zip, tar.gz, rar, 7z.
"""

ExtractCompressedFileTool = ChatCompletionToolParam(
    type='function',
    function=ChatCompletionToolParamFunctionChunk(
        name='extract_compressed_file',
        description=_EXTRACT_COMPRESSED_FILE_DESCRIPTION,
        parameters={
            'type': 'object',
            'properties': {
                'file_path': {
                    'type': 'string',
                    'description': 'Path of the compressed file to extract',
                },
                'format': {
                    'type': 'string',
                    'enum': ['zip', 'tar.gz', 'rar', '7z'],
                    'description': 'Compression format of the file',
                },
                'destination': {
                    'type': 'string',
                    'description': 'Destination folder to extract the contents',
                },
            },
            'required': ['file_path', 'format'],
        },
    ),
)
