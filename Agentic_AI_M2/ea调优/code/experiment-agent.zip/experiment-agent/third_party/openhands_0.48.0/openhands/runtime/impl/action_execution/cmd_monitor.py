"""
这一个监听者，当每次实例化的时候，就会自动开启一个线程和队列，外部可以直接调用函数向队列里面写入数据，内部一个线程隔一段时间后就可以获取当前队列里面的数据，并且打印出来
并且要提供可以停止关闭的接口让外部可以主动停止，且可以获取当前的状态
"""

import json
import threading
from collections import deque
from enum import Enum
from typing import Callable, Optional

from openhands.core.config import OpenHandsConfig
from openhands.core.message import TextContent, Message
from openhands.llm import LLM
from openhands.llm.metrics import Metrics


class CmdMonitorStatus(Enum):
    """命令监听器状态枚举"""

    INITIALIZED = 'initialized'
    RUNNING = 'running'
    STOPPED = 'stopped'
    FORCE_STOPPED = 'force_stopped'
    NOT_RUNNING = 'not_running'
    ERROR = 'error'


class TruncatedStrategy(Enum):
    TAIL = 'tail'
    HEAD_TAIL = 'head_tail'


class CmdMonitor:
    """命令监听器，用于监控命令执行过程中的输出"""

    def __init__(
        self,
        config: OpenHandsConfig,
        stop_task: Optional[Callable],
        logger: Optional[Callable],
        max_queue_size: int = 100,
        command: Optional[str] = None,  # 添加命令参数，用于LLM分析
    ):
        """
        初始化命令监听器

        Args:
            interval: 打印间隔时间（秒）
            max_queue_size: 队列最大元素数量
            logger: 日志记录函数，如果为None则使用print
            command: 正在执行的命令，用于LLM分析
        """
        self.max_queue_size = max_queue_size
        self.monitor_semaphore = threading.Semaphore(1)
        # 使用双向队列来存储内容
        self.content_queue = deque(maxlen=max_queue_size)
        self.stop_event = threading.Event()
        self.thread = None
        self.logger = logger
        self.stop_task = stop_task
        self.command = command
        self.max_chars = 10000
        self.accumulated_content = ''
        self.stop_reason = ''
        self.latest_content = ''
        self.status = CmdMonitorStatus.INITIALIZED
        self.force_stopped = False  # 标记是否被强制停止
        # 自动启动监听线程
        if config.enable_cmd_monitor:
            self.llm_config = config.get_llm_config('cmd_monitor')
            llm_metrics = Metrics(model_name='cmd_monitor:' + self.llm_config.model)
            self.llm = LLM(self.llm_config, metrics=llm_metrics)
            logger(f'[Cmd Monitor functionality] enabled with LLM: {self.llm}')
            self.interval = self.llm_config.interval
            self.start()

    def start(self):
        """启动监听线程"""
        if self.thread is not None and self.thread.is_alive():
            return

        self.stop_event.clear()
        self.status = CmdMonitorStatus.RUNNING
        self.thread = threading.Thread(target=self._monitor_loop)
        self.thread.daemon = True
        self.thread.start()

        return self

    def stop(self, force=False):
        """
        停止监听线程

        Args:
            force: 是否强制停止
        """
        if self.status != CmdMonitorStatus.RUNNING:
            return

        if force:
            self.force_stopped = True
            self.status = CmdMonitorStatus.FORCE_STOPPED
            self.stop_task()
        else:
            self.status = CmdMonitorStatus.STOPPED
        self.stop_event.set()

        # 避免当前线程join自己
        current_thread = threading.current_thread()
        if self.thread and self.thread.is_alive() and self.thread != current_thread:
            self.thread.join(timeout=2)

    def get_status(self) -> CmdMonitorStatus:
        """获取当前监听器状态"""
        if not self.thread or not self.thread.is_alive():
            if self.force_stopped:
                return CmdMonitorStatus.FORCE_STOPPED
            return CmdMonitorStatus.NOT_RUNNING
        return self.status

    def add_content(self, content: str):
        """
        添加内容到监听队列

        Args:
            content: 要添加的内容
        """
        if (
            self.status != CmdMonitorStatus.FORCE_STOPPED
            and self.status != CmdMonitorStatus.STOPPED
        ):
            self.content_queue.append(content)

    def get_accumulated_content(self) -> str:
        """获取当前累积的内容"""
        return self.accumulated_content

    def _truncated_content(
        self, log: str, strategy: TruncatedStrategy = TruncatedStrategy.TAIL
    ) -> str:
        max_chars = self.max_chars
        if len(log) <= max_chars:
            return log

        if strategy == TruncatedStrategy.HEAD_TAIL:
            half = max_chars // 2
            return (
                log[:half]
                + '\n[... Observation truncated due to length ...]\n'
                + log[-half:]
            )
        else:
            # By default or if no match is found, the TAIL mode is used directly
            return log[-max_chars:]

    def _monitor_loop(self):
        """监听循环，定期处理队列中的数据"""
        try:
            while not self.stop_event.is_set():
                self.stop_event.wait(timeout=self.interval)
                if self.status != CmdMonitorStatus.RUNNING:
                    self.logger('当前日志监控已停止')
                    break
                combined_content = ''.join(self.content_queue)
                if len(combined_content) > self.max_chars:
                    combined_content = self._truncated_content(combined_content)

                if combined_content == self.latest_content:
                    continue
                self.latest_content = combined_content
                self.logger(f'命令输出 (队列中的所有内容):\n{combined_content}')
                # 使用内部LLM分析方法
                should_stop = self._analyze_with_llm(combined_content)
                if should_stop:
                    self.logger("LLM分析建议停止执行")
                    # 强制停止并修改状态
                    self.stop(force=True)
                    break

        except Exception as e:
            self.status = CmdMonitorStatus.ERROR
            self.logger(f'监听线程出错: {str(e)}')
        finally:
            if not self.force_stopped:
                self.status = CmdMonitorStatus.STOPPED

    def __del__(self):
        """析构函数，确保线程被正确关闭"""
        self.stop()

    def _analyze_with_llm(self, content):
        """使用LLM分析命令输出内容"""
        try:
            # 优先使用常量中的API密钥，如果没有则从环境变量获取
            command_info = (
                f'command: {self.command}' if self.command else 'current command'
            )

            prompt = f"""You are a machine learning training monitoring assistant, responsible for analyzing and judging the status of command line execution.
Your task is to monitor the commands and their outputs I run in the terminal in real time, help me judge whether the program is running normally, and decide whether to stop or continue waiting.
You need to judge whether it is a machine learning or deep learning task based on the output of the program. If not, return "CONTINUE" directly. If it is, execute according to the following standards:

### Your goal:
- **Normal execution**: If the output shows that the loss is decreasing, the accuracy is improving, and there are no abnormal warnings or errors, return "CONTINUE".
- **Potential problems**: If the loss becomes NaN or inf, or the model fails to converge for a long time and the accuracy stagnates, return "STOP".
- **Error termination**: If the output contains obvious errors, such as insufficient memory, data loading failure, or tensor shape mismatch, return "STOP" immediately.
- **Notice**: Early stop information in the output is not a stop signal, it is a normal log, trainning script will process it, you should return "CONTINUE".

- **This task is not related to machine learning or deep learning**: If the program output itself is not related to machine learning or deep learning, "CONTINUE" is returned.

### Output format:
- **Normal operation: return `{{"status": "CONTINUE"}}`
- **Anomaly detected: return `{{"status": "STOP", "reason": "REASON"}}`

### Important:
- **Only JSON objects are returned without any other formatting or backticks. **
- **Please note that if there is no output content that can be used for judgment, continue to wait.

### Monitoring content:
1. **Executed command**:
 `{command_info}`
2. **Program output**: Current content:
 `{content}`
            """

            messages = [
                Message(
                    role='user',
                    content=[TextContent(text='\n' + prompt)],
                )
            ]
            params: dict = {
                'messages': self.llm.format_messages_for_llm(messages),
                'monitor': True
            }
            response = self.llm.completion(**params)
            response_text = response.choices[0].message.content.strip()
            self.logger(f'LLM分析结果: {response_text}')
            res = json.loads(response_text)
            status = res.get('status', 'CONTINUE')
            self.stop_reason = res.get('reason', '')
            if status in 'STOP':
                return True  # 需要停止
            return False  # 可以继续
        except Exception as e:
            self.logger(f'LLM分析出错: {str(e)}')
            # 出错时默认继续执行
            return False
