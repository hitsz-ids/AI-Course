from dataclasses import dataclass

from openhands.core.schema import ActionType
from openhands.events.action.action import Action, ActionConfirmationStatus, ActionSecurityRisk
from typing import ClassVar


@dataclass
class GitRepoDownloadAction(Action):
    """Get the recommended Python version based on project dependencies"""

    git_url: str = '',
    destination_path: str = ''
    project_name: str = ''
    action: str = ActionType.GIT_REPO_DOWNLOAD
    runnable: ClassVar[bool] = True

    @property
    def message(self) -> str:
        return f"git repo need download ,the git url : {self.git_url}"

    def __str__(self) -> str:
        ret = f'**GitRepoDownloadAction (source={self.source})**\n'
        ret += f'git_url:{self.git_url}\n'
        ret += f'destination_path:{self.destination_path}\n'
        ret += f'project_name:{self.project_name}\n'
        return ret


@dataclass
class PythonAutoSetupAction(Action):
    dependency_file_path: str
    env_name: str
    python_version: str
    namespace: str
    action: str = ActionType.PYTHON_AUTO_SETUP
    runnable: ClassVar[bool] = True

    @property
    def message(self) -> str:
        return f'setup the python env ,get the dependency_file: {self.dependency_file_path}and env_name:{self.env_name}'

    def __str__(self) -> str:
        return (f'**PythonAutoSetupAction  (source={self.source},**\n,'
                f'dependency_file_path={self.dependency_file_path})**\n'
                f'env_name={self.env_name})**\n'
                f'namespace={self.namespace})**\n'
                )


@dataclass
class ProjectStartCmdAction(Action):
    command: str
    thought: str = ''
    blocking: bool = False
    # If blocking is True, the command will be run in a blocking manner.
    # e.g., it will NOT return early due to soft timeout.
    hidden: bool = False
    action: str = ActionType.PROJECT_START
    runnable: ClassVar[bool] = True
    confirmation_state: ActionConfirmationStatus = ActionConfirmationStatus.CONFIRMED
    security_risk: ActionSecurityRisk | None = None

    @property
    def message(self) -> str:
        return f'Running project command: {self.command}'

    def __str__(self) -> str:
        ret = f'**ProjectStartCmdAction (source={self.source})**\n'
        if self.thought:
            ret += f'THOUGHT: {self.thought}\n'
        ret += f'COMMAND:\n{self.command}'
        return ret


@dataclass
class ExtractCompressedFileAction(Action):
    """Extracts a compressed file from a given path."""

    file_path: str
    format: str = 'zip'
    destination: str = '/workspace/dataset/'
    action: str = ActionType.EXTRACT_COMPRESSED_FILE
    runnable: ClassVar[bool] = True

    @property
    def message(self) -> str:
        return (
            f'Extracting {self.format} file from {self.file_path} to {self.destination}'
        )


@dataclass
class PythonTrackingAction(Action):
    """Tracks the Python code execution."""

    path: str
    repository_name: str = 'tracking_output'
    action: str = ActionType.PYTHON_TRACKING
    runnable: ClassVar[bool] = True

    @property
    def message(self) -> str:
        return f'Tracking the Python code execution in the file: {self.path}'


@dataclass
class DatasetDownloadAction(Action):
    """Downloads a dataset from a given URL."""

    url: str
    platform: str
    repository_name: str = 'mindflow_download_dataset'
    output_path: str = '/workspace/'
    action: str = ActionType.DATASET_DOWNLOAD
    runnable: ClassVar[bool] = True

    @property
    def message(self) -> str:
        return f'Download the {self.platform} Dataset from url: {self.url}'
