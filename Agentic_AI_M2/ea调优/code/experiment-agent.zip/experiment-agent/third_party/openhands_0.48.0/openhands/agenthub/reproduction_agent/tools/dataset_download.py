from litellm.types.llms.openai import ChatCompletionToolParam, ChatCompletionToolParamFunctionChunk

_DATASET_DOWNLOAD_DESCRIPTION = """This tool is the only way to download the dataset. It can obtain datasets from official sources, third-party repositories, or internal storage to ensure correctness, consistency, and access tracking.
"""

DatasetDownloadTool = ChatCompletionToolParam(
    type='function',
    function=ChatCompletionToolParamFunctionChunk(
        name='dataset_download',
        description=_DATASET_DOWNLOAD_DESCRIPTION,
        parameters={
            'type': 'object',
            'properties': {
                'url': {'type': 'string', 'description': 'Dataset download URL'},
                'platform': {
                    'type': 'string',
                    'enum': ['google_drive', 'kaggle'],
                    'description': 'Source platform',
                },
                "repository_name": {
                    'type': "string",
                    'description': "The name of the repository.",
                    "default": "mindflow_download_dataset",
                },
            },
            'required': ['url', 'source'],
        },
    ),
)
