import time
from functools import lru_cache
from typing import Callable
from uuid import UUID

import httpx
import kubernetes
import tenacity
import yaml
from kubernetes import client, config
from kubernetes.client import V1CSIVolumeSource
from kubernetes.client.models import (
    V1Container,
    V1ContainerPort,
    V1EnvVar,
    V1HTTPIngressPath,
    V1HTTPIngressRuleValue,
    V1Ingress,
    V1IngressBackend,
    V1IngressRule,
    V1IngressServiceBackend,
    V1IngressSpec,
    V1IngressTLS,
    V1ObjectMeta,
    V1PersistentVolumeClaim,
    V1PersistentVolumeClaimSpec,
    V1PersistentVolumeClaimVolumeSource,
    V1Pod,
    V1PodSpec,
    V1ResourceRequirements,
    V1SecurityContext,
    V1Service,
    V1ServiceBackendPort,
    V1ServicePort,
    V1ServiceSpec,
    V1Toleration,
    V1Volume,
    V1VolumeMount,
)
import google.auth
from google.cloud import container_v1, storage
from poetry.console.commands import self

from openhands.core.config import OpenHandsConfig
from openhands.core.exceptions import (
    AgentRuntimeDisconnectedError,
    AgentRuntimeNotFoundError,
)
from openhands.core.logger import DEBUG
from openhands.core.logger import openhands_logger as logger
from openhands.events import EventStream
from openhands.integrations.provider import PROVIDER_TOKEN_TYPE
from openhands.runtime.impl.action_execution.action_execution_client import (
    ActionExecutionClient,
)
from openhands.runtime.plugins import PluginRequirement
from openhands.runtime.runtime_status import RuntimeStatus
from openhands.runtime.utils.command import get_action_execution_server_startup_command
from openhands.utils.async_utils import call_sync_from_async
from openhands.utils.shutdown_listener import add_shutdown_listener
from openhands.utils.tenacity_stop import stop_if_should_exit

POD_NAME_PREFIX = 'openhands-runtime-'
POD_LABEL = 'openhands-runtime'

EXECUTION_SERVER_PORT_RANGE = (30000, 32767)


def _is_retryablewait_until_alive_error(exception: Exception) -> bool:
    if isinstance(exception, tenacity.RetryError):
        cause = exception.last_attempt.exception()
        return _is_retryablewait_until_alive_error(cause)

    return isinstance(
        exception,
        (
            ConnectionError,
            httpx.ConnectTimeout,
            httpx.NetworkError,
            httpx.RemoteProtocolError,
            httpx.HTTPStatusError,
            httpx.ReadTimeout,
        ),
    )


class GoogleKubernetesRuntime(ActionExecutionClient):
    """
    A Kubernetes runtime for OpenHands that works with Google Kubernetes Engine (GKE).

    This runtime creates pods in a GKE cluster to run the agent code.
    It uses the Kubernetes Python client to create and manage the pods.

    Args:
        config (OpenHandsConfig): The application configuration.
        event_stream (EventStream): The event stream to subscribe to.
        sid (str, optional): The session ID. Defaults to 'default'.
        plugins (list[PluginRequirement] | None, optional): List of plugin requirements. Defaults to None.
        env_vars (dict[str, str] | None, optional): Environment variables to set. Defaults to None.
        status_callback (Callable | None, optional): Callback for status updates. Defaults to None.
        attach_to_existing (bool, optional): Whether to attach to an existing pod. Defaults to False.
        headless_mode (bool, optional): Whether to run in headless mode. Defaults to True.
    """

    _shutdown_listener_id: UUID | None = None
    _namespace: str = ''

    def __init__(
            self,
            config: OpenHandsConfig,
            event_stream: EventStream,
            sid: str = 'default',
            plugins: list[PluginRequirement] | None = None,
            env_vars: dict[str, str] | None = None,
            status_callback: Callable | None = None,
            attach_to_existing: bool = False,
            headless_mode: bool = True,
            user_id: str | None = None,
            git_provider_tokens: PROVIDER_TOKEN_TYPE | None = None,

    ):
        if not GoogleKubernetesRuntime._shutdown_listener_id:
            GoogleKubernetesRuntime._shutdown_listener_id = add_shutdown_listener(
                lambda: GoogleKubernetesRuntime._cleanup_k8s_resources(
                    namespace=self._namespace,
                    remove_pvc=True,
                    conversation_id=self.sid,
                )  # this is when you ctrl+c.
            )
        self.config = config
        self._runtime_initialized: bool = False
        self.status_callback = status_callback

        # Load and validate GKE
        try:
            credentials, project_id = google.auth.default()
            if not project_id:
                raise ValueError("No Google Cloud project found. Please set your project.")
            self.project_id = project_id
        except Exception as e:
            raise ValueError(f"Authentication failed: {e}")
        self._google_k8s_config = config.google_k8s_config
        self.service_account = self._google_k8s_config.service_account
        self.cluster_name = self._google_k8s_config.cluster_name
        self.location = self._google_k8s_config.location
        self.benchmark_bucket = self._google_k8s_config.benchmark_bucket
        self.workspace_bucket = self._google_k8s_config.workspace_bucket
        self.gpu_type = self._google_k8s_config.gpu_type
        self.gpu_count = self._google_k8s_config.gpu_count

        # Load and validate Kubernetes configuration
        if self.config.kubernetes is None:
            raise ValueError(
                'Kubernetes configuration is required when using GoogleKubernetesRuntime. '
                'Please add a [kubernetes] section to your configuration.'
            )

        GoogleKubernetesRuntime._namespace = 'default'
        # Initialize ports with default values in the required range
        self._container_port = 8080  # Default internal container port
        self._vscode_port = 8081  # Default VSCode port.
        self._app_ports: list[int] = [
            30082,
            30083,
        ]  # Default app ports in valid range # The agent prefers these when exposing an application.

        self.k8s_client, self.k8s_networking_client = self._init_kubernetes_client()

        self.pod_image = self.config.sandbox.runtime_container_image
        if not self.pod_image:
            # If runtime_container_image isn't set, use the base_container_image as a fallback
            self.pod_image = self.config.sandbox.base_container_image
        if self._google_k8s_config.pod_name:
            self.pod_name = self._google_k8s_config.pod_name
        else:
            self.pod_name = POD_NAME_PREFIX + sid
        # Initialize the API URL with the initial port value
        self._node_port = None
        self._node_ip = None
        self.k8s_local_url = f'http://{self._get_svc_name(self.pod_name)}'
        self.api_url = None
        super().__init__(
            config,
            event_stream,
            sid,
            plugins,
            env_vars,
            status_callback,
            attach_to_existing,
            headless_mode,
            user_id,
            git_provider_tokens,
        )

    @staticmethod
    def _get_svc_name(pod_name: str) -> str:
        """Get the service name for the pod."""
        return f'{pod_name}-svc'

    @staticmethod
    def _get_vscode_svc_name(pod_name: str) -> str:
        """Get the VSCode service name for the pod."""
        return f'{pod_name}-svc-code'

    @staticmethod
    def _get_vscode_ingress_name(pod_name: str) -> str:
        """Get the VSCode ingress name for the pod."""
        return f'{pod_name}-ingress-code'

    @staticmethod
    def _get_vscode_tls_secret_name(pod_name: str) -> str:
        """Get the TLS secret name for the VSCode ingress."""
        return f'{pod_name}-tls-secret'

    @staticmethod
    def _get_pvc_name(pod_name: str) -> str:
        """Get the PVC name for the pod."""
        return f'{pod_name}-pvc'

    @staticmethod
    def _get_pod_name(sid: str) -> str:
        """Get the pod name for the session."""
        return POD_NAME_PREFIX + sid

    @property
    def action_execution_server_url(self):
        return self.api_url

    def _get_gcs_fuse_volumes(self):
        """创建 GCS FUSE CSI 卷配置"""

        benchmark = self.benchmark_bucket
        workspace = self.workspace_bucket
        volumes = []
        volume_mounts = []
        # workspace   bucket/task/sota_project/sid
        workspace_bucket, sota_path = workspace.split('/', 1)
        if benchmark:
            sota_path = sota_path.rstrip('/') + '/' + self.sid
        self._create_gcs_directory(workspace_bucket, sota_path)

        # 如果有子目录，添加到 volume_attributes 中
        workspace_volume, workspace_mount = self._generate_volume_mount(workspace_bucket,
                                                                        self.config.workspace_mount_path_in_sandbox,
                                                                        sota_path)
        volumes.append(workspace_volume)
        volume_mounts.append(workspace_mount)
        # benchmark bucket/task
        if benchmark:
            benchmark_bucket, task = benchmark.split('/', 1)
            self._copy_gcs_directory(benchmark_bucket, task, workspace_bucket, sota_path)

        return volumes, volume_mounts

    def _copy_gcs_directory(self,
                            source_bucket_name: str,
                            source_prefix: str,
                            dest_bucket_name: str,
                            dest_prefix: str
                            ):
        """
        把 source_bucket 下 source_prefix 下的所有对象复制到 dest_bucket 下 dest_prefix 下

        Args:
            source_bucket_name: 源 bucket 名称
            source_prefix: 源目录路径，例如 "mydir/subdir/"（最好以 / 结尾）
            dest_bucket_name: 目标 bucket 名称
            dest_prefix: 目标目录路径，例如 "backup/subdir/"（最好以 / 结尾）
        """
        client = storage.Client()

        source_bucket = client.bucket(source_bucket_name)
        dest_bucket = client.bucket(dest_bucket_name)

        # 确保 prefix 以 / 结尾
        if not source_prefix.endswith("/"):
            source_prefix += "/"
        if not dest_prefix.endswith("/"):
            dest_prefix += "/"

        blobs = client.list_blobs(source_bucket, prefix=source_prefix)
        for blob in blobs:
            # 去掉前缀，得到相对路径
            relative_path = blob.name[len(source_prefix):]
            if not relative_path:  # 避免复制“空目录”对象
                continue

            # 目标对象路径
            dest_blob_name = f"{dest_prefix}{relative_path}"

            # 拷贝
            source_bucket.copy_blob(blob, dest_bucket, dest_blob_name)
            print(f"Copied gs://{source_bucket_name}/{blob.name} -> gs://{dest_bucket_name}/{dest_blob_name}")

    def _generate_volume_mount(self, bucket_name, volume_name, subdirectory):
        """<UNK> <UNK> <UNK> <UNK> <UNK> <UNK> <UNK>"""
        mount_opts = ["implicit-dirs", "uid=1000", "gid=1000"]
        if subdirectory:
            mount_opts.append(f"only-dir={subdirectory}")
        volume_attributes = {
            "bucketName": bucket_name,
            "mountOptions": ",".join(mount_opts),
        }
        # 创建 CSI 卷
        gcs_volume_name = volume_name.replace('_', '-')
        if gcs_volume_name.startswith('/'):
            volume_name = volume_name[1:]
        gcs_volume_name = volume_name.split('/')[0]
        volume = V1Volume(
            name=f"gcs-{gcs_volume_name}-volume",
            csi=V1CSIVolumeSource(
                driver="gcsfuse.csi.storage.gke.io",
                read_only=False,
                volume_attributes=volume_attributes
            )
        )
        # 创建卷挂载
        volume_mount = V1VolumeMount(
            name=f"gcs-{gcs_volume_name}-volume",
            mount_path=f"/{volume_name}"
        )
        return volume, volume_mount

    def _create_gcs_directory(self, bucket_name: str, directory_path: str):
        """在 GCS bucket 里创建一个‘目录’"""
        if not directory_path.endswith("/"):
            directory_path += "/"

        client = storage.Client()
        bucket = client.bucket(bucket_name)

        # 上传一个空的 blob
        blob = bucket.blob(directory_path)
        blob.upload_from_string(b"")

    @property
    def node_selector(self) -> dict[str, str] | None:
        if (
                not self._google_k8s_config.node_selector_key
                or not self._google_k8s_config.node_selector_val
        ):
            return None
        return {self._google_k8s_config.node_selector_key: self._google_k8s_config.node_selector_val}

    @property
    def tolerations(self) -> list[V1Toleration] | None:
        if not self._google_k8s_config.tolerations_yaml:
            return None
        tolerations_yaml_str = self._google_k8s_config.tolerations_yaml
        tolerations = []
        try:
            tolerations_data = yaml.safe_load(tolerations_yaml_str)
            if isinstance(tolerations_data, list):
                for toleration in tolerations_data:
                    tolerations.append(V1Toleration(**toleration))
            else:
                logger.error(
                    f'Invalid tolerations format. Should be type list: {tolerations_yaml_str}. Expected a list.'
                )
                return None
        except yaml.YAMLError as e:
            logger.error(
                f'Error parsing tolerations YAML: {tolerations_yaml_str}. Error: {e}'
            )
            return None
        return tolerations

    async def connect(self):
        """Connect to the runtime by creating or attaching to a pod."""
        self.log('info', f'Connecting to runtime with conversation ID: {self.sid}')
        self.log('info', f'self._attach_to_existing: {self.attach_to_existing}')
        self.set_runtime_status(RuntimeStatus.STARTING_RUNTIME)
        self.log('info', f'Using API URL {self.api_url}')

        try:
            await call_sync_from_async(self._attach_to_pod)
        except client.rest.ApiException as e:
            # we are not set to attach to existing, ignore error and init k8s resources.
            if self.attach_to_existing:
                self.log(
                    'error',
                    f'Pod {self.pod_name} not found or cannot connect to it.',
                )
                raise AgentRuntimeDisconnectedError from e

            self.log('info', f'Starting runtime with image: {self.pod_image}')
            try:
                await call_sync_from_async(self._init_k8s_resources)
                self.log(
                    'info',
                    f'Pod started: {self.pod_name}. VSCode URL: {self.vscode_url}',
                )
            except Exception as init_error:
                self.log('error', f'Failed to initialize k8s resources: {init_error}')
                raise AgentRuntimeNotFoundError(
                    f'Failed to initialize kubernetes resources: {init_error}'
                ) from init_error
        # 等待 LoadBalancer 分配公网 IP
        external_ip = None
        for _ in range(30):  # 最多等 30 次 * 10s = 5 分钟
            svc = self.k8s_client.read_namespaced_service(
                name=self._get_svc_name(self.pod_name),
                namespace=self._namespace
            )
            if svc.status.load_balancer and svc.status.load_balancer.ingress:
                external_ip = svc.status.load_balancer.ingress[0].ip
                break
            self.log('info', 'Waiting for LoadBalancer external IP...')
            time.sleep(10)

        if not external_ip:
            raise TimeoutError("LoadBalancer did not get an external IP in time")

        self.api_url = f'http://{external_ip}:{self._container_port}'
        self.log('info', f'Runtime external API URL: {self.api_url}')
        if not self.attach_to_existing:
            self.log('info', 'Waiting for pod to become ready ...')
            self.set_runtime_status(RuntimeStatus.STARTING_RUNTIME)
        try:
            await call_sync_from_async(self._wait_until_ready)
        except Exception as alive_error:
            self.log('error', f'Failed to connect to runtime: {alive_error}')
            self.send_error_message(
                'ERROR$RUNTIME_CONNECTION',
                f'Failed to connect to runtime: {alive_error}',
            )
            raise AgentRuntimeDisconnectedError(
                f'Failed to connect to runtime: {alive_error}'
            ) from alive_error
        if not self.attach_to_existing:
            self.log('info', 'Runtime is ready.')

        if not self.attach_to_existing:
            await call_sync_from_async(self.setup_initial_env)

        self.log(
            'info',
            f'Pod initialized with plugins: {[plugin.name for plugin in self.plugins]}. VSCode URL: {self.vscode_url}',
        )
        if not self.attach_to_existing:
            self.set_runtime_status(RuntimeStatus.READY)
        self._runtime_initialized = True

    def _attach_to_pod(self):
        """Attach to an existing pod."""
        try:
            pod = self.k8s_client.read_namespaced_pod(
                name=self.pod_name, namespace=self._namespace
            )

            if pod.status.phase != 'Running':
                try:
                    self._wait_until_ready()
                except TimeoutError:
                    raise AgentRuntimeDisconnectedError(
                        f'Pod {self.pod_name} exists but failed to become ready.'
                    )

            self.log('info', f'Successfully attached to pod {self.pod_name}')
            return True

        except client.rest.ApiException as e:
            self.log('info', f'Failed to attach to pod: {self.pod_name}')
            raise

    @tenacity.retry(
        stop=tenacity.stop_after_delay(300) | stop_if_should_exit(),
        retry=tenacity.retry_if_exception_type(TimeoutError),
        reraise=True,
        wait=tenacity.wait_fixed(2),
    )
    def _wait_until_ready(self):
        """Wait until the runtime server is alive by checking the pod status in Kubernetes."""
        self.log('info', f'Checking if pod {self.pod_name} is ready in Kubernetes')
        pod = self.k8s_client.read_namespaced_pod(
            name=self.pod_name, namespace=self._namespace
        )
        if pod.status.phase == 'Running' and pod.status.conditions:
            for condition in pod.status.conditions:
                if condition.type == 'Ready' and condition.status == 'True':
                    self.log('info', f'Pod {self.pod_name} is ready!')
                    return True  # Exit the function if the pod is ready

        self.log(
            'info',
            f'Pod {self.pod_name} is not ready yet. Current phase: {pod.status.phase}',
        )
        raise TimeoutError(f'Pod {self.pod_name} is not in Running state yet.')

    @lru_cache(maxsize=1)
    def _init_kubernetes_client(self) -> tuple[client.CoreV1Api, client.NetworkingV1Api]:
        """Initialize the Kubernetes client for GKE."""
        try:
            # Try different authentication methods for GKE
            gke_client = container_v1.ClusterManagerClient()

            # Get cluster info
            cluster_path = f"projects/{self.project_id}/locations/{self.location}/clusters/{self.cluster_name}"
            cluster = gke_client.get_cluster(name=cluster_path)

            # Configure Kubernetes client
            config.load_kube_config()
            # First try: Use kubeconfig file (for local development)
            logger.info("Loaded Kubernetes configuration from kubeconfig file")

            # Test the connection
            v1 = client.CoreV1Api()
            v1.list_namespaced_pod(namespace="default", limit=1)

            return client.CoreV1Api(), client.NetworkingV1Api()
        except Exception as ex:
            logger.error(
                'Failed to initialize Kubernetes client for GKE. '
                'Make sure you have: '
                '1) gcloud CLI installed and configured '
                '2) kubectl configured to connect to your GKE cluster '
                '3) Appropriate permissions in GKE cluster',
            )
            raise ex

    def _cleanup_k8s_resources(self,
                               namespace: str, remove_pvc: bool = False, conversation_id: str = ''
                               ):
        """Clean up Kubernetes resources with our prefix in the namespace.

        :param remove_pvc: If True, also remove persistent volume claims (defaults to False).
        """
        try:
            k8s_api, k8s_networking_api = self._init_kubernetes_client()

            pod_name = GoogleKubernetesRuntime._get_pod_name(conversation_id)
            service_name = GoogleKubernetesRuntime._get_svc_name(pod_name)
            vscode_service_name = GoogleKubernetesRuntime._get_vscode_svc_name(pod_name)
            ingress_name = GoogleKubernetesRuntime._get_vscode_ingress_name(pod_name)
            pvc_name = GoogleKubernetesRuntime._get_pvc_name(pod_name)

            try:
                if remove_pvc:
                    # Delete PVC if requested
                    k8s_api.delete_namespaced_persistent_volume_claim(
                        name=pvc_name,
                        namespace=namespace,
                        body=client.V1DeleteOptions(),
                    )
                    logger.info(f'Deleted PVC {pvc_name}')

                k8s_api.delete_namespaced_pod(
                    name=pod_name,
                    namespace=namespace,
                    body=client.V1DeleteOptions(),
                )
                logger.info(f'Deleted pod {pod_name}')

                k8s_api.delete_namespaced_service(
                    name=service_name,
                    namespace=namespace,
                )
                logger.info(f'Deleted service {service_name}')
                # Delete the vs code service
                k8s_api.delete_namespaced_service(
                    name=vscode_service_name, namespace=namespace
                )
                logger.info(f'Deleted service {vscode_service_name}')

                k8s_networking_api.delete_namespaced_ingress(
                    name=ingress_name, namespace=namespace
                )
                logger.info(f'Deleted ingress {ingress_name}')
            except client.rest.ApiException as e:
                if e.status != 404:  # Ignore not found errors
                    logger.error(f'Error deleting resource: {e}')
            logger.info('Cleaned up Kubernetes resources')
        except Exception as e:
            logger.error(f'Error cleaning up k8s resources: {e}')

    def _get_pvc_manifest(self):
        """Create a PVC manifest for GKE."""
        # For GKE, use standard storage classes
        storage_class = self._google_k8s_config.pvc_storage_class or "standard"  # standard, premium, or standard-rwo for GKE

        pvc = V1PersistentVolumeClaim(
            api_version='v1',
            kind='PersistentVolumeClaim',
            metadata=V1ObjectMeta(
                name=self._get_pvc_name(self.pod_name),
                namespace=self._namespace,
                annotations={
                    # GKE specific annotations if needed
                }
            ),
            spec=V1PersistentVolumeClaimSpec(
                access_modes=['ReadWriteOnce'],
                resources=V1ResourceRequirements(
                    requests={'storage': self._google_k8s_config.pvc_storage_size or "10Gi"}
                ),
                storage_class_name=storage_class,
            ),
        )

        return pvc

    def _get_vscode_service_manifest(self):
        """Create a service manifest for the VSCode server."""
        vscode_service_spec = V1ServiceSpec(
            selector={'app': POD_LABEL, 'session': self.sid},
            type='LoadBalancer',  # Use ClusterIP for internal access
            ports=[
                V1ServicePort(
                    port=self._vscode_port,
                    target_port='vscode',
                    name='code',
                )
            ],
        )

        vscode_service = V1Service(
            metadata=V1ObjectMeta(
                name=self._get_vscode_svc_name(self.pod_name),
                namespace=self._namespace
            ),
            spec=vscode_service_spec,
        )
        return vscode_service

    def _get_runtime_service_manifest(self):
        """Create a LoadBalancer service manifest for the runtime pod execution-server."""
        service_spec = V1ServiceSpec(
            selector={'app': POD_LABEL, 'session': self.sid},
            type='LoadBalancer',  # 使用 LoadBalancer 自动分配公网 IP
            ports=[
                V1ServicePort(
                    port=self._container_port,  # Service 对外端口
                    target_port='http',  # Pod 内部端口
                    name='execution-server',
                )
            ],
        )

        service = V1Service(
            metadata=V1ObjectMeta(
                name=self._get_svc_name(self.pod_name),
                namespace=self._namespace
            ),
            spec=service_spec,
        )
        return service

    def _get_assigned_node_port(self):
        """获取自动分配的 NodePort"""
        service_name = self._get_svc_name(self.pod_name)

        try:
            service = self.k8s_client.read_namespaced_service(
                name=service_name,
                namespace=self._namespace
            )

            if service.spec.ports and service.spec.ports[0].node_port:
                node_port = service.spec.ports[0].node_port
                self.log('info', f'Assigned NodePort: {node_port}')
                return node_port
            else:
                raise Exception("NodePort not yet assigned")

        except Exception as e:
            self.log('error', f'Error getting NodePort: {e}')
            return None

    def _get_node_external_ip(self):
        """获取节点的外部IP"""
        try:
            nodes = self.k8s_client.list_node()

            for node in nodes.items:
                for address in node.status.addresses:
                    if address.type == 'ExternalIP':
                        self.log('info', f'Found node ExternalIP: {address.address}')
                        return address.address

            # 如果没有ExternalIP，尝试InternalIP（可能需要VPN）
            for node in nodes.items:
                for address in node.status.addresses:
                    if address.type == 'InternalIP':
                        self.log('info', f'Using node InternalIP: {address.address}')
                        return address.address

            raise Exception("No node IP address found")

        except Exception as e:
            self.log('error', f'Error getting node IP: {e}')
            return None

    def _wait_for_nodeport_assignment(self, timeout=60):
        """等待NodePort分配完成"""
        start_time = time.time()

        while time.time() - start_time < timeout:
            node_port = self._get_assigned_node_port()
            if node_port:
                return node_port

            self.log('info', 'Waiting for NodePort assignment...')
            time.sleep(2)

        raise TimeoutError("NodePort not assigned within timeout")

    def get_external_access_url(self):
        """获取外部访问的完整URL"""
        node_ip = self._get_node_external_ip()
        if not node_ip:
            raise Exception("Cannot get node external IP")

        node_port = self._wait_for_nodeport_assignment()
        if not node_port:
            raise Exception("Cannot get assigned NodePort")

        url = f"http://{node_ip}:{node_port}"
        self.log('info', f'External access URL: {url}')
        return url

    def _get_runtime_pod_manifest(self):
        """创建支持 GKE 功能的 Pod 配置"""
        # 基础环境变量
        environment = [
            V1EnvVar(name='port', value=str(self._container_port)),
            V1EnvVar(name='PYTHONUNBUFFERED', value='1'),
            V1EnvVar(name='VSCODE_PORT', value=str(self._vscode_port)),
        ]

        if self.config.debug or DEBUG:
            environment.append(V1EnvVar(name='DEBUG', value='true'))

        # 添加运行时启动环境变量
        for key, value in self.config.sandbox.runtime_startup_env_vars.items():
            environment.append(V1EnvVar(name=key, value=value))

        # 准备卷挂载 - 支持 GCS FUSE 和传统 PVC
        volume_mounts = []
        volumes = []

        # 添加 GCS FUSE 卷（如果配置了）
        if self.benchmark_bucket != "" and self.workspace_bucket != "":
            gcs_volumes, gcs_volume_mounts = self._get_gcs_fuse_volumes()
            volumes.extend(gcs_volumes)
            volume_mounts.extend(gcs_volume_mounts)

        # 添加传统 PVC 卷（如果配置了 PVC）
        if self._google_k8s_config.pvc_storage_class:
            volume_mounts.append(V1VolumeMount(
                name='workspace-volume',
                mount_path=self.config.workspace_mount_path_in_sandbox,
            ))
            volumes.append(V1Volume(
                name='workspace-volume',
                persistent_volume_claim=V1PersistentVolumeClaimVolumeSource(
                    claim_name=self._get_pvc_name(self.pod_name)
                ),
            ))

        # 容器端口配置
        container_ports = [
            V1ContainerPort(container_port=self._container_port, name='http'),
        ]

        if self.vscode_enabled:
            container_ports.append(
                V1ContainerPort(container_port=self._vscode_port, name='vscode')
            )

        for port in self._app_ports:
            container_ports.append(V1ContainerPort(container_port=port))

        # 健康检查
        health_check = client.V1Probe(
            http_get=client.V1HTTPGetAction(
                path='/alive',
                port=self._container_port,
            ),
            initial_delay_seconds=10,
            period_seconds=15,
            timeout_seconds=5,
            success_threshold=1,
            failure_threshold=5,
        )

        # 启动命令
        command = get_action_execution_server_startup_command(
            server_port=self._container_port,
            plugins=self.plugins,
            app_config=self.config,
            override_user_id=0,
            override_username='root',
        )
        if self.config.sandbox.enable_gpu and self.gpu_count > 0:
            # 有 GPU 时可以使用更多存储
            ephemeral_storage_limit = '200Gi'
            ephemeral_storage_request = '100Gi'
        else:
            # 无 GPU 时遵守 Autopilot 10Gi 限制
            ephemeral_storage_limit = '10Gi'  # 留一些余量
            ephemeral_storage_request = '5Gi'  # 最小请求

        # 资源配置 - 支持 GPU
        resources_dict = {
            'limits': {
                'memory': self._google_k8s_config.resource_memory_limit or '8Gi',
                'ephemeral-storage': ephemeral_storage_limit
            },
            'requests': {
                'memory': self._google_k8s_config.resource_memory_request or '4Gi',
                'cpu': self._google_k8s_config.resource_cpu_request or '4',
                'ephemeral-storage': ephemeral_storage_request
            }
        }

        # 添加 GPU 资源（如果配置了）
        if self.config.sandbox.enable_gpu and self.gpu_count > 0:
            gpu_resource_name = f"nvidia.com/gpu"
            resources_dict['limits'][gpu_resource_name] = self.gpu_count
            resources_dict['requests'][gpu_resource_name] = self.gpu_count

        resources = V1ResourceRequirements(**resources_dict)

        # 安全上下文
        security_context = V1SecurityContext(
            run_as_user=0,
            run_as_group=0,
            allow_privilege_escalation=False,
        )

        # 创建容器
        container = V1Container(
            name='runtime',
            image=self.pod_image,
            command=command,
            env=environment,
            ports=container_ports,
            volume_mounts=volume_mounts,
            working_dir='/openhands/code/',
            resources=resources,
            readiness_probe=health_check,
            security_context=security_context,
        )

        # Pod 安全上下文
        pod_security_context = client.V1PodSecurityContext(
            run_as_user=0,
            run_as_group=0,
            fs_group=1000,  # 匹配 GCS FUSE 的 gid
        )

        # Pod 规格参数
        pod_spec_kwargs = {
            "containers": [container],
            "volumes": volumes,
            "restart_policy": "Never",
            "security_context": pod_security_context,
            "automount_service_account_token": False,
        }

        # 添加服务账户（如果配置了）
        if self.service_account:
            pod_spec_kwargs["service_account_name"] = self.service_account

        # 添加节点选择器（GPU 节点选择）
        node_selector = {}
        if self.node_selector:
            node_selector.update(self.node_selector)
        if self.config.sandbox.enable_gpu:
            node_selector["cloud.google.com/gke-accelerator"] = self.gpu_type
        if node_selector:
            pod_spec_kwargs["node_selector"] = node_selector

        # 添加容忍度
        if self.tolerations:
            pod_spec_kwargs["tolerations"] = self.tolerations

        # 创建 Pod 定义
        pod = V1Pod(
            metadata=V1ObjectMeta(
                name=self.pod_name,
                namespace=self._namespace,
                labels={
                    'app': POD_LABEL,
                    'session': self.sid,
                    'environment': 'openhands'
                },
                annotations={
                    'gke-gcsfuse/volumes': 'true'
                }
            ),
            spec=V1PodSpec(**pod_spec_kwargs),
        )

        return pod

    def _get_vscode_ingress_manifest(self):
        """Create an ingress manifest optimized for GKE."""
        # GKE Ingress annotations
        annotations = {
            'kubernetes.io/ingress.class': 'gce',  # GCE ingress controller
            'networking.gke.io/v1beta1.FrontendConfig': 'frontend-config' if self._google_k8s_config.ingress_tls_secret else '',
        }

        if self._google_k8s_config.ingress_tls_secret:
            annotations.update({
                'networking.gke.io/managed-certificates': self._google_k8s_config.ingress_tls_secret,
                'kubernetes.io/ingress.allow-http': 'false',  # Force HTTPS
            })

        tls = []
        if self._google_k8s_config.ingress_tls_secret:
            tls = [V1IngressTLS(
                hosts=[self.ingress_domain],
                secret_name=self._google_k8s_config.ingress_tls_secret,
            )]

        rules = [
            V1IngressRule(
                host=self.ingress_domain,
                http=V1HTTPIngressRuleValue(
                    paths=[
                        V1HTTPIngressPath(
                            path='/*',  # GKE ingress path pattern
                            path_type='ImplementationSpecific',
                            backend=V1IngressBackend(
                                service=V1IngressServiceBackend(
                                    port=V1ServiceBackendPort(
                                        number=self._vscode_port,
                                    ),
                                    name=self._get_vscode_svc_name(self.pod_name),
                                )
                            ),
                        )
                    ]
                ),
            )
        ]

        ingress_spec = V1IngressSpec(rules=rules, tls=tls)

        ingress = V1Ingress(
            api_version='networking.k8s.io/v1',
            kind='Ingress',
            metadata=V1ObjectMeta(
                name=self._get_vscode_ingress_name(self.pod_name),
                namespace=self._namespace,
                annotations=annotations,
            ),
            spec=ingress_spec,
        )

        return ingress

    def _pvc_exists(self):
        """Check if the PVC already exists."""
        try:
            pvc = self.k8s_client.read_namespaced_persistent_volume_claim(
                name=self._get_pvc_name(self.pod_name),
                namespace=self._namespace
            )
            return pvc is not None
        except client.rest.ApiException as e:
            if e.status == 404:
                return False
            self.log('error', f'Error checking PVC existence: {e}')
            raise

    def _init_k8s_resources(self):
        """Initialize the Kubernetes resources for GKE."""
        self.log('info', 'Preparing to start pod in GKE...')
        self.set_runtime_status(RuntimeStatus.STARTING_RUNTIME)

        pod = self._get_runtime_pod_manifest()
        service = self._get_runtime_service_manifest()
        vscode_service = self._get_vscode_service_manifest()
        # pvc_manifest = self._get_pvc_manifest()
        ingress = self._get_vscode_ingress_manifest()

        try:
            # if not self._pvc_exists():
            #     self.k8s_client.create_namespaced_persistent_volume_claim(
            #         namespace=self._namespace, body=pvc_manifest
            #     )
            #     self.log('info', f'Created PVC {self._get_pvc_name(self.pod_name)}')

            self.k8s_client.create_namespaced_pod(
                namespace=self._namespace, body=pod
            )
            self.log('info', f'Created pod {self.pod_name}.')

            # 创建 LoadBalancer Service
            # self.k8s_client.create_namespaced_service(
            #     namespace=self._namespace, body=service
            # )
            try:
                self.k8s_client.create_namespaced_service(
                    namespace=self._namespace,
                    body=service
                )
                self.log('info', f'Created service {self.pod_name}.')
            except kubernetes.client.exceptions.ApiException as e:
                if e.status == 409:  # 冲突错误，Service 已存在
                    self.log('info', f'Service {self.pod_name} already exists, updating...')
                    self.k8s_client.replace_namespaced_service(
                        name=self._get_svc_name(self.pod_name),
                        namespace=self._namespace,
                        body=service
                    )
                    self.log('info', f'Updated service {self.pod_name}.')
                else:
                    raise

            self.log('info', f'Created LoadBalancer service {self._get_svc_name(self.pod_name)}')
            # 创建 VSCode Service
            try:
                self.k8s_client.create_namespaced_service(
                    namespace=self._namespace,
                    body=vscode_service
                )
                self.log('info', f'Created vs_code {self._get_vscode_svc_name(self.pod_name)}.')
            except kubernetes.client.exceptions.ApiException as e:
                if e.status == 409:  # 冲突错误，Service 已存在
                    self.log('info',
                             f'vscode_service {self._get_vscode_svc_name(self.pod_name)} already exists, updating...')
                    self.k8s_client.replace_namespaced_service(
                        name=self._get_vscode_svc_name(self.pod_name),
                        namespace=self._namespace,
                        body=vscode_service
                    )
                    self.log('info', f'Updated vscode_service {self._get_vscode_svc_name(self.pod_name)}.')
                else:
                    raise
            if self.vscode_enabled:
                self.k8s_networking_client.create_namespaced_ingress(
                    namespace=self._namespace, body=ingress
                )
                self.log('info', f'Created ingress {self._get_vscode_ingress_name(self.pod_name)}')

            self._wait_until_ready()

        except client.rest.ApiException as e:
            self.log('error', f'Failed to create resources in GKE: {e}')
            self._cleanup_k8s_resources(namespace=self._namespace, remove_pvc=True, conversation_id=self.sid)
            raise

    @tenacity.retry(
        stop=tenacity.stop_after_delay(120) | stop_if_should_exit(),
        retry=tenacity.retry_if_exception(_is_retryablewait_until_alive_error),
        reraise=True,
        wait=tenacity.wait_fixed(2),
    )
    def reset(self) -> None:
        self._send_action_server_request(
            'GET',
            f'{self.action_execution_server_url}/reset',
            timeout=30,
        )

    def get_config(self):
        response = self._send_action_server_request(
            'GET',
            f'{self.action_execution_server_url}/get_config',
            timeout=30,
        )
        return response

    def cleanup_k8s_resources(self):
        self._cleanup_k8s_resources(
            namespace=self._namespace,
            remove_pvc=False,  # Keep PVC by default to preserve data
            conversation_id=self.sid,
        )

    def close(self):
        """Close the runtime and clean up resources."""
        self.log(
            'info',
            f'Closing runtime and cleaning up resources for conversation ID: {self.sid}',
        )
        # Call parent class close method first
        # super().close()

        # Return early if we should keep the runtime alive or if we're attaching to existing
        if self.config.sandbox.keep_runtime_alive or self.attach_to_existing:
            self.log(
                'info', 'Keeping runtime alive due to configuration or attach mode'
            )
            return

        try:
            self.log("info", f'Cleaning up resources for conversation ID: {self.sid}')
            # self._cleanup_k8s_resources(
            #     namespace=self._namespace,
            #     remove_pvc=False,  # Keep PVC by default to preserve data
            #     conversation_id=self.sid,
            # )
        except Exception as e:
            self.log('error', f'Error closing runtime: {e}')

    @property
    def ingress_domain(self) -> str:
        """Get the ingress domain for the runtime."""
        if not self._google_k8s_config.ingress_domain:
            # Default to GKE's default domain pattern if not specified
            return f'{self.sid}.nip.io'  # Using nip.io for testing
        return f'{self.sid}.{self._google_k8s_config.ingress_domain}'

    @property
    def vscode_url(self) -> str | None:
        """Get the URL for VSCode server if enabled."""
        if not self.vscode_enabled:
            return None
        token = super().get_vscode_token()
        if not token:
            return None

        protocol = 'https' if self._google_k8s_config.ingress_tls_secret else 'http'
        vscode_url = f'{protocol}://{self.ingress_domain}/?tkn={token}&folder={self.config.workspace_mount_path_in_sandbox}'
        self.log('info', f'VSCode URL: {vscode_url}')
        return vscode_url

    @property
    def web_hosts(self) -> dict[str, int]:
        """Get web hosts dict mapping for browser access."""
        hosts = {}
        for idx, port in enumerate(self._app_ports):
            hosts[f'{self.k8s_local_url}:{port}'] = port
        return hosts


@classmethod
async def delete(cls, conversation_id: str):
    """Delete resources associated with a conversation."""
    try:
        cls._cleanup_k8s_resources(
            namespace=cls._namespace,
            remove_pvc=True,  # Remove PVC when explicitly deleting
            conversation_id=conversation_id,
        )
    except Exception as e:
        logger.error(
            f'Error deleting resources for conversation {conversation_id}: {e}'
        )
