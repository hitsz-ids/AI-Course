from litellm.types.llms.openai import ChatCompletionToolParam, ChatCompletionToolParamFunctionChunk

_PYTHON_TRACKING_DESCRIPTION = """
This tool enables the tracking and recording of function calls within a Python program, offering detailed insights into program execution.

### Key Features:
- **Code Insertion**: Automatically inserts tracking code at the start of the provided Python entry file. This initialization sets up the tracking mechanism to monitor all function calls during the program's execution.

- **Function Call Graph**: As the program runs, the tool generates a dynamic function call graph. This graph provides a visual representation of the sequence and flow of function calls throughout the program.

### Example:

Given a file, `/path/to/run.py`, with the following content:

**Example
For example, given an file `/path/to/run.py` that looks like this:
1|class MyClass:
2|    def __init__(self):
3|        self.x = 1
4|        self.y = 2
5|        self.z = 3

To track and record the function calls in this program, the assistant inserts the trace code like this:

1|import os
2|from callgraph_tool import EnhancedCallGraphBuilder
3|
4|tracer = EnhancedCallGraphBuilder(project_root=os.getcwd())
5|tracer.start_tracing()
6|try:
7|    class MyClass:
8|        def __init__(self):
9|            self.x = 1
10|            self.y = 2
11|            self.z = 3
12|finally:
13|    tracer.stop_tracing()
14|    output_dir = '/workspace/output-graph/{repository_name}'  # 单花括号
15|    from datetime import datetime
16|    # 获取当前时间
17|    current_time = datetime.now()
18|    # 格式化为 "年_月_日_时_分"
19|    formatted_time = current_time.strftime("%Y_%m_%d_%H_%M")
20|    if not os.path.exists(output_dir):
21|        os.makedirs(output_dir)
22|    output_file_path = output_dir + '/call_graph_temp_{repository_name}' + formatted_time + '.json'
23|    tracer.save_graph(output_file_path)
"""

PythonTrackingTool = ChatCompletionToolParam(
    type='function',
    function=ChatCompletionToolParamFunctionChunk(
        name='python_tracking',
        description=_PYTHON_TRACKING_DESCRIPTION,
        parameters={
            'type': 'object',
            'properties': {
                'path': {
                    'type': 'string',
                    'description': 'Path of the Python file to track and record function calls.',
                },
                'repository_name': {
                    'type': 'string',
                    'description': 'Name of the git repository.',
                    'default': 'tracking_output',
                },
            },
            'required': ['path'],
        },
    ),
)
