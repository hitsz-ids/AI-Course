"""Constants for tool names used in function calling."""

EXECUTE_BASH_TOOL_NAME = 'execute_bash'
EXECUTE_STREAM_BASH_TOOL_NAME = 'execute_stream_bash'
STR_REPLACE_EDITOR_TOOL_NAME = 'str_replace_editor'
BROWSER_TOOL_NAME = 'browser'
FINISH_TOOL_NAME = 'finish'
LLM_BASED_EDIT_TOOL_NAME = 'edit_file'
SEQUENTIAL_THINKING_TOOL = 'sequential_thinking_tool'
