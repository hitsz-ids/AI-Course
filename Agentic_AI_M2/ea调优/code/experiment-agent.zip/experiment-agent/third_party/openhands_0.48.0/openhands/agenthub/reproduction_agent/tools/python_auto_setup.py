from litellm.types.llms.openai import ChatCompletionToolParam, ChatCompletionToolParamFunctionChunk

_PYTHON_AUTO_SETUP_DESCRIPTION = """
Tool Description: Automated Conda Environment Setup

This tool is used **only for creating Conda environments**, not for installing Python packages or dependencies.

- Purpose:
    - Analyze dependency files (`requirements.txt`, `environment.yml`, `pyproject.toml`) **only to determine the appropriate Python version**.
    - Automatically create an isolated Conda environment using that Python version.

- Behavior:
    - The tool **does not install any project dependencies** listed in the files.
    - It only installs the corresponding **Python interpreter** inside the Conda environment.
    - The created environment provides isolated binaries:
      - `/opt/conda/envs/{env_name}/bin/python`
      - `/opt/conda/envs/{env_name}/bin/pip`

- Requirements:
    - **Dependency File Validation**
       - `dependency_file_path` must point to an existing `.txt` or `.yml` file.
       - The path must be absolute and accessible.
       - The file is parsed **only for Python version detection**.
    
    - **Environment Naming**
       - `env_name` should be descriptive (usually matching the project name).
       - Must be unique within the same namespace.
       - This name will identify and activate the Conda environment.

    - **Namespace Selection**
       - Use only the predefined namespace values:
         - `"project"` — for development environments.
         - `"evaluation"` — for testing or evaluation environments.
       - Do **not** use custom namespace values.

    - **Python Version Specification**
       - If a Python version is explicitly specified in the dependency file or README, it will be used.
       - If not specified, the tool will automatically infer the best-fit Python version.
       - Only the specified Python interpreter will be installed—**no additional dependencies**.

- Output:
    - Create a new Conda environment located at `/opt/conda/envs/{env_name}/`
    - Provide a ready-to-use isolated Python interpreter
    - Not perform any dependency installation (`pip install` or `conda install`)

- Reminder:
    - This tool’s sole purpose is to set up a clean Conda environment with the correct Python version.  
    - It does not handle dependency installation.
"""

PythonAutoSetupTool = ChatCompletionToolParam(
    type='function',
    function=ChatCompletionToolParamFunctionChunk(
        name='python_auto_setup',
        description=_PYTHON_AUTO_SETUP_DESCRIPTION,
        parameters={
            'type': 'object',
            'properties': {
                'dependency_file_path': {
                    'type': 'string',
                    'description': 'Absolute path to dependency file (e.g., /workspace/requirements.txt). Currently only supports .txt and .yml files.',
                },
                'env_name': {
                    'type': 'string',
                    'description': 'Name of the Python virtual environment to create.',
                },
                'python_version': {
                    'type': 'string',
                    'description': 'Python version from README or dependency info. Leave blank if not specified.',
                },
                'namespace': {
                    'type': 'string',
                    'enum': ['project', 'evaluation'],
                    'description': 'Environment type: `project` for standard projects environment, `evaluation` for evaluation projects environment.'
                }
            },
            'required': ['dependency_file_path', 'env_name', 'namespace'],
        },
    ),
)