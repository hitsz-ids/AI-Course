from pydantic import BaseModel, ConfigDict, Field, ValidationError

WORKSPACE_BUCKET = 'experiment_agent_workspace'
SOW_BENCHMARK_BUCKET = 'mlrc_bench_sow'


class GoogleKubernetesConfig(BaseModel):
    """Configuration for Kubernetes runtime.

    Attributes:
        namespace: The Kubernetes namespace to use for OpenHands resources
        ingress_domain: Domain for ingress resources
        pvc_storage_size: Size of the persistent volume claim (e.g. "2Gi")
        pvc_storage_class: Storage class for persistent volume claims
        resource_cpu_request: CPU request for runtime pods
        resource_memory_request: Memory request for runtime pods
        resource_memory_limit: Memory limit for runtime pods
        image_pull_secret: Optional name of image pull secret for private registries
        ingress_tls_secret: Optional name of TLS secret for ingress
        node_selector_key: Optional node selector key for pod scheduling
        node_selector_val: Optional node selector value for pod scheduling
        tolerations_yaml: Optional YAML string defining pod tolerations
    """

    namespace: str = Field(
        default='default',
        description='The Kubernetes namespace to use for OpenHands resources',
    )
    ingress_domain: str = Field(
        default='localhost', description='Domain for ingress resources'
    )
    pvc_storage_size: str = Field(
        default='2Gi', description='Size of the persistent volume claim'
    )
    pvc_storage_class: str | None = Field(
        default=None, description='Storage class for persistent volume claims'
    )
    resource_cpu_request: str = Field(
        default='4', description='CPU request for runtime pods'
    )
    resource_memory_request: str = Field(
        default='8Gi', description='Memory request for runtime pods'
    )
    resource_memory_limit: str = Field(
        default='16Gi', description='Memory limit for runtime pods'
    )
    image_pull_secret: str | None = Field(
        default=None,
        description='Optional name of image pull secret for private registries',
    )
    ingress_tls_secret: str | None = Field(
        default=None, description='Optional name of TLS secret for ingress'
    )
    node_selector_key: str | None = Field(
        default=None, description='Optional node selector key for pod scheduling'
    )
    node_selector_val: str | None = Field(
        default=None, description='Optional node selector value for pod scheduling'
    )
    tolerations_yaml: str | None = Field(
        default=None, description='Optional YAML string defining pod tolerations'
    )
    privileged: bool = Field(
        default=False,
        description='Run the runtime sandbox container in privileged mode for use with docker-in-docker',
    )
    cluster_name: str | None = Field(
        default='experiment-agent', description='Cluster name to use for GKE resources'
    )
    location: str | None = Field(
        default='us-east1', description='Location to use for GKE resources'
    )
    # 新增 GKE 特定参数
    gpu_type: str | None = Field(default="nvidia-tesla-t4", description='GPU type')
    gpu_count: int = Field(default=0)
    benchmark_bucket: str = None
    workspace_bucket: str = None
    service_account: str | None = Field(default='experiment-agent-gke-service-account',
                                        description='Service account for GKE resources')
    pod_name: str = None
    model_config = ConfigDict(extra='forbid')

    @classmethod
    def from_toml_section(cls, data: dict) -> dict[str, 'GoogleKubernetesConfig']:
        """
        Create a mapping of KubernetesConfig instances from a toml dictionary representing the [kubernetes] section.

        The configuration is built from all keys in data.

        Returns:
            dict[str, KubernetesConfig]: A mapping where the key "kubernetes" corresponds to the [kubernetes] configuration
        """
        # Initialize the result mapping
        google_k8s_mapping: dict[str, GoogleKubernetesConfig] = {}

        # Try to create the configuration instance
        try:
            google_k8s_mapping['google_k8s'] = cls.model_validate(data)
        except ValidationError as e:
            raise ValueError(f'Invalid google_k8s configuration: {e}')

        return google_k8s_mapping
