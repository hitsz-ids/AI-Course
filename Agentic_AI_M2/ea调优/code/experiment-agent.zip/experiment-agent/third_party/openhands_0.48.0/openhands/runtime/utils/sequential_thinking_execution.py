import json

from openhands.events.action import SequentialThinkingAction
from openhands.events.observation import ErrorObservation
from openhands.events.observation.agent import SequentialThinkingObservation

class SequentialThinkingExecution:

    def __init__(self):
        self.thought_history: list = []
        self.branches: dict[str, list] = {}

    def execute(self, action: SequentialThinkingAction) -> SequentialThinkingObservation | ErrorObservation:
        try:
            validated_input = action
            # Validate and extract thought data
            # Adjust total thoughts if current thought number exceeds it
            if validated_input.thought_number > validated_input.total_thoughts:
                validated_input.total_thoughts = validated_input.thought_number

            # Add to thought history
            self.thought_history.append(validated_input)

            # Handle branching
            if validated_input.branch_from_thought and validated_input.branch_id:
                if validated_input.branch_id not in self.branches:
                    self.branches[validated_input.branch_id] = []
                self.branches[validated_input.branch_id].append(validated_input)

            # Format and display the thought
            # formatted_thought = self._format_thought(validated_input)
            # print(formatted_thought, flush=True)  # Print to stdout for immediate feedback

            # Prepare response
            return SequentialThinkingObservation(
                content=f"Sequential thinking step completed.\n"
                        f"[thought_number:{validated_input.thought_number}]\n"
                        f"[total_thoughts:{validated_input.total_thoughts}]\n"
                        f"[next_thought_needed:{'true' if validated_input.next_thought_needed else 'false'}]\n"
                        f"[branches:{list(self.branches.keys())}]\n"
                        f"[thought_history_length:{len(self.thought_history)}]\n"
            )

        except Exception as e:
            error_data = {"error": str(e), "status": "failed"}
            return ErrorObservation(
                content=f"Sequential thinking failed: {str(e)}\n\nDetails:\n{json.dumps(error_data, indent=2)}",
            )