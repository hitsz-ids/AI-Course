from dataclasses import dataclass

from openhands.core.schema import ObservationType
from openhands.events import EventSource
from openhands.events.observation import Observation


@dataclass
class GitRepoDownloadObservation(Observation):
    git_url: str
    observation: str = ObservationType.GIT_REPO_DOWNLOAD
    success: bool = True

    @property
    def message(self) -> str:
        return f'I get the git url: {self.git_url}.'

    def __str__(self) -> str:
        return (f'**GitRepoDownloadObservation  (source={self.source},**\n,'
                f'git url={self.git_url})**\n'
                '--BEGIN AGENT OBSERVATION--\n'
                f'{self.observation}\n'
                '--END AGENT OBSERVATION--'
                )


@dataclass
class PythonAutoSetupObservation(Observation):
    dependency_file_path: str
    env_name: str
    observation: str = ObservationType.PYTHON_AUTO_SETUP
    impl_source: EventSource = EventSource.ENVIRONMENT
    success: bool = True

    @property
    def message(self) -> str:
        return f'I get the file_path {self.dependency_file_path}.'

    def __str__(self) -> str:
        return (f'**PythonAutoSetupObservation  (source={self.source},**\n,'
                f'file_path={self.dependency_file_path})**\n'
                '--BEGIN AGENT OBSERVATION--\n'
                f'{self.observation},content={self.content}\n'
                '--END AGENT OBSERVATION--'
                )


@dataclass
class ProjectStartOutputObservation(Observation):
    """This data class represents the output of a project start."""

    command: str
    code: int = 0
    observation: str = ObservationType.PROJECT_START
    stream: bool = False
    info = str

    @property
    def message(self) -> str:
        return f'Command `{self.command}` executed with exit code {self.code}.'

    def __str__(self) -> str:
        return f'**ProjectStartOutputObservation (source={self.source}, exit_code={self.code},content={self.info})**\n'


@dataclass
class PythonTrackingObservation(Observation):
    """This data class represents the Python code execution tracking."""

    path: str
    observation: str = ObservationType.PYTHON_TRACKING

    @property
    def message(self) -> str:
        return f'Tracking the Python code execution in the file: {self.path}'

    def __str__(self) -> str:
        return f'[Tracking the Python code execution in the file: {self.path} is successful.]'


@dataclass
class ExtractCompressedFileObservation(Observation):
    """This data class represents the extracted compressed file."""

    file_path: str
    format: str
    observation: str = ObservationType.EXTRACT_COMPRESSED_FILE

    @property
    def message(self) -> str:
        return f'I extracted the compressed file {self.file_path}.'

    def __str__(self) -> str:
        return f'[Extracted from {self.file_path} is successful {self.content}.]'


@dataclass
class DatasetDownloadObservation(Observation):
    """This data class represents the"""

    url: str
    platform: str
    output_path: str = '/workspace/'
    observation: str = ObservationType.DATASET_DOWNLOAD

    @property
    def message(self) -> str:
        return f'I downloaded dataset from {self.platform}. URL: {self.url}.'

    def __str__(self) -> str:
        return f'[Successfully downloaded from {self.platform}. URL: {self.url}. Output path: {self.output_path}.]'
