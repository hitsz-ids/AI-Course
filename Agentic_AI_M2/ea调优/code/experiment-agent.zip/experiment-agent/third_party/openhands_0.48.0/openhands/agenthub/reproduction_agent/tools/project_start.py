from litellm.types.llms.openai import ChatCompletionToolParam, ChatCompletionToolParamFunctionChunk

_PROJECT_START_CMD_DESCRIPTION = """
Execute a compound command to start a project.
* This tool runs a single command line that can chain multiple commands using operators like &&, ||, etc.
* Ideal for  project startup sequences like: "cd /workspace && python x.py" or "cd /workspace && sh path/to/script/run.sh"
"""
ProjectStartCmdTool = ChatCompletionToolParam(
    type='function',
    function=ChatCompletionToolParamFunctionChunk(
        name='project_start',
        description=_PROJECT_START_CMD_DESCRIPTION,
        parameters={
            'type': 'object',
            'properties': {
                'command': {
                    'type': 'string',
                    'description': 'Execute the program startup command',
                },
            },
            'required': ['command'],
        },
    ),
)
