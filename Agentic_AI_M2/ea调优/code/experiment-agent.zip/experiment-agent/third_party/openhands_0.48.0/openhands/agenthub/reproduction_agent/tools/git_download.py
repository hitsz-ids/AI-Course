from litellm import (
    ChatCompletionToolParam,
    ChatCompletionToolParamFunctionChunk,
)

_DGIT_REPO_DOWNLOAD_DESCRIPTION = """
Download a Git repository to a specified location.  
* This tool downloads the repository from a given Git URL.
* It saves the repository code to the specified local directory and renames the project folder based on the provided project name.
"""
GitRepoDownloadTool = ChatCompletionToolParam(
    type='function',
    function=ChatCompletionToolParamFunctionChunk(
        name='git_repo_download',
        description=_DGIT_REPO_DOWNLOAD_DESCRIPTION,
        parameters={
            'type': 'object',
            'properties': {
                'git_url': {
                    'type': 'string',
                    'description': 'The URL of the Git repository to be cloned.',
                },
                'destination_path': {
                    'type': 'string',
                    'description': 'The local directory where the repository should be saved.',
                },
                'project_name': {
                    'type': 'string',
                    'description': 'The name to rename the downloaded project folder.',
                },
            },
            'required': ['git_url', 'destination_path', 'project_name'],
        },
    ),
)