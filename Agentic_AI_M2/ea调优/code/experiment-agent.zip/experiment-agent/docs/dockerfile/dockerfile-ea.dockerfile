FROM python:3.12-slim

WORKDIR /app

# 环境变量
ENV DEBUG=1 \
    LOG_ALL_EVENTS=1 \
    LOG_TO_FILE=1 \
    LOG_DIR=/app/output \
    PYTHONPATH=/app \
    GOOGLE_APPLICATION_CREDENTIALS=/root/.google_cloud/config/config.json \
    ENV_LOG_ID=default

# 源、工具与 openssh
RUN mkdir -p /etc/apt && \
    echo "deb http://mirrors.aliyun.com/debian/ bookworm main contrib non-free non-free-firmware" > /etc/apt/sources.list && \
    echo "deb-src http://mirrors.aliyun.com/debian/ bookworm main contrib non-free non-free-firmware" >> /etc/apt/sources.list && \
    echo "deb http://mirrors.aliyun.com/debian-security bookworm-security main contrib non-free non-free-firmware" >> /etc/apt/sources.list && \
    echo "deb-src http://mirrors.aliyun.com/debian-security bookworm-security main contrib non-free non-free-firmware" >> /etc/apt/sources.list && \
    echo "deb http://mirrors.aliyun.com/debian/ bookworm-updates main contrib non-free non-free-firmware" >> /etc/apt/sources.list && \
    echo "deb-src http://mirrors.aliyun.com/debian/ bookworm-updates main contrib non-free non-free-firmware" >> /etc/apt/sources.list && \
    echo "deb http://mirrors.aliyun.com/debian/ bookworm-backports main contrib non-free non-free-firmware" >> /etc/apt/sources.list && \
    echo "deb-src http://mirrors.aliyun.com/debian/ bookworm-backports main contrib non-free non-free-firmware" >> /etc/apt/sources.list

RUN apt-get update && apt-get install -y --no-install-recommends \
      gcc g++ make git openssh-server sudo acl \
    && rm -rf /var/lib/apt/lists/*

# SSHD 基本配置
RUN mkdir -p /var/run/sshd && \
    sed -i '$a PermitRootLogin no' /etc/ssh/sshd_config && \
    sed -i '$a PasswordAuthentication yes' /etc/ssh/sshd_config && \
    sed -i '$a ChallengeResponseAuthentication no' /etc/ssh/sshd_config && \
    sed -i '$a UsePAM no' /etc/ssh/sshd_config && \
    sed -i '$a Port 22' /etc/ssh/sshd_config && \
    sed -i '$a AllowUsers vscode' /etc/ssh/sshd_config

# 目录
RUN mkdir -p /root/.kube /root/.google_cloud/config /root/.ea/logs

# 动态 shell：进入日志目录
RUN printf '%s\n' \
  '#!/bin/bash' \
  'set -e' \
  'ENV_LOG_ID=${ENV_LOG_ID:-default}' \
  'LOG_DIR="/root/.ea/logs/${ENV_LOG_ID}"' \
  'mkdir -p "$LOG_DIR"' \
  'chown vscode:vscode "$LOG_DIR"' \
  'chmod 700 "$LOG_DIR"' \
  'cd "$LOG_DIR"' \
  'exec bash --login' \
  > /usr/local/bin/dynamic_shell && chmod +x /usr/local/bin/dynamic_shell

# 用户
RUN useradd -m -s /usr/local/bin/dynamic_shell vscode && \
    echo "vscode ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers

# 拷贝配置与项目
COPY google_config/config.json /root/.google_cloud/config/config.json
COPY google_config/config /root/.kube/config
COPY . .
RUN pip install -e .

# 启动脚本：随机密码 + 权限收紧 + 启动 sshd
# 启动脚本：随机密码 + 权限收紧 + 启动 sshd
RUN mkdir -p /app && \
cat <<'EOF' >/app/start.sh
#!/bin/bash
set -e

# 1) 生成随机密码
PASS=$(tr -dc 'A-Za-z0-9' </dev/urandom | head -c 20)
echo "vscode:${PASS}" | chpasswd
echo "================================================="
echo "VS Code SSH 用户: vscode"
echo "随机密码: ${PASS}"
echo "日志ID: ${ENV_LOG_ID:-default}"
echo "================================================="

# 2) 准备日志目录并设为 HOME
ENV_LOG_ID=${ENV_LOG_ID:-default}
LOG_DIR="/root/.ea/logs/${ENV_LOG_ID}"
mkdir -p "$LOG_DIR"
chown -R vscode:vscode "$LOG_DIR"
chmod 700 "$LOG_DIR"

# 3) 允许非 root 穿越目录（不可列目录）
chmod 711 /root || true
chmod 711 /root/.ea || true
chmod 711 /root/.ea/logs || true

# 4) 降权
chmod 700 /app || true

# 5) 设置 HOME
usermod -d "$LOG_DIR" vscode
echo "export HOME=\"${LOG_DIR}\"" >> /home/vscode_env.sh
echo "cd \"${LOG_DIR}\"" >> /home/vscode_env.sh
chown vscode:vscode /home/vscode_env.sh

# 6) 自动回目录（给 bash 用）
echo "PROMPT_COMMAND='{ [ \"\$PWD\" != \"\$HOME\" ] && cd \"\$HOME\"; }'" >> "${LOG_DIR}/.bashrc"

# 7) 再次收权限
chmod 700 "${LOG_DIR}"

# 8) 启动 sshd（作为容器前台进程）
exec /usr/sbin/sshd -D -e
EOF

RUN chmod +x /app/start.sh



EXPOSE 8081 22
CMD ["/app/start.sh"]
