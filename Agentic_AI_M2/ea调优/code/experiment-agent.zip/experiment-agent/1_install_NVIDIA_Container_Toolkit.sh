#!/bin/bash

# 定义颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== NVIDIA Container Toolkit 自动安装脚本 ===${NC}"

# 1. 检查 Root 权限
if [ "$EUID" -ne 0 ]; then 
  echo -e "${RED}[错误] 请使用 sudo 或以 root 用户运行此脚本。${NC}"
  exit 1
fi

# 2. 预检：检查 Docker 和 Nvidia 驱动
echo -e "${YELLOW}[INFO] 正在检查环境...${NC}"

if ! command -v docker &> /dev/null; then
    echo -e "${RED}[错误] 未检测到 Docker。请先安装 Docker Engine。${NC}"
    exit 1
fi

if ! command -v nvidia-smi &> /dev/null; then
    echo -e "${RED}[错误] 未检测到 NVIDIA 驱动 (nvidia-smi 无法运行)。请先安装显卡驱动。${NC}"
    exit 1
fi
echo -e "${GREEN}[OK] Docker 和 NVIDIA 驱动已就绪。${NC}"

# 3. 检测系统并配置源
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$ID
else
    echo -e "${RED}[错误] 无法检测操作系统类型。${NC}"
    exit 1
fi

echo -e "${YELLOW}[INFO] 检测到系统: $OS${NC}"

if [[ "$OS" == "ubuntu" || "$OS" == "debian" ]]; then
    # --- Ubuntu / Debian 逻辑 ---
    echo -e "${YELLOW}[INFO] 正在为 Debian/Ubuntu 配置 GPG Key 和软件源...${NC}"
    
    curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg \
    && curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
    sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
    sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
    
    echo -e "${YELLOW}[INFO] 更新软件包列表...${NC}"
    apt-get update
    
    echo -e "${YELLOW}[INFO] 安装 nvidia-container-toolkit...${NC}"
    apt-get install -y nvidia-container-toolkit

elif [[ "$OS" == "centos" || "$OS" == "rhel" || "$OS" == "fedora" || "$OS" == "almalinux" || "$OS" == "rocky" ]]; then
    # --- RHEL / CentOS 逻辑 ---
    echo -e "${YELLOW}[INFO] 正在为 RHEL/CentOS 配置软件源...${NC}"
    
    curl -s -L https://nvidia.github.io/libnvidia-container/stable/rpm/nvidia-container-toolkit.repo | \
    sudo tee /etc/yum.repos.d/nvidia-container-toolkit.repo
    
    echo -e "${YELLOW}[INFO] 安装 nvidia-container-toolkit...${NC}"
    if command -v dnf &> /dev/null; then
        dnf install -y nvidia-container-toolkit
    else
        yum install -y nvidia-container-toolkit
    fi

else
    echo -e "${RED}[错误] 不支持的操作系统: $OS${NC}"
    echo "请参考官方文档手动安装。"
    exit 1
fi

# 4. 配置 Docker (Nvidia Runtime)
echo -e "${YELLOW}[INFO] 正在配置 Docker Daemon (注入 Nvidia Runtime)...${NC}"
sudo nvidia-ctk runtime configure --runtime=docker

# =======================================================
# 新增逻辑: 修改 daemon.json 添加 cgroupfs 配置
# =======================================================
echo -e "${YELLOW}[INFO] 正在修改 daemon.json 添加 exec-opts: native.cgroupdriver=cgroupfs ...${NC}"

# 使用 Python 进行安全的 JSON 操作，确保不破坏 nvidia-ctk 生成的 runtimes 配置
sudo python3 -c "
import json
import os
import sys

file_path = '/etc/docker/daemon.json'

# 1. 读取现有文件
if os.path.exists(file_path):
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
    except json.JSONDecodeError:
        print('警告: daemon.json 格式错误，将重置。')
        data = {}
else:
    data = {}

# 2. 添加或更新 exec-opts
# 确保它是列表格式
data['exec-opts'] = ['native.cgroupdriver=cgroupfs']

# 3. 写回文件
with open(file_path, 'w') as f:
    json.dump(data, f, indent=4)
"

if [ $? -eq 0 ]; then
    echo -e "${GREEN}[OK] daemon.json 修改成功。${NC}"
else
    echo -e "${RED}[错误] 修改 daemon.json 失败。${NC}"
    exit 1
fi
# =======================================================

# 5. 重启 Docker
echo -e "${YELLOW}[INFO] 重启 Docker 服务...${NC}"
sudo systemctl restart docker

# 6. 验证安装
echo -e "${YELLOW}[INFO] 正在运行测试容器验证安装 (可能需要下载 ubuntu 镜像)...${NC}"

# 尝试运行 nvidia-smi 容器
if sudo docker run --rm --runtime=nvidia --gpus all ubuntu nvidia-smi; then
    echo -e ""
    echo -e "${GREEN}==============================================${NC}"
    echo -e "${GREEN}   安装成功！你已能在 Docker 中看到显卡信息。   ${NC}"
    echo -e "${GREEN}==============================================${NC}"
else
    echo -e ""
    echo -e "${RED}[错误] 测试容器运行失败。请检查上方的错误信息。${NC}"
    echo -e "${YELLOW}提示: 如果是因为网络问题无法拉取镜像，请配置 Docker 镜像加速。${NC}"
fi