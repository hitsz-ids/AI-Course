#!/bin/bash

# 遇到任何命令错误立即停止执行
set -e

# ==========================================
# 1. 环境准备与 Conda 配置
# ==========================================

# 获取 Miniconda 路径
MINICONDA_PATH="$HOME/miniconda3"

# 加载 conda 配置
if [ -f "$MINICONDA_PATH/etc/profile.d/conda.sh" ]; then
    source "$MINICONDA_PATH/etc/profile.d/conda.sh"
else
    echo "错误: 未找到 conda 配置文件，请确认安装路径是否为 $MINICONDA_PATH"
    exit 1
fi

# ==========================================
# 2. Python 环境安装 (核心修复)
# ==========================================

echo ">>> 检查 conda 环境 'ea'..."

if conda info --envs | grep -q "^ea "; then
    echo "环境 'ea' 已存在，跳过创建。"
else
    echo "环境 'ea' 不存在，开始创建 (Python 3.12)..."
    
    # 【核心修改】
    # 使用 --override-channels -c conda-forge
    # 这会强制 Conda 只去 conda-forge 找包，完全忽略 defaults 频道
    # 从而彻底避开 Anaconda Terms of Service 的报错
    conda create -n ea python=3.12 --override-channels -c conda-forge -y
fi

echo ">>> 激活环境 'ea'..."
conda activate ea

echo ">>> 进入 third_party/openhands_0.48.0/ 安装依赖..."
if [ -d "third_party/openhands_0.48.0/" ]; then
    cd third_party/openhands_0.48.0/
    pip install -e .
    cd ../../
else
    echo "错误: 找不到目录 third_party/openhands_0.48.0/"
    exit 1
fi

echo ">>> 安装当前项目..."
pip install -e .

# ==========================================
# 3. Docker 权限配置
# ==========================================

echo ">>> 正在检查 Docker 权限..."

# 检查 Docker 是否运行
if ! systemctl is-active --quiet docker; then
    echo "警告: Docker 服务似乎未运行，尝试启动..."
    sudo systemctl start docker
fi

# 检查当前用户是否已经在 docker 组
if groups $USER | grep -q '\bdocker\b'; then
    echo "用户 $USER 已在 docker 组中。"
    USE_SG=false
else
    echo "用户 $USER 不在 docker 组中。"
    echo "正在将用户加入 docker 组 (需要 sudo 密码)..."
    
    # 创建 docker 组（如果不存在）并添加用户
    sudo groupadd -f docker
    sudo usermod -aG docker $USER
    
    echo "用户已添加。为了在当前脚本立即生效，将使用 sg 命令执行构建..."
    USE_SG=true
fi

# ==========================================
# 4. 构建 Docker 镜像
# ==========================================

DOCKER_FILE="docs/dockerfile/dockerfile-base.dockerfile"
IMAGE_TAG="experiment-agent-base:0.1"

if [ ! -f "$DOCKER_FILE" ]; then
    echo "错误: 找不到 Dockerfile ($DOCKER_FILE)"
    exit 1
fi

echo ">>> 开始构建 Docker 镜像: $IMAGE_TAG"

# 定义构建命令
BUILD_CMD="docker build -t $IMAGE_TAG -f $DOCKER_FILE ."

if [ "$USE_SG" = true ]; then
    # 使用 sg 临时切换组身份执行命令
    sg docker -c "$BUILD_CMD"
else
    # 直接执行
    $BUILD_CMD
fi

echo ">>> 所有步骤执行完毕！"
