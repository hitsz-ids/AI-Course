#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

echo "Starting Docker Installation..."

# 1. Update existing packages
echo "Updating package database..."
sudo apt-get update

# 2. Install prerequisite packages
echo "Installing prerequisites..."
sudo apt-get install -y ca-certificates curl gnupg

# 3. Add Docker's official GPG key
echo "Adding Docker GPG key..."
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg --yes
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# 4. Set up the repository
echo "Setting up Docker repository..."
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# 5. Install Docker Engine, containerd, and Docker Compose
echo "Installing Docker Engine and Docker Compose..."
sudo apt-get update
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# 6. Add current user to the docker group (to run without sudo)
echo "Adding $USER to the docker group..."
sudo usermod -aG docker $USER

echo "------------------------------------------------------------------"
echo "Docker installed successfully!"
echo "You verify the installation by running: sudo docker run hello-world"
echo "IMPORTANT: You must log out and log back in for group changes to take effect."
echo "------------------------------------------------------------------"
