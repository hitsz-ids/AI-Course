#!/bin/bash

# 1. 下载 Miniconda 安装脚本
echo "正在下载 Miniconda..."
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh -O ~/Miniconda3-latest-Linux-x86_64.sh

# 2. 安装 Miniconda
# -b 表示批处理模式（静默安装，不需要按回车）
# -p 指定安装路径（通常是 ~/miniconda3）
echo "正在安装 Miniconda..."
bash ~/Miniconda3-latest-Linux-x86_64.sh -b -p $HOME/miniconda3

# 3. 初始化 Conda
echo "正在初始化 Conda..."
$HOME/miniconda3/bin/conda init bash
# 如果你也使用 zsh，取消下面这行的注释
# $HOME/miniconda3/bin/conda init zsh

# 4. 清理安装包
rm ~/Miniconda3-latest-Linux-x86_64.sh

echo "Miniconda 安装完成！"
echo "请执行 'source ~/.bashrc' 或重启终端以使 conda 命令生效。"