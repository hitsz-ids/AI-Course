from pydantic import BaseModel, Field

class AdaptationConfig(BaseModel):
    max_iterations: int = Field(default=100)
    memory_storage_type: str = Field(default='memory')