from experiment_agent import ExperimentParams
from experiment_agent.adaptation.adaptation_agent import AdaptationAgent
from experiment_agent.adaptation.config.adaptation_config import AdaptationConfig
from experiment_agent.adaptation.model.adaptaion_result import AdaptationResult
from experiment_agent.framework.config.experiment_config import ExperimentConfig
from experiment_agent.framework.stage import Stage
from experiment_agent.framework.agent.base import StepDecision
from experiment_agent.framework.logger.logger import ea_logger
from experiment_agent.framework.memery.base import Memory
from experiment_agent.reproduction.model.reproduction_result import ReproductionResult


def should_proceed_next_step(memory_manager: Memory) -> StepDecision:
    # 当agent准备执行下一步行动时会回调，在MemoryManager中会存在对话的历史和当前的步数
    return StepDecision(prompt='', proceed=True)


class Adaptation(Stage[AdaptationResult]):

    def __init__(self, config: ExperimentConfig, reproduction: ReproductionResult | None = None,
                 sid: str | None = None):
        super().__init__(config, sid)
        ea_logger.info(f'Create Adaptation Stage')
        self.agent = AdaptationAgent(config=config,
                                     should_proceed_next_step=should_proceed_next_step,
                                     params=reproduction,
                                     sid=sid)

    def execute(self, params: ReproductionResult = None) -> AdaptationResult:
        return self.agent.run()

    def close_resources(self):
        self.agent.close_resources()