from experiment_agent import StageResult


class AdaptationResult(StageResult):
    id: str
    workspace: str
    current_performance: str | None = None
    target_performance: str | None = None
