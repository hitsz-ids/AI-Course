import uuid
from abc import ABC, abstractmethod
from enum import nonmember
from typing import Optional, Callable, Generic, TypeVar

from experiment_agent.framework.config.experiment_config import ExperimentConfig
from experiment_agent.framework.delegate.base import Delegate
from experiment_agent.framework.memery.base import Memory
from experiment_agent.framework.memery.step_decision import StepDecision
from experiment_agent.framework.models.models import ExperimentParams

P = TypeVar('P')
R = TypeVar('R')


class Agent(ABC, Generic[P, R]):
    config: ExperimentConfig
    should_proceed_next_step: Optional[Callable[[Memory], StepDecision]]
    memory: Memory
    delegate: Delegate
    params: P | None = None
    result: R | None = None

    def __init__(self,
                 config: ExperimentConfig,
                 should_proceed_next_step: Optional[Callable[[Memory], StepDecision]],
                 params: P | None = None,
                 sid: str | None = None):
        if sid is None:
            self._id = str(uuid.uuid4())
        else:
            self._id = sid
        self.params = params
        self.config = config
        self.should_proceed_next_step = should_proceed_next_step
        self.init_config()
        self.delegate = self.init_delegate()
        self.memory = self.init_memory()

    @abstractmethod
    def init_config(self):
        pass

    @abstractmethod
    def init_delegate(self) -> Delegate:
        pass

    @abstractmethod
    def init_memory(self) -> Memory:
        pass

    @property
    def id(self):
        if hasattr(self, '_id'):
            return self._id
        return None

    @abstractmethod
    def run(self) -> R | None:
        pass

    @abstractmethod
    def close_resources(self):
        pass
