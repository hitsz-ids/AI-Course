import uuid
from abc import ABC, abstractmethod
from typing import Optional, Callable

from experiment_agent.framework.memery.base import Memory
from experiment_agent.framework.memery.conversation import Step
from experiment_agent.framework.memery.step_decision import StepDecision


class Delegate(ABC):
    memory: Memory
    pre_next_step: Optional[Callable[[Step, int], StepDecision]]
    callback_finish: Optional[Callable] = None
    is_finish: bool
    def __init__(self, pre_next_step: Optional[Callable[[Step, int], StepDecision]],
                 callback_finish: Optional[Callable] | None = None,
                 sid: str | None = None):
        if sid is None:
            self._id = str(uuid.uuid4())
        else:
            self._id = sid
        self.pre_next_step = pre_next_step
        self.callback_finish = callback_finish
        self.is_finish = False

    @abstractmethod
    def run(self, task: str):
        pass

    def finish(self):
        if self.callback_finish:
            self.callback_finish()
        self.is_finish = True

    @property
    def id(self):
        if hasattr(self, '_id'):
            return self._id
        return None
