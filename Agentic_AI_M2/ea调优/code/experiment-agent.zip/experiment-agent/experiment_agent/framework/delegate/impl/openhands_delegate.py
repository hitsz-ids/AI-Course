import os
import threading
from dataclasses import is_dataclass, fields
from datetime import datetime
from enum import Enum
from typing import Any, ClassVar, TypeVar, Type
from typing import Optional, Callable
import pickle
from pydantic import BaseModel
from pathlib import Path

from experiment_agent.framework.agent.base import StepDecision
from experiment_agent.framework.delegate.base import Delegate
from experiment_agent.framework.logger.logger import ea_logger
from experiment_agent.framework.memery.conversation import Step, StepAction, StepObservation
from openhands.controller.agent import Agent
from openhands.controller.agent_controller import AgentController, InnerStepDecision
from openhands.controller.state.state import State
from openhands.core.config.utils import OpenHandsConfig
from openhands.core.config.utils import load_from_toml
from openhands.core.schema import AgentState
from openhands.core.setup import create_runtime, create_agent, create_controller, create_memory
from openhands.events import Event, EventStreamSubscriber, EventSource, EventStream
from openhands.events.action import MessageAction, CmdRunAction, Action
from openhands.events.observation import AgentStateChangedObservation, CmdOutputObservation, Observation
from openhands.memory.memory import Memory
from openhands.runtime import Runtime, GoogleKubernetesRuntime, DockerRuntime
from openhands.runtime.mcp.proxy.manager import logger
from openhands.utils.async_utils import call_async_from_sync


def _to_dict(obj: Any) -> Any:
    """Recursively convert dataclass or complex object to JSON-serializable dict."""
    if is_dataclass(obj):
        result = {}
        for f in fields(obj):
            # 忽略 ClassVar
            if getattr(f.type, '__origin__', None) is ClassVar:
                continue
            value = getattr(obj, f.name, None)
            result[f.name] = _to_dict(value)
        return result

    elif isinstance(obj, dict):
        return {k: _to_dict(v) for k, v in obj.items()}

    elif isinstance(obj, (list, tuple, set)):
        return [_to_dict(v) for v in obj]

    elif isinstance(obj, Enum):
        return obj.name  # 或 obj.value

    elif isinstance(obj, datetime):
        return obj.isoformat()

    # 基本类型直接返回
    elif isinstance(obj, (str, int, float, bool, type(None))):
        return obj

    # 其他对象尝试用 __dict__ 再转
    elif hasattr(obj, "__dict__"):
        return {k: _to_dict(v) for k, v in obj.__dict__.items()}

    else:
        # 最后兜底，转成字符串
        return str(obj)


def create_openhands_config():
    openhands_config = OpenHandsConfig()
    path = Path(os.path.join(os.path.dirname(__file__), 'config', 'openhands_config.toml'))
    load_from_toml(openhands_config, str(path))
    return openhands_config


class OpenhandsResult(BaseModel):
    id: str
    workspace: str
    image_name: str


R = TypeVar('R', bound=Runtime)


class OpenhandsDelegate(Delegate):
    _openhands_config: OpenHandsConfig
    _runtime: Runtime
    _event_stream: EventStream
    _memory: Memory
    _controller: AgentController
    _initial_user_action: MessageAction
    _agent: Agent
    _conversation_index: int
    _conda_env: str
    _is_change_python_env: bool

    def __init__(self,
                 openhands_config: OpenHandsConfig,
                 conda_env: str,
                 pre_next_step: Optional[Callable[[Step, int], StepDecision]],
                 is_change_python_env: bool = False,
                 callback_finish: Optional[Callable] | None = None,
                 sid: str | None = None):
        super().__init__(pre_next_step=pre_next_step, callback_finish=callback_finish, sid=sid)
        self._is_finish = False
        self._stop_event = threading.Event()
        self._is_change_python_env = is_change_python_env
        self._conda_env = conda_env
        self._conversation_index = 1
        self._openhands_config = openhands_config
        self._agent = create_agent(self._openhands_config)
        self._runtime = create_runtime(
            self._openhands_config,
            sid=self.id,
            headless_mode=True,
            agent=self._agent,
        )
        self._event_stream = self._runtime.event_stream

        def on_event(event: Event) -> None:
            if isinstance(event, AgentStateChangedObservation):
                if event.agent_state == AgentState.AWAITING_USER_INPUT:
                    action = MessageAction(content="""Please continue working on the task on whatever approach you think is suitable.
                                       If you think you have solved the task, please first send your answer to user through message and then finish the interaction.
                                       IMPORTANT: YOU SHOULD NEVER ASK FOR HUMAN HELP.""")
                    self._event_stream.add_event(action, EventSource.USER)
                if event.agent_state == AgentState.STOPPED or event.agent_state == AgentState.FINISHED or event.agent_state == AgentState.ERROR:
                    if event.agent_state == AgentState.FINISHED:
                        self._finish()
                    self._stop_event.set()

        self._event_stream.subscribe(EventStreamSubscriber.MAIN, on_event, self.id)
        ea_logger.info(f'Create Openhands Delegate id is:{self.id}')

    def run(self, task: str) -> bool:
        self._initial_user_action = MessageAction(content=task)
        call_async_from_sync(self._runtime.connect)
        if self._openhands_config.runtime == 'google_k8s':
            self.runtime(GoogleKubernetesRuntime).reset()
        self._memory = create_memory(
            runtime=self._runtime,
            event_stream=self._event_stream,
            sid=self.id,
            selected_repository=self._openhands_config.sandbox.selected_repo,
            repo_directory=self._openhands_config.workspace_base,
            conversation_instructions=None,
        )
        if self._is_change_python_env:
            obs = self._runtime.run_action(CmdRunAction(
                command=f'echo "export PATH=/opt/conda/envs/{self._conda_env}/bin:$PATH" >> ~/.bashrc && source ~/.bashrc'))
            assert isinstance(obs, CmdOutputObservation) and obs.exit_code == 0

        self._controller, initial_state = create_controller(
            self._agent, self._runtime, self._openhands_config, replay_events=None,
            should_proceed_next_step=self._should_proceed_next_step
        )
        self._event_stream.add_event(self._initial_user_action, EventSource.USER)
        logger.debug(f'当前启动的sid：{self.id}')
        while not self._stop_event.is_set():
            self._stop_event.wait()
        return self.is_finish

    def _should_proceed_next_step(self, state: State, is_editor: bool):
        step: Step
        if state.iteration_flag.current_value == 1:
            # 由于该钩子是在openhands每一次与大模型交互生成action之前执行，所以第一次的回调不需要做处理直接放行即可
            return InnerStepDecision(
                proceed=True,
                prompt=''
            )
        else:
            # 在执行下一步动作前，先记录前一步的历史记录，并且对其做处理，此处可以添加一些prompt来指导llm下一步的动作
            step = self._create_step(state)
        self._conversation_index = len(state.history)
        step_decision = self.pre_next_step(step, state.iteration_flag.current_value)
        return InnerStepDecision(
            proceed=step_decision.proceed,
            prompt=step_decision.prompt
        )

    def _create_step(self, state):
        step: Step | None = None
        start = self._conversation_index
        pending: dict[int, Step] = {}  # 仅以 Action 的 id 建立条目
        order: list[int] = []  # 保持 Step 输出顺序（按 Action 出现顺序）
        for event in state.history[start:]:
            if isinstance(event, Action):
                # 创建/复用以 Action 为核心的 Step
                step = pending.get(event.id)
                if step is None:
                    step = Step(prompt=state.step_prompt,
                                prompt_format=self._agent.llm.get_prompt(state.step_prompt),
                                response=state.step_response,
                                tools=state.step_tools, )
                    pending[event.id] = step
                    order.append(event.id)
                if hasattr(event, 'thought'):
                    thought = event.thought
                else:
                    thought = ''

                step.action = StepAction(
                    id=event.id,
                    thought=thought,
                    action_type=event.action,
                    params=_to_dict(event),
                    class_name=type(event).__name__
                )
            elif isinstance(event, Observation):
                # 只有当先前见过对应的 Action（即在 pending 中）时才补齐 observation
                step = pending.get(event.cause)
                if step is not None and getattr(step, "observation", None) is None:
                    step.observation = StepObservation(
                        id=event.cause,
                        observation=event.observation or 'None',
                        params=_to_dict(event),
                        class_name=type(event).__name__,
                    )
        for aid in order:
            step = pending[aid]

        if step is None:
            # 容错处理，如果都没有解析到对应内容则llm调用失败
            step = Step(
                action=None,
                observation=None
            )
        return step

    def runtime(self, cls: Type[R]) -> R:
        if isinstance(self._runtime, cls):
            return self._runtime

        raise TypeError(f"runtime is of type {type(self._runtime).__name__}, "
                        f"expected {cls.__name__}")

    def get_runtime(self):
        return self._runtime

    def _finish(self):
        self._should_proceed_next_step(self._controller.state, False)
        self.finish()
