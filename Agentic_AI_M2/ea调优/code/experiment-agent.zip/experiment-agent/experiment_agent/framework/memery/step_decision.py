from pydantic import BaseModel

class StepDecision(BaseModel):
    """_should_proceed_next_step 的返回类型。"""
    prompt: str = ''
    proceed: bool = False