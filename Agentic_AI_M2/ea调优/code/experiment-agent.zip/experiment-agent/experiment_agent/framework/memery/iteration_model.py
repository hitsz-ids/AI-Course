class IterationModel:
    max_iterations: int
    current_iteration: int
    def __init__(self, max_iterations: int, current_iteration: int = 0):
        self.max_iterations = max_iterations
        self.current_iteration = current_iteration
