from experiment_agent import ea_logger
from experiment_agent.framework.memery.base import Memory
from experiment_agent.framework.memery.conversation import Step


class MemoryStore(Memory):

    def init(self):
        ea_logger.info(f"Create Memory Store")
        if self.current_iteration > 1:
            self.set_iteration(1)

    def record(self, step: Step):
        self._conversation.steps.append(step)

    def find_record(self, index: int) -> Step:
        return self._conversation.steps[index]

    def record_len(self) -> int:
        return len(self._conversation.steps)

    def retrieve(self, keywords: list[str]) -> list[str]:
        pass
