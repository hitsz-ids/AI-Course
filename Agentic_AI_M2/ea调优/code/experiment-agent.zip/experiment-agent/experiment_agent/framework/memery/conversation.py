from dataclasses import dataclass


@dataclass
class StepAction:
    id: int
    action_type: str
    params: dict
    class_name: str
    thought: str = ''


@dataclass
class StepObservation:
    id: int
    observation: str
    params: dict
    class_name: str


@dataclass
class Step:
    prompt: list[str] | None = None
    prompt_format: str | None = None
    response: str | None = None
    tools: list[str] | None = None
    action: StepAction | None = None
    observation: StepObservation | None = None


class Conversation:
    steps: list[Step]
    is_editor: bool = False

    def __init__(self):
        self.steps = []

    def stash(self, step: Step):
        self.steps.append(step)

    def pop(self):
        return self.steps.pop()
