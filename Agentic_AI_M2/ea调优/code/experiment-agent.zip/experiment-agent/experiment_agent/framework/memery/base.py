import uuid
from abc import abstractmethod, ABC

from experiment_agent import ea_logger
from experiment_agent.framework.memery.conversation import Conversation, Step
from experiment_agent.framework.memery.iteration_model import IterationModel


class Memory(ABC):
    _iteration_model: IterationModel
    _conversation: Conversation
    _name: str

    def __init__(self, name: str,
                 iteration_model: IterationModel,
                 conversation: Conversation,
                 sid: str | None = None):
        self._name = name
        self._iteration_model = iteration_model
        self._conversation = conversation
        if sid is None:
            self._id = str(uuid.uuid4())
        else:
            self._id = sid
        ea_logger.info(f"Create Memory, this name is: {self._name}")
        self.init()

    @property
    def id(self) -> str | None:
        if hasattr(self, '_id'):
            return self._id
        return None

    @abstractmethod
    def init(self):
        pass

    @abstractmethod
    def record(self, step: Step):
        pass

    @abstractmethod
    def find_record(self, index: int) -> Step:
        pass

    @abstractmethod
    def record_len(self) -> int:
        pass

    @abstractmethod
    def retrieve(self, keywords: list[str]) -> list[str]:
        pass

    @property
    def max_iterations(self):
        return self._iteration_model.max_iterations

    @property
    def current_iteration(self):
        return self._iteration_model.current_iteration

    def set_iteration(self, iteration: int):
        self._iteration_model.current_iteration = iteration

