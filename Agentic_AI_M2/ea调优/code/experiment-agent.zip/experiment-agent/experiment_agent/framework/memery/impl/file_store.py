import json
import os
from pathlib import Path

from experiment_agent.framework.logger.config import LOG_DIR
from experiment_agent.framework.logger.logger import ea_logger
from experiment_agent.framework.memery.base import Memory
from experiment_agent.framework.memery.conversation import Step

CONVERSATION_FILE_NAME = 'conversation.md'
OBSERVATION_FILE_SUFFIX = 'observation.json'
ACTION_FILE_SUFFIX = 'action.json'
PROMPT_FILE_SUFFIX = 'prompt.json'
PROMPT_FORMAT_FILE_SUFFIX = 'prompt_format.log'
RESPONSE_FILE_SUFFIX = 'response.log'
TOOLS_FILE_SUFFIX = 'tools.json'


def _write_json_pretty(data: dict, file_path: str):
    lines = data["content"].splitlines()
    lines = [line.replace("\t", "    ") for line in lines]
    data["content_formatter"] = lines
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)


class FileStore(Memory):
    conversation_file: Path
    file_dir: str
    ea_dir: str

    # file_name_dir: str

    def init(self):
        self.create_store_dir()
        ea_logger.info(f"Create File Store Memory, this file path is: {self.file_dir}")

    def create_store_dir(self):
        self.ea_dir = os.path.join(LOG_DIR, 'conversations')
        if not os.path.exists(self.ea_dir):
            os.mkdir(self.ea_dir)
        self.file_dir = os.path.join(self.ea_dir, self._name)
        if not os.path.exists(self.file_dir):
            os.mkdir(self.file_dir)
        # self.file_name_dir = os.path.join(self.ea_dir, self._name)
        # if not os.path.exists(self.file_name_dir):
        #     os.mkdir(self.file_name_dir)
        # self.file_dir = os.path.join(self.file_name_dir, self.id)
        # if not os.path.exists(self.file_dir):
        #     os.mkdir(self.file_dir)

        self.conversation_file = Path(os.path.join(self.file_dir, CONVERSATION_FILE_NAME))
        self.conversation_file.touch(exist_ok=True)

    def record(self, step: Step):
        with self.conversation_file.open("a", encoding="utf-8") as f:
            step_name = f"Step{self.current_iteration-1}"
            f.write(f"# {step_name}\n")
            # 存储action
            if step.action is None:
                f.write("### action: None\n")
            else:
                json_file_name = f"{step_name}_{ACTION_FILE_SUFFIX}"
                json_file = os.path.join(self.file_dir, json_file_name)
                f.write(
                    f"### Thought\n"
                    f"{step.action.thought}\n"
                    f"### Action: {step.action.class_name}\n"
                    f"  - action_type: {step.action.action_type}\n"
                    f"  - params: [params]({json_file_name})\n"
                )
                with open(json_file, "w", encoding="utf-8") as action_json_file:
                    json.dump(step.action.params, action_json_file, ensure_ascii=False, indent=4)
            # 存储observation
            if step.observation is None:
                f.write("- observation: None\n")
            else:
                json_file_name = f"{step_name}_{OBSERVATION_FILE_SUFFIX}"
                json_file = os.path.join(self.file_dir, json_file_name)
                f.write(
                    f"### Observation: {step.observation.class_name}\n"
                    f"  - observation_type: {step.observation.observation}\n"
                    f"  - params: [params]({json_file_name})\n"
                )
                _write_json_pretty(data=step.observation.params,
                                   file_path=json_file)
            # 存储prompt
            f.write(f"### Arguments\n")
            if step.prompt:
                prompt_file_name = self._save_prompt(step_name, step.prompt)
                f.write(f"- prompt: [prompt]({prompt_file_name})\n")
            else:
                f.write("- prompt: None\n")
            # 存储prompt_format
            if step.prompt:
                prompt_file_name = self._save_prompt_format(step_name, step.prompt_format)
                f.write(f"- prompt_format: [prompt_format]({prompt_file_name})\n")
            else:
                f.write("- prompt_format: None\n")
            # 存储response
            if step.response:
                response_file_name = self._save_response(step_name, step.response)
                f.write(f"- response: [response]({response_file_name})\n")
            else:
                f.write("- response: None\n")
            # 存储tools
            if step.tools:
                tools_file_name = self._save_tools(step_name, step.tools)
                f.write(f"- tools: [tools]({tools_file_name})\n")
            else:
                f.write("- tools: None\n")

    def _save_prompt(self, step_name: str, prompt: list[str]):
        prompt_file_name = f"{step_name}_{PROMPT_FILE_SUFFIX}"
        prompt_file = os.path.join(self.file_dir, prompt_file_name)
        with open(prompt_file, "w", encoding="utf-8") as f:
            json.dump(prompt, f, ensure_ascii=False, indent=4)
        return prompt_file_name

    def _save_prompt_format(self, step_name: str, prompt_format: str):
        prompt_format_file_name = f"{step_name}_{PROMPT_FORMAT_FILE_SUFFIX}"
        prompt_file = os.path.join(self.file_dir, prompt_format_file_name)
        with open(prompt_file, "w", encoding="utf-8") as f:
            f.write(prompt_format)
        return prompt_format_file_name

    def _save_response(self, step_name: str, response: str):
        response_file_name = f"{step_name}_{RESPONSE_FILE_SUFFIX}"
        response_file = os.path.join(self.file_dir, response_file_name)
        with open(response_file, "w", encoding="utf-8") as f:
            f.write(response)
        return response_file_name

    def _save_tools(self, step_name: str, tools: list[str]):
        tools_file_name = f"{step_name}_{TOOLS_FILE_SUFFIX}"
        tools_file = os.path.join(self.file_dir, tools_file_name)
        with open(tools_file, "w", encoding="utf-8") as f:
            json.dump(tools, f, ensure_ascii=False, indent=4)
        return tools_file_name

    def find_record(self, index: int) -> Step:
        pass

    def record_len(self) -> int:
        pass

    def retrieve(self, keywords: list[str]) -> list[str]:
        pass
