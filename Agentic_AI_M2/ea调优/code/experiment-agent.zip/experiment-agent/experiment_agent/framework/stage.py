import uuid
from abc import ABC, abstractmethod
from enum import Enum, auto
from typing import TypeVar, Generic

from pydantic import BaseModel

from experiment_agent.framework.config.experiment_config import ExperimentConfig
from experiment_agent.framework.agent.base import Agent


class StageResult(BaseModel):
    pass


R = TypeVar('R', bound=StageResult)


class StageStatus(Enum):
    PENDING = auto()  # 阶段尚未执行
    RUNNING = auto()  # 阶段正在执行
    COMPLETED = auto()  # 阶段执行完成
    FAILED = auto()  # 阶段执行失败


class Stage(ABC, Generic[R]):
    agent: 'Agent'
    config: 'ExperimentConfig'
    status: StageStatus

    def __init__(self, config: 'ExperimentConfig', sid: str | None = None):
        self.config = config
        self.status = StageStatus.PENDING  # 默认状态为待执行
        if sid is None:
            self._id = str(uuid.uuid4())
        else:
            self._id = sid

    @abstractmethod
    def execute(self, params) -> R:
        pass

    def set_status(self, status: StageStatus):
        self.status = status

    @abstractmethod
    def close_resources(self):
        pass

    @property
    def id(self):
        if hasattr(self, '_id'):
            return self._id
        return None
