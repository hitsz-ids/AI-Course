from pydantic import BaseModel, Field


class GoogleK8sConfig(BaseModel):
    gpu_count: int = Field(default=1)
