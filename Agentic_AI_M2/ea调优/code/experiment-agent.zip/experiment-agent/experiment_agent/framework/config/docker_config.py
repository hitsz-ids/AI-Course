from pydantic import BaseModel, Field


class LocalDockerConfig(BaseModel):
    workspace: str | None = Field(default='./workspace', description='local workspace to mount docker image')
    cuda_visible_devices: str | None = Field(default='0', description='CUDA visible devices to use')
