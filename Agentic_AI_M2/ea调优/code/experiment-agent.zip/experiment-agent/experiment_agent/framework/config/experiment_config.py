from pydantic import BaseModel, Field

from experiment_agent.adaptation.config.adaptation_config import AdaptationConfig
from experiment_agent.framework.config.docker_config import LocalDockerConfig
from experiment_agent.framework.config.google_k8s_config import GoogleK8sConfig
from experiment_agent.reproduction.config.reproduction_config import ReproductionConfig
from experiment_agent.framework.config.llm_config_info import LLMConfigInfo


class ExperimentConfig(BaseModel):
    local_docker: LocalDockerConfig = Field(default=None)
    google_k8s: GoogleK8sConfig = Field(default=None)
    stage: str = Field(default=None)
    enable_gpu: bool = Field(default=False)
    conda_env: str = Field(default=None)
    runtime: str = Field(default=None)
    llm: LLMConfigInfo | None = Field(default=None)
    conversation_to_file: bool = Field(default=True)
    adaptation: AdaptationConfig = Field(default=None)
    reproduction: ReproductionConfig = Field(default=None)
