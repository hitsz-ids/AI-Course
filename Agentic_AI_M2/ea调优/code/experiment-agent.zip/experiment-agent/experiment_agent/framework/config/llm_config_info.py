from pydantic import BaseModel, Field, SecretStr


class LLMConfigInfo(BaseModel):
    model: str = Field(default='')
    api_key: SecretStr | None = Field(default=None)
    base_url: str = Field(default='')
    temperature: int = Field(default=0)
    max_message_chars: int = Field(
        default=30_000
    )
