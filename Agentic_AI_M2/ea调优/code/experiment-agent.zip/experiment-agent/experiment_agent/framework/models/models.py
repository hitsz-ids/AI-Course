from openai import BaseModel
from typing import Optional, List


class SotaCandidate(BaseModel):
    git_url: str | None = None
    project_name: str
    workspace: str | None = None
    project_path: str | None = None
    evaluation_env: str | None = None
    image_name: str


class ExperimentParams(BaseModel):
    task: Optional[str]
    sota_candidate: SotaCandidate
