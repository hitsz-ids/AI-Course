"""
logger is used to record program logs

Original implementation: https://github.com/All-Hands-AI/OpenHands/blob/0.48.0/openhands/core/logger.py

"""
