import logging
import os
import sys
import traceback
from datetime import datetime
from types import TracebackType
from typing import Optional

from .colored_formatter import ColoredFormatter
from .config import LOG_DIR, LOG_TO_FILE, LOG_LEVEL
from .llm_file_handler import LlmFileHandler
from .no_color_formatter import NoColorFormatter
from .sensitive_data_filter import SensitiveDataFilter


class LogManager:
    _loggers = {}  # 用于存储已创建的日志记录器

    def __new__(cls, name: str, *args, **kwargs):
        """
        实现单例模式，确保相同名称的日志记录器只创建一次。

        :param name: 日志记录器名称
        """
        if name not in cls._loggers:
            instance = super().__new__(cls)
            cls._loggers[name] = instance
        return cls._loggers[name]

    def __init__(
            self,
            name: str,
            sub_name: str = '',
            log_dir: Optional[str] = LOG_DIR,
            log_to_file: bool = LOG_TO_FILE
    ):
        """
        初始化日志管理器。

        :param name: 日志记录器名称
        :param log_dir: 日志文件目录
        :param log_to_file: 是否将日志记录到文件
        :param log_level: 日志级别
        """
        if hasattr(self, "initialized") and self.initialized:
            return  # 防止重复初始化
        if sub_name:
            self.name = f"{name}[{sub_name}]"
        else:
            self.name = name
        self.log_dir = log_dir
        self.log_to_file = log_to_file
        if LOG_LEVEL in logging.getLevelNamesMapping():
            current_log_level = logging.getLevelNamesMapping()[LOG_LEVEL]
        else:
            current_log_level = logging.INFO
        self.log_level = current_log_level
        self.logger = logging.getLogger(self.name)
        self._configure_logger()
        self.initialized = True  # 标记为已初始化

    def _configure_logger(self):
        """配置日志记录器。"""
        self.logger.setLevel(self.log_level)
        self.logger.addHandler(self._get_console_handler())
        self.logger.addFilter(SensitiveDataFilter(self.name))
        self.logger.propagate = False

        if self.log_to_file:
            self.logger.addHandler(self._get_file_handler())

        if self.log_level == logging.DEBUG:
            self.logger.debug("DEBUG mode enabled.")

    def _get_console_handler(self) -> logging.Handler:
        """返回一个控制台日志处理器。"""
        console_handler = logging.StreamHandler()
        console_handler.setLevel(self.log_level)
        formatter_str = "\033[92m%(asctime)s - %(name)s:%(levelname)s\033[0m: %(filename)s:%(lineno)s - %(message)s"
        console_handler.setFormatter(ColoredFormatter(formatter_str, datefmt="%H:%M:%S"))
        return console_handler

    def _get_file_handler(self) -> logging.Handler:
        """返回一个文件日志处理器。"""
        os.makedirs(self.log_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y-%m-%d-%H:%M:%S")
        file_name = f"{timestamp}_{self.name}.log"
        file_handler = logging.FileHandler(os.path.join(self.log_dir, file_name))
        file_handler.setLevel(self.log_level)
        file_formatter = NoColorFormatter(
            "%(asctime)s - %(name)s:%(levelname)s: %(filename)s:%(lineno)s - %(message)s",
            datefmt="%H:%M:%S",
        )
        file_handler.setFormatter(file_formatter)
        return file_handler

    def _get_llm_file_handler(self, name: str) -> logging.Handler:
        """返回一个用于 LLM 日志的文件处理器。"""
        llm_file_handler = LlmFileHandler(name, delay=True)
        llm_file_handler.setFormatter(logging.Formatter("%(message)s"))
        llm_file_handler.setLevel(self.log_level)
        return llm_file_handler

    def setup_llm_logger(self, llm_name: str) -> logging.Logger:
        """为 LLM 模块设置独立的日志记录器。"""
        llm_logger = logging.getLogger(llm_name)
        llm_logger.propagate = False
        llm_logger.setLevel(self.log_level)
        if self.log_to_file:
            llm_logger.addHandler(self._get_llm_file_handler(llm_name))
        return llm_logger

    @staticmethod
    def log_uncaught_exceptions(
            ex_cls: type[BaseException], ex: BaseException, tb: Optional[TracebackType]
    ) -> None:
        """记录未捕获的异常。"""
        if tb:  # 如果 traceback 存在
            logging.error("".join(traceback.format_tb(tb)))
        logging.error(f"{ex_cls}: {ex}")


# 设置系统异常处理
sys.excepthook = LogManager.log_uncaught_exceptions
