import os
from typing import Mapping, Literal
from dotenv import load_dotenv

load_dotenv()

# 日志基本配置
DEBUG = os.getenv("IS_DEBUG") == 'True' if True else False
LOG_LEVEL = os.getenv("LOGGER_LEVEL") if os.getenv("LOGGER_LEVEL") else "INFO"
if DEBUG:
    LOG_LEVEL = 'DEBUG'

# 日志颜色配置
DISABLE_COLOR_PRINTING = False
ColorType = Literal[
    'red',
    'green',
    'yellow',
    'blue',
    'magenta',
    'cyan',
    'light_grey',
    'dark_grey',
    'light_red',
    'light_green',
    'light_yellow',
    'light_blue',
    'light_magenta',
    'light_cyan',
    'white',
]

LOG_COLORS: Mapping[str, ColorType] = {
}

# 日志文件
LOG_TO_FILE = os.getenv("DEBUG") == '1' if True else False
log_dir = os.getenv('LOG_DIR')
if log_dir is None or log_dir == '':
    log_dir = os.path.join(os.getcwd(), 'logs')
LOG_DIR = os.path.join(log_dir, 'ea')
LOG_DIR = os.path.expanduser(LOG_DIR)
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)
