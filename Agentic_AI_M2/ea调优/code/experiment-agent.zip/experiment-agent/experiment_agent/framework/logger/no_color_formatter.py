import logging
import copy
import re

class NoColorFormatter(logging.Formatter):
    """Formatter for non-colored logging in files."""

    def format(self, record: logging.LogRecord) -> str:
        # Create a deep copy of the record to avoid modifying the original
        new_record: logging.LogRecord = copy.deepcopy(record)
        # Strip ANSI color codes from the message
        new_record.msg = self.strip_ansi(new_record.msg)

        return super().format(new_record)

    def strip_ansi(self, s: str) -> str:
        """Remove ANSI escape sequences (terminal color/formatting codes) from string.

        Removes ANSI escape sequences from str, as defined by ECMA-048 in
        http://www.ecma-international.org/publications/files/ECMA-ST/Ecma-048.pdf
        # https://github.com/ewen-lbh/python-strip-ansi/blob/master/strip_ansi/__init__.py
        """
        pattern = re.compile(r'\x1B\[\d+(;\d+){0,2}m')
        stripped = pattern.sub('', s)
        return stripped
