from experiment_agent.framework.logger.log_manager import LogManager

# 初始化客户端日志
logger_manager = LogManager(name=f"ea_log")
ea_logger = logger_manager.logger
ea_logger.info("experiment agent logger initialized.")
