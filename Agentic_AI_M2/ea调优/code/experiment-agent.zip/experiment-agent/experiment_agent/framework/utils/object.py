from typing import Type, TypeVar

T = TypeVar('T')

def convert(obj, cls: Type[T]) -> T:
    if isinstance(obj, cls):
        return obj
    raise TypeError(f"object is of type {type(obj).__name__}, "
                    f"expected {cls.__name__}")