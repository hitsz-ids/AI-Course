from experiment_agent import ExperimentParams
from experiment_agent.framework.agent.base import StepDecision
from experiment_agent.framework.config.experiment_config import ExperimentConfig
from experiment_agent.framework.memery.base import Memory
from experiment_agent.framework.stage import Stage
from experiment_agent.reproduction.model.reproduction_params import ReproductionParams
from experiment_agent.reproduction.model.reproduction_result import ReproductionResult
from experiment_agent.reproduction.reproduction_agent import ReproductionAgent


def should_proceed_next_step(memory_manager: Memory) -> StepDecision:
    # 当agent准备执行下一步行动时会回调，在MemoryManager中会存在对话的历史和当前的步数
    print(f'当前执行的步骤是否以修改文件为结尾:{memory_manager._conversation.is_editor}')
    return StepDecision(prompt='', proceed=True)


class Reproduction(Stage[ReproductionResult]):

    def __init__(self, config: ExperimentConfig, sid: str | None = None, params: ExperimentParams | None = None):
        super().__init__(config, sid)
        reproduction_params = ReproductionParams(
            repository=params.sota_candidate.git_url,
            reproduce_image=params.sota_candidate.image_name,
            project_name=params.sota_candidate.project_name,
            task=params.task,
            workspace=params.sota_candidate.workspace,
        )
        self.agent = ReproductionAgent(config=config,
                                       should_proceed_next_step=should_proceed_next_step,
                                       sid=sid,
                                       params=reproduction_params)

    def execute(self, params: any = None) -> ReproductionResult | None:
        return self.agent.run()

    def close_resources(self):
        self.agent.close_resources()