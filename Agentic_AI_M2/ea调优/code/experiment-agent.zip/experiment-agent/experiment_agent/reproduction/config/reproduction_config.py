from pydantic import BaseModel, Field


class ReproductionConfig(BaseModel):
    max_iterations: int = Field(default=100)
    memory_storage_type: str = Field(default='memory')
    skip_if_exists: bool = Field(default=True)