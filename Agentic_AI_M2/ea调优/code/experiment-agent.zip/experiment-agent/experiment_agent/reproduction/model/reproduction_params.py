from pydantic import BaseModel


class ReproductionParams(BaseModel):
    repository: str
    reproduce_image: str
    project_name: str
    task: str| None = None
    workspace: str | None = None
