from pydantic import Field

from experiment_agent import StageResult


class ReproductionResult(StageResult):
    image_name: str | None = Field(default=None)
    project_path: str
    project_name: str
    project_env: str
    evaluation_env: str
    workspace: str | None = Field(default=None)
    pod_name: str | None = Field(default=None)
