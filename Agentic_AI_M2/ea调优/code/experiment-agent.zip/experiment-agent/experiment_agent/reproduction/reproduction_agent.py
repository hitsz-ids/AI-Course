import json
import logging
import os
import shutil
import subprocess
from pathlib import Path

import docker
from git import Repo
from openhands.core.config import OpenHandsConfig

from experiment_agent.framework.agent.base import StepDecision, Agent
from experiment_agent.framework.delegate.impl.openhands_delegate import OpenhandsDelegate, create_openhands_config
from experiment_agent.framework.logger.logger import ea_logger
from experiment_agent.framework.memery.conversation import Conversation, Step
from experiment_agent.framework.memery.impl.file_store import FileStore
from experiment_agent.framework.memery.impl.memory_store import MemoryStore
from experiment_agent.framework.memery.iteration_model import IterationModel
from experiment_agent.framework.utils.object import convert
from experiment_agent.reproduction.config.reproduction_config import ReproductionConfig
from experiment_agent.reproduction.model.reproduction_params import ReproductionParams
from experiment_agent.reproduction.model.reproduction_result import ReproductionResult
from openhands.core.config.google_k8s_config import WORKSPACE_BUCKET, SOW_BENCHMARK_BUCKET
from openhands.runtime import DockerRuntime, GoogleKubernetesRuntime


def get_git_modified_files(repo_path: str):
    """
    使用GitPython获取修改过的文件

    参数:
        repo_path: Git仓库路径，默认为当前目录

    返回:
        修改过的文件列表（相对路径）
    """
    try:
        repo = Repo(repo_path)
    except Exception as e:
        raise ValueError(f"获取git修改文件错误:{e}")
    # 仅获取工作目录中未暂存的修改文件
    modified_files = [diff.a_path for diff in repo.index.diff(None)]

    return modified_files


def git_reset_and_clean(repo_path):
    """彻底还原所有修改（包括未跟踪文件）"""
    try:
        # 重置所有已跟踪文件的修改
        subprocess.run(["git", "reset", "--hard"], cwd=repo_path, check=True)
        # 删除所有未跟踪的文件和目录
        subprocess.run(["git", "clean", "-fd"], cwd=repo_path, check=True)
        ea_logger.info("已彻底还原所有修改（包括未跟踪文件）")
    except subprocess.CalledProcessError as e:
        ea_logger.info(f"Git 操作失败: {e}")
        raise ValueError(f"Git 操作失败: {e}")


def git_add_modified(repo_path: str):
    """使用当前时间作为提交消息"""
    message = f"复现修改"

    try:
        subprocess.run(["git", "add", "."], cwd=repo_path, check=True)
        subprocess.run(["git", "commit", "-m", message], cwd=repo_path, check=True)
        ea_logger.info(f"已提交: {message}")
    except subprocess.CalledProcessError as e:
        raise ValueError(f"Git提交复现变更失败")


def cleanup_container(container_name):
    try:
        client = docker.from_env()
        container = client.containers.get(container_name)
        container.remove(force=True)
        ea_logger.info(f"已清理失败的容器: {container_name}")
    except Exception as e:
        raise ValueError(f"清理容器失败: {e}")


class ReproductionAgent(Agent[ReproductionParams, ReproductionResult]):
    reproduction_config: ReproductionConfig
    image_name: str
    workspace: str
    openhands_config: OpenHandsConfig

    def init_config(self):
        ea_logger.info(f'Create Reproduction Agent id is:{self.id}')
        self.reproduction_config = self.config.reproduction

    def init_delegate(self) -> OpenhandsDelegate | None:
        self.openhands_config = create_openhands_config()
        self.openhands_config.max_iterations = self.reproduction_config.max_iterations
        self.openhands_config.sandbox.enable_gpu = self.config.enable_gpu
        self.openhands_config.sandbox.runtime_container_image = self.params.reproduce_image
        self.openhands_config.runtime = self.config.runtime
        ea_logger.info(f"<config配置信息>: {self.config.model_dump_json()}>")
        if self.config.runtime == 'google_k8s':
            self.workspace = (WORKSPACE_BUCKET + '/' + self.params.task + '/' + self.params.project_name)
            self.openhands_config.google_k8s_config.workspace_bucket = self.workspace
            self.openhands_config.google_k8s_config.benchmark_bucket = SOW_BENCHMARK_BUCKET + '/' + self.params.task
            if self.config.enable_gpu:
                self.openhands_config.google_k8s_config.gpu_count = self.config.google_k8s.gpu_count
        elif self.config.runtime == 'docker':
            os.environ['SANDBOX_ENV_PROJECT_NAME'] = self.params.project_name
            self.openhands_config.workspace_mount_path = self.config.local_docker.workspace
            if self.config.enable_gpu:
                self.openhands_config.sandbox.cuda_visible_devices = self.config.local_docker.cuda_visible_devices
        self.openhands_config.default_agent = 'ReproductionAgent'

        for key, value in self.openhands_config.llms.items():
            for attr in self.config.llm.__annotations__:
                if not attr.startswith('_'):
                    setattr(value, attr, getattr(self.config.llm, attr))
        for key, value in self.openhands_config.agents.items():
            value.llm_config = 'llm'

        return OpenhandsDelegate(openhands_config=self.openhands_config,
                                 conda_env=self.config.conda_env,
                                 pre_next_step=self._delegate_pre_next_step,
                                 is_change_python_env=False,
                                 callback_finish=self.finish,
                                 sid=self.id)

    def init_memory(self):
        if self.reproduction_config.memory_storage_type == 'file':
            return FileStore(
                name='reproduction',
                iteration_model=IterationModel(
                    self.reproduction_config.max_iterations, 1),
                conversation=Conversation(),
                sid=self.id)
        else:
            return MemoryStore(
                'reproduction',
                IterationModel(
                    self.reproduction_config.max_iterations, 1),
                Conversation(),
                sid=self.id)

    def run(self) -> ReproductionResult | None:
        if self.delegate is None:
            raise RuntimeError('delegate is Null')
        is_finish = self.delegate.run(self.load_instruction())
        if is_finish:
            return self.result
        else:
            return None

    def _delegate_pre_next_step(self, step: Step, current_iteration: int) -> StepDecision:
        if current_iteration > self.memory.max_iterations:
            return StepDecision(prompt='', proceed=False)
        self.memory.set_iteration(current_iteration)
        self.memory.record(step)
        self.should_proceed_next_step(self.memory)
        return StepDecision(prompt='', proceed=True)

    def load_instruction(self):
        template = Path(os.path.join(os.path.dirname(__file__), 'prompts', 'instruction_template.txt')).read_text(
            encoding='utf-8')
        prompt = template.format(
            repository=self.params.repository,
            project=self.params.project_name
        )
        return prompt

    def _handle_task_completion(self):
        # workspace_base = Path(self.config.workspace).resolve()
        # self._check_is_finished(workspace_base)
        # project_name = self.config.project_name
        delegate = convert(self.delegate, OpenhandsDelegate)
        if self.openhands_config.runtime == 'docker':
            container_name = delegate.runtime(DockerRuntime).container_name
            if not container_name:
                raise TypeError("未查询到容器")
            self.commit_container(container_name)
        elif self.openhands_config.runtime == 'google_k8s':
            self.pod_name = delegate.runtime(GoogleKubernetesRuntime).pod_name
            logging.info(f'Create Reproduction Pod name is:{self.pod_name}')
            self.result = self._create_google_k8s_result()
        # project_path = Path(workspace_base, project_name)
        # self.copy_git_changes_to_temp_and_replace(workspace_base, project_path)
        # git_add_modified(project_path.as_posix())
        # self.clean_workspace(workspace_base, project_name)
        # # 4.提交docker成新的镜像,适配使用,或者直接返回已存在的容器名

        # self.cleanup_container(container_name)

    def _get_new_image_name(self):
        # todo dockerRuntime and google
        delegate = convert(self.delegate, OpenhandsDelegate)
        runtime = delegate.get_runtime()
        if isinstance(runtime, GoogleKubernetesRuntime):
            return f'us-docker.pkg.dev/ardent-rush-467905-s2/mindflow-ai/{self.params.project_name}:reproduction'.lower()
        else:
            return f'{self.params.project_name}:reproduction'.lower()

    def commit_container(self, container_name):
        try:
            image_name = self._get_new_image_name()
            logging.info(f"{container_name} 要提交成为: {image_name}")
            client = docker.from_env(timeout=99999)
            # 提交容器为新的镜像
            container = client.containers.get(container_name)
            new_image = container.commit(repository=image_name, tag='reproduction')
            # push_log = client.images.push(repository=image_name, tag='reproduction')

            self.result = self._create_result(self.config.local_docker.workspace, image_name)
            ea_logger.info(f"提交适配镜像成功,镜像名{new_image}")
        except Exception as e:
            ea_logger.error(f"提交适配镜像失败: {e}")
            raise ValueError(f"提交适配镜像失败: {e}")

    def _copy_git_changes_to_temp_and_replace(self, workspace_base, project_path):

        # 获取所有modified文件
        modified_files = get_git_modified_files(project_path)
        tmp_dir = Path(workspace_base / 'tmp')
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir)
        os.makedirs(workspace_base / 'tmp', exist_ok=True)
        # 挨个复制到临时目录
        for file in modified_files:
            copy_file_path = tmp_dir / file
            if not os.path.exists(os.path.dirname(copy_file_path)):
                os.makedirs(os.path.dirname(copy_file_path))
            shutil.copy(project_path / file, copy_file_path)
            # 还原已修改项目,目的删除新增文件与文件夹,模型,中间结果等
        git_reset_and_clean(project_path)
        # 覆盖变更文件并本地提交
        for file in modified_files:
            shutil.copy(tmp_dir / file, project_path / file)

    def _cleanup_container(self, container_name):
        try:
            client = docker.from_env()
            container = client.containers.get(container_name)
            container.remove(force=True)
            ea_logger.info(f"已清理失败的容器: {container_name}")
        except Exception as e:
            raise ValueError(f"清理容器失败: {e}")

    def _create_result(self, workspace_base: str, image_name: str) -> ReproductionResult | None:
        try:
            config_path = os.path.join(workspace_base, '.config.json')
            with open(config_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            required_keys = {"project_name", "project_env", "project_path", "evaluation_env"}
            if required_keys.issubset(data.keys()):
                result = ReproductionResult(
                    image_name=image_name,
                    project_name=data['project_name'],
                    project_env=data['project_env'],
                    project_path=data['project_path'],
                    evaluation_env=data['evaluation_env'],
                )
            else:
                missing_keys = required_keys - set(data.keys())
                raise ValueError(f"复现环境失败缺失的环境: {missing_keys}")
            return result
        except Exception as e:
            ea_logger.info(f"当前目录.config.json文件读取错误:{e}, 重新运行reproduction生成对应镜像")

    def _create_google_k8s_result(self) -> ReproductionResult | None:
        try:
            delegate = convert(self.delegate, OpenhandsDelegate)
            response = delegate.runtime(GoogleKubernetesRuntime).get_config()
            if response.status_code == 200:
                config_data = response.json()
                required_keys = {"project_name", "project_env", "project_path", "evaluation_env"}
                if required_keys.issubset(config_data.keys()):
                    result = ReproductionResult(
                        project_name=config_data['project_name'],
                        project_env=config_data['project_env'],
                        project_path=config_data['project_path'],
                        evaluation_env=config_data['evaluation_env'],
                        pod_name=self.pod_name,
                        workspace=self.workspace,
                    )
                else:
                    missing_keys = required_keys - set(config_data.keys())
                    raise ValueError(f"复现环境失败缺失的环境: {missing_keys}")
                return result
            else:
                ea_logger.info(f"当前目录.config.json文件读取错误:请求获取配置信息失败")
        except Exception as e:
            ea_logger.error(f"当前目录.config.json文件读取错误:{e}, 重新运行reproduction生成对应镜像", exc_info=True)

    def finish(self):
        self._handle_task_completion()

    def close_resources(self):
        delegate = convert(self.delegate, OpenhandsDelegate)
        if self.config.runtime == 'docker':
            container_name = delegate.runtime(DockerRuntime).container_name
            cleanup_container(container_name)
        elif self.config.runtime == 'google_k8s':
            delegate.runtime(GoogleKubernetesRuntime).cleanup_k8s_resources()
