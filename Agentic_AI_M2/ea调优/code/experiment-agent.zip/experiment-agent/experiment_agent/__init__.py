import json
import os
import uuid
from enum import Enum

import toml

from experiment_agent.framework.config.experiment_config import ExperimentConfig
from experiment_agent.framework.logger.logger import ea_logger
from experiment_agent.framework.models.models import ExperimentParams
from experiment_agent.framework.stage import Stage, StageResult, StageStatus
from experiment_agent.reproduction.model.reproduction_result import ReproductionResult

ENV_EA_CLIENT_CONFIG = 'ENV_EA_CLIENT_CONFIG'


class ExperimentStage(Enum):
    REPRODUCTION = 'reproduction'
    ADAPTATION = 'adaptation'
    ALL = 'all'


from typing import List, TypeVar

R = TypeVar('R', bound=StageResult)


class ExperimentAgent:
    """
    支持多阶段实验，阶段按顺序执行。
    每个阶段在前一阶段执行完成后才创建。
    """
    stage_configs: List[ExperimentStage]  # 存储阶段的配置名称
    stages: List[Stage]  # 已执行的阶段实例
    config: ExperimentConfig
    sid: str

    def __init__(self, sid: str | None = None, config_file: str | None = None):
        self.stages = []
        self.tasks = []
        self.load_config(config_file=config_file)
        self.stage_configs = self._get_stage_configs()
        if sid is None or sid == '':
            sid = str(uuid.uuid4())
        self.sid = sid

    def _get_stage_configs(self) -> List[ExperimentStage]:
        """返回阶段名称列表，保证统一为 list，并处理 'all'"""
        stage_names = self.config.stage
        if isinstance(stage_names, str):
            stage_names = [stage_names]

        resolved_stages: List[ExperimentStage] = []
        for name in stage_names:
            stage_enum = ExperimentStage(name.lower())
            if stage_enum == ExperimentStage.ALL:
                # 展开 all 为两个阶段
                resolved_stages.extend([
                    ExperimentStage.REPRODUCTION,
                    ExperimentStage.ADAPTATION
                ])
            else:
                resolved_stages.append(stage_enum)

        ea_logger.info(f"正在准备运行stage：{resolved_stages}")
        ea_logger.info(f"当前使用的LLM配置：{self.config.llm}")
        return resolved_stages

    def _create_stage(self, stage_enum: ExperimentStage, prev_output: R,
                      params: ExperimentParams) -> Stage:
        """
        根据上一个阶段的输出动态创建下一个阶段
        """
        if stage_enum == ExperimentStage.REPRODUCTION:
            from experiment_agent.reproduction.reproduction import Reproduction
            return Reproduction(self.config, sid=self.sid, params=params)
        elif stage_enum == ExperimentStage.ADAPTATION:
            from experiment_agent.adaptation.adaptation import Adaptation
            return Adaptation(self.config, prev_output, sid=self.sid)
        else:
            raise RuntimeError(f'Unknown experiment stage: {stage_enum}')

    def run(self, params: ExperimentParams):
        """
        按顺序执行阶段。
        前一个阶段执行结果作为下一阶段创建时的参数。
        """
        prev_output = None
        if self.config.stage == ExperimentStage.ADAPTATION.value:
            prev_output = ReproductionResult(
                image_name=params.sota_candidate.image_name,
                project_name=params.sota_candidate.project_name,
                workspace=params.sota_candidate.workspace,
                project_path=params.sota_candidate.project_path,
                project_env=params.sota_candidate.project_env,
                evaluation_env=params.sota_candidate.evaluation_env,
            )
        close_stage = None
        for index, stage_enum in enumerate(self.stage_configs):
            stage_name = stage_enum.value
            stage = self._create_stage(stage_enum, prev_output, params)
            close_stage = stage
            stage.set_status(StageStatus.RUNNING)
            ea_logger.info(f'{stage_name} is running')
            try:
                output = stage.execute(prev_output)
                self.stages.append(stage)
                prev_output = output
                stage.set_status(StageStatus.COMPLETED)
                ea_logger.info(f'{stage_name} is completed')
            except Exception as e:
                stage.set_status(StageStatus.FAILED)
                ea_logger.error(f'{stage_name} is failed: {e}', exc_info=True)
                break
        try:
            close_stage.close_resources()
        except Exception as e:
            ea_logger.error(f'resource close failed: {e}', exc_info=True)

    def load_config(self, config_file: str | None = None):
        """从环境变量中读取 JSON 并转换为 ExperimentConfig"""
        env_config = self._load_from_env(ENV_EA_CLIENT_CONFIG)
        config = ExperimentConfig()
        toml_config = self._load_from_toml(config_file)

        for attr in config.__annotations__:
            # 如果env_config为None，或者env_config中该属性为None，则使用toml_config
            if env_config is None:
                value = getattr(toml_config, attr)
            else:
                env_value = getattr(env_config, attr)
                value = env_value if env_value is not None else getattr(toml_config, attr)

            setattr(config, attr, value)

        self.config = config

    def get_stages(self) -> List[str]:
        """
        返回当前 Agent 已创建的阶段列表，每个阶段包含名称和状态。
        格式类似: "阶段名称[状态]"
        """
        return [f"{type(stage).__name__}[{stage.status.name}]" for stage in self.stages]

    def get_stages_config(self) -> List[ExperimentStage]:
        return self.stage_configs

    @classmethod
    def _load_from_toml(cls, config_file: str):
        try:
            with open(config_file, 'r', encoding='utf-8') as toml_contents:
                toml_config = toml.load(toml_contents)
        except Exception as e:
            raise e
        return ExperimentConfig.model_validate(toml_config)

    @classmethod
    def _load_from_env(cls, env_var: str):
        config_json = os.getenv(env_var)
        try:
            config_data = json.loads(config_json)
            return ExperimentConfig.model_validate(config_data)
        except Exception as e:
            # ea_logger.error(e, exc_info=True)
            return None
