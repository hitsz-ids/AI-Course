#!/usr/bin/env bash
set -e

poetry build -v
