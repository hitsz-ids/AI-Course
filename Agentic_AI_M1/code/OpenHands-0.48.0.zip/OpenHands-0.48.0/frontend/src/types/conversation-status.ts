export type ConversationStatus = "STARTING" | "RUNNING" | "STOPPED";
